# PROMPT PARA ARGON — reducir el tiempo de Kaggle

Copia desde aquí hasta el final y pásaselo a Argon tal cual, con el zip adjunto.

---

Eres Argon. Tienes acceso a un entorno agéntico: puedes descomprimir, ejecutar Python,
leer todos los ficheros y hacer cuentas tú misma. No tienes GPU. Eso está bien: lo que
te pido es que **hagas las cuentas**, no que midas.

Te he pasado un paquete con el estado real de un proyecto de SFT. Empieza leyendo
`00_BRIEFING.md` entero. Ahí está el problema, las mediciones y las restricciones.
Después mira `codigo/configuration_v4x.py` y `codigo/celda_SESION1_v141.py` (el bucle del
piloto está hacia el final, busca `ms_step` y `tok_s`), porque el briefing no basta para
entender cómo se ejecuta de verdad.

## El problema en una frase

Entrenar 1.974.760.183 tokens en Kaggle con 30 GPU-hora por semana. La última medición
real dice 47,7 tok/s, que son ~11.500 horas de reloj. Necesito que encuentres de dónde
salen esas horas y qué cambios legítimos las bajan más.

## Cuatro reglas que no se negocian

1. **No inventes cifras.** Cada número que escribas va etiquetado como MEDIDO (y dices de
   qué fichero o qué experimento sale) o PAPEL (y escribes la aritmética que lo produce).
   Si no puedes sostenerlo, escribe "no lo sé" y explica qué haría falta para saberlo.
   Prefiero un hueco honesto a un relleno.
2. **No propongas LoRA, QLoRA, 4-bit, NF4, fp8 en entrenamiento ni pesos entrenables en
   bf16.** Están vetados por decretos del proyecto. Si crees que una de esas es la única
   salida, dilo como "esto requeriría derogar el decreto X", no como recomendación.
3. **Nada de prosa que sustituya números.** Si dices "mejora notablemente", has fallado.
   Di "1,8× y aquí está el cálculo".
4. **El techo es Kaggle 1×T4 o 2×T4.** No propongas A100, H100 ni multi-nodo como plan
   principal. Puedes mencionarlos una vez como comparación de coste, nada más.

## Lo que quiero que hagas, en este orden

### Paso 1 — Audita las mediciones antes de usarlas

Abre `medidas/piloto_OPT1.json`, `medidas/piloto_BASE.json` y `medidas/p0_microbench.json`.
Comprueba tú misma:

- que `tok_s = 47,7` es coherente con `ms_step = 10.725,2` y con T=512, batch=1;
- que el `p0` dice lo que el briefing afirma (fp16 21,8 vs bf16 1,9 TFLOPS, 14,18 GFLOP
  por token en forward);
- cuáles de las cifras del `p0` son imposibles físicamente y por qué.

Si encuentras un error en mi briefing, **corrígelo**. Ese es parte del trabajo.

### Paso 2 — Descompón el step

Con lo que hay en los ficheros, construye un presupuesto del step de 512 tokens:

| Componente | ms | % |
|---|---|---|

Separa al menos: GEMM de los expertos, atención, capas mamba, lm_head / CE, copias por el
split entre las dos GPU, lanzamiento de kernels, paso del optimizador. Cuando un
componente no se pueda separar con los datos disponibles, dilo y da la cota.

El dato que me interesa: el piloto va a **21,0 ms/token** y el techo aritmético del `p0`
es **7,46 ms/token**. Hay 2,8× de aire ahí. ¿Dónde está?

### Paso 3 — Modela las palancas

Para cada una de estas, dame speedup estimado del **step completo** (no del kernel),
coste de implementación (bajo/medio/alto) y efecto en VRAM:

1. **Una GPU en vez de dos** para las tandas que caben en 14,86 GiB. Ojo: el split actual
   cruza PCIe en cada frontera de capa.
2. **T = 8192 en vez de 512.** El coste escala distinto en GEMM (lineal) que en atención
   (cuadrática) y que el overhead de kernel (constante).
3. **Sombra fp16** (`acel_BF16_TURING.py`). El ratio de GEMM es 11,47× pero Amdahl lo
   rebaja. Con `ratio_wgrad0 = 0,709` (wgrad = 29,1 % del step), calcula el speedup real
   del step y qué pasa cuando el slot entrenable es grande (37 % del modelo en Phi, ~4 %
   en Nemo).
4. **`torch.compile`**, **CUDA graphs**, **gradient checkpointing**, **prefetch de datos**.
   Para cada una: qué ataca exactamente y cuánto puede dar en esta máquina concreta.
5. **Trocear por capas** el modelo grande (Phi) para que quepa: cuánto cuesta en tiempo
   de interacción entre trozos.

### Paso 4 — Responde la pregunta incómoda

Con las restricciones puestas, ¿cuál es el **mejor caso realista** de tok/s? Y con ese
mejor caso, ¿cuántas semanas cuesta el entrenamiento completo a 15 h de reloj por semana?

Si la respuesta es "no cabe en un horizonte razonable", dímelo así. No maquilles el
número para que quede bonito. Si el plan es imposible tal como está, lo que necesito
saber es **cuánto habría que recortar el volumen de datos** para que quepa en, digamos,
un año, y qué se pierde al recortarlo.

### Paso 5 — Entrega

Genera estos cuatro ficheros:

- **`VEREDICTO.md`** — las respuestas, con la tabla del step, la tabla de palancas y el
  veredicto final. Cada cifra etiquetada MEDIDO o PAPEL.
- **`plan.json`** — configuraciones candidatas, cada una como
  `{"nombre", "knobs", "tok_s", "horas", "semanas", "vram_gib", "esfuerzo", "viola_decreto"}`.
- **`presupuesto_step.csv`** — componentes del step en ms y %.
- **`ERRORES_EN_EL_BRIEFING.md`** — todo lo que he dicho mal y tú has pillado.

## Una nota sobre el tono

No me digas lo que quiero oír. Si el 47,7 tok/s se debe a que el bucle hace algo
evitable y arreglarlo es trivial, quiero saberlo. Si se debe a que el modelo es
simplemente demasiado grande para dos T4 y no hay palanca que lo arregle, también.
Las dos respuestas me sirven; una respuesta tibia no.
