# TESTS A1/A2 — Análisis profundo y árbol de decisiones (encargo "profundiza", 13-oct)

Dos preguntas baratas que deciden cosas caras. Ninguna toca pesos. Ambas son **perplejidad por teacher-forcing** sobre los mismos 200 textos con la misma semilla, antes de gastar horas de entrenamiento.

---

## A1 · ¿RoPE o NoPE en las 6 capas de atención?

### El fondo (por qué esta pregunta existe — ACTUALIZADO 13-oct con contexto OOMB)
La base híbrida (Nemotron-3-Nano: 23 Mamba + 6 atención + 23 MoE) se pre-entrenó **sin codificación posicional en atención (NoPE)**: en un híbrido, el orden de la secuencia lo transporta Mamba de forma recurrente y absoluta; las pocas capas de atención aprenden *retrieval* por contenido sin fase posicional. La rama V4X **añadió RoPE + YaRN ×4 (262K→1M)… y ahora sabemos POR QUÉ: es el traje del OOMB-500K**. Al entrenar a 500K sobre capacidad 1M, el estiramiento efectivo queda en **×2: el régimen donde YaRN apenas interpola las frecuencias altas = su punto dulce**. El diseño es coherente y deliberado, no equipaje.

### La pregunta correcta (reencuadrada)
YA NO es "¿RoPE o NoPE?" — es: **"¿cuánto nos cuesta HOY, a 2-8K, llevar puesto el traje del OOMB?"**
Nuance física: si la atención nunca entrenó con fase, el stock (RoPE) puede salir peor AHORA y eso sería *esperado* (ropa no adaptada de cara al OOMB), no necesariamente motivo de retirada. El default pasa a **conservar RoPE salvo catástrofe clara**; lo que decide el test es por dónde se paga el coste.

### Mecánica (sin cambios de fondo)
- **Corpus fijo**: 200 textos hold-out (estratificado: ~50% código URT, ~25% razonamiento Ado, ~25% charla/técnico; semilla 42, guardado en `fidelidad_sample_espec.json`).
- **Condición A (stock)**: RoPE+YaRN tal cual (config actual).
- **Condición B (nope)**: monkeypatch de `V4XRotaryEmbedding.forward` → `cos≡1, sin≡0` (identidad exacta; el resto del grafo idéntico).
- **Longitudes**: 2.048 y 8.192 (si la brecha crece con L, es señal posicional estructural).
- **Métricas**: ppl total + ppl en la región final-512 tokens (uso de contexto lejano) **+ ppl en la región inicial-512 (control: si RoPE daña uniformemente, también se verá ahí)**.

### Árbol de decisiones (rehecho para el contexto OOMB)
| Resultado | Decreto |
|---|---|
| A ≤ B o empate (<1%) | RoPE se queda sin coste pagado: el traje le sienta bien incluso hoy. Cerrado. |
| B mejor que A por 1-3% | Coste pequeño por llevar el traje: **conservar RoPE y seguir** — el OOMB lo amortiza; registrar el coste en CAMBIOS. Opcional: flag `V4X_NOPE=1` solo para evaluaciones cortas, jamás para borrar la capacidad. |
| B mejor que A por >3% | Coste serio: abrir debate de calibración (rampa YaRN / `original_max_position` / beta_fast-slow) en lugar de retirada; RoPE sigue para OOMB; la atención está congelada de facto (slots=expertos) y se monitorea. |

Pregunta abierta para la fase OOMB (aparcada por la regla no-mezclar): **¿qué entrena durante el OOMB para que la atención se ADAPTE a la fase?** Los slots de expertos no tocan q/k. Candidatos: LoRA q/k/o exclusivo de esa fase, qk-norms, o descongelar atención entonces. Decidir cuando toque.

Barra de honestidad: 200 textos ≈ ruido ±0,3% ppl; los umbrales de la tabla ya lo descuentan.

---

## A2 · ¿top-6 nativo o top-8 decretado? → **DECRETADO 13-oct: top_k = 6** (test pasa a confirmatorio)

### Estado del decreto
13-oct: el usuario decretó **top_k=6** ("es lo que usa Nemotron"), supersede al top_k=8 previo. El test ya no decide: **mide el margen del decreto** y sirve de telemetría de salud del gate.

### El fondo
El gate nativo Nemotron usa **scoring sigmoid + norma de top-k + routed_scaling 2,5**, calibrado alrededor de **top-6** (Σw post-normalización ×2,5 ≈ distribución de salida MoE con la que se entrenó). Forzar k=8 altera la masa de salida por token (des-calibración), cuesta **~12-14% de FLOPs/token totales** (activos 3,22B→3,68B) y **ensancha la unión de expertos por pack** = más streaming PCIe/secuencia.

### Mecánica
- Mismos 200 textos, semilla, batch, longitudes.
- **Condición native**: gate Nemotron con top_k=6. **Condición decreto**: top_k=8 (override existente, celda_7 `V4X_TOPK`).
- Métricas: ppl (total + final-512), **entropía mediana de pesos del router** (¿sigmoid saturado → pesos ~uniformes?) y **cobertura** (¿el 7º-8º experto aporta masa real o es ruido residual?).
- ⚠️ Este test lee el **gate nativo (modo off)**; el router unified-sembrado (A3) tiene su propio A/B posterior — no mezclar los dos experimentos.

### Árbol de decisiones
| Resultado | Decreto |
|---|---|
| top-6 ≤ top-8 | Adoptar 6: −12-14% FLOPs + menos expertos/paso (PCIe). El decreto top_k=8 se reescribe **con evidencia** (CAMBIOS). |
| top-8 > top-6 claro | top_k=8 se sella con evidencia. |
| Empate | 6 por economía; registrar. |

---

## Protocolo común (garantías)
- Semilla 42 en TODO (muestreo, dropout off, batch order). Sin entrenamiento. bf16 pipelined idéntico en ambas condiciones (misma precisión ⇒ comparación limpia).
- Salida: tabla ppl por condición×longitud + JSON crudo → veredicto → CAMBIOS.
- **Dependencia (honesta)**: la medición necesita un forward de 88 GB sin entrenamiento → o ① el runner de barrido del kit (rama streaming local, `V4X_STREAM_DISK`) en tu PC local, o ② el motor nuevo cuando exista. La celda está cableada para ambos: si detecta runner local lo usa; si no, aborta con instrucciones.
- Coste estimado: 1-3 h en una GPU por la matriz completa (8 condiciones), mucho menos con muestreo corto.

---

## TEST R-25 (obligatorio tras CAZA #25, ARGON/96): ruteo correcto en capa MoE con dim=177

Gate #0 de ARGON: antes de cualquier entrenamiento, demostrar que el mapa de slots funciona en el caso maldito (valid_rows.numel() == num_experts == 177).

1. Instanciar `V4XRouter(hidden_size, 177, top_k=6, scoring="softmax")` (hidden pequeño basta, p.ej. 64) + valid_rows = `[0..127, 129..177]` (177 filas).
2. ASSERT topk_indices ⊆ {0..127} ∪ {129..177} — **el 128 (shared) jamás puede salir**.
3. ASSERT con `_phi_span_mask = 0` (fuera de think): la columna de fila 176 (=slot 177, Phi) queda a -inf → Phi no sale en top-6.
4. ASSERT despacho downstream: idx 176 → `local = 177-129 = 48` → `experts[177]` (Phi) recibe tokens; idx 128 → `local = 129-129 = 0` → Qwen#1 sigue existiendo.
5. ASSERT ancla (flag ON, `_forced_slot=177`): top-1 == 177 en todas las filas, también bajo row_offset.
6. Repetir en dim=178 (capa no-MoE) y dim=129 (capas 48-51): sin regresión.

Fichero ejecutable: pendiente (Kaggle tiene torch; sandbox no). Candidato: `celda_TEST_R25_router.py`.

---

## TESTS R-24b / R-25.7 / R-26 / R-27 (CAMBIOS 98 — endurecimiento exigido por el segundo externo)

- **R-24b (CAZA #24, cierre real)**: además del dedup de ids, construir `torch.optim.AdamW(entrenables, lr=1e-4)` para CADA tanda y hacer 1 step sintético: no debe lanzar ValueError. (La caza original vivía en el CONSTRUCTOR del optimizador; el test de ARGON no llegaba allí — corregido por exigencia de ChatGPT.)
- **R-25.7 (paridad fila↔logit, CAZA #25)**: con dim=177 y valid_rows numel==177, calcular a mano `L = x @ W.T` y el top-6 manual; exigir que los índices devueltos (mapeados por row_offset) y los pesos softmax coincidan <1e-6 con ese top-6 manual. No basta "índice ∈ conjunto permitido": hay que demostrar que cada slot usa la puntuación de SU fila física (punto 2 de ChatGPT, aceptado — el diseño 1-a-1 se prueba, no se asume).
- **R-26 (CAZA #26)**: con un pack 100% -100, monkeypatch del forward para lanzar excepción si se llama: el bucle debe saltarlo (0 llamadas GPU) y `saltadas == 1`.
- **R-27 (CAZA #27)**: (a) 8 packs seguidos 100% -100 → 0 yields, 0 llamadas a scaler.step; (b) mezcla 8-k supervisados + k skips → yield SOLO tras el 8º supervisado, divisor = 8 supervisados reales; (c) cola final de tanda con acc en {1..7} → yield parcial correcto.
