# CURA-26 — la celda deja de estar bloqueada

Fecha: 2026-09-11 · Fichero: `AI-ku_New/celda_KAGGLE_v3_entreno.py` (1.548 líneas)
md5: `e57c0444a859c0baf86ea69b05f3ffcf` · copia: `_bak/celda.after_cura26.py`

---

## 1. Qué estaba roto y qué es ahora

| Bloqueante | Antes | Ahora |
|---|---|---|
| `iter_packs` | `NotImplementedError` — la celda moría antes del primer paso | Lector real: json / jsonl / parquet / gz, caché en disco, prefetch |
| Reanudar a mitad de tanda | El cursor se **escribía** pero nadie lo **leía** | `desde_packs` conectado al bucle |
| Tokenizador | No existía en la celda | Se carga de `V4X_REPO` una vez, con guardia |
| Disco | Nadie miraba | Poda de packs + guardia de espacio antes de construir |
| MFU | Constante de papel `410` | Medido y persistido; el papel solo si no hay medición |

## 2. Lo que se ha medido de verdad (aquí, sin GPU)

| Medición | Valor | Método |
|---|---|---|
| Ritmo del constructor de packs | **300 Ktok/s por núcleo** | tokenizador real Qwen2.5, 3.000 documentos |
| Los 1.975 M tokens del manifiesto | **110 min de CPU, una sola vez** | extrapolación del ritmo medido |
| Relectura de caché | **130× más rápida** que reconstruir | 149 packs, idénticos byte a byte |
| Disco de todos los packs | **15,80 GB** (241.060 packs de 64 KiB) | aritmética exacta |
| Cuota de Kaggle | 20 GB ⇒ **margen 4,2 GB** sin checkpoints | ⇒ la poda no es opcional |

El tokenizador **no es el cuello de botella**: 300 Ktok/s de CPU contra 410 tok/s de GPU es 730× de margen. Lo que sí era el cuello de botella era no tener lector.

## 3. Corrección de la máscara (tokenizador real)

La plantilla de Qwen2.5 **no** trae `{% generation %}`, así que el camino "oficial" de `return_assistant_tokens_mask` devuelve máscara nula. El plan B obvio (tokenizar cada prefijo) es O(n²) en tokenizaciones. Implementado por **renderizado de prefijos en texto + una sola tokenización con `offset_mapping`**.

Verificación sobre 30 turnos: 860 tokens, 440 supervisados (51,2 %), **cero texto de usuario o de sistema en la parte supervisada**, las 30 respuestas presentes. Coste: 2,1 ms por documento de 12 turnos.

Decisión añadida: el EOS de cierre de documento **solo** se supervisa si el documento acaba en turno `assistant`. Antes se supervisaba siempre, lo que entrenaba a cerrar el turno del usuario.

## 4. Los tres pasos que pediste

### (1) Checkpoint — hecho y probado
7 pruebas, todas verdes: estado inicial, marcado de completadas, cursor a mitad, **archivo intacto tras un kill simulado a mitad de escritura**, JSON corrupto reconstruido, presupuesto por tanda, poda (6 → 3).

### (2) Piloto — preparado, **no ejecutado**. No hay GPU aquí.
No puedo darte un MFU medido. Puedo darte el comando exacto y el coste:

```
V4X_PILOTO_PACKS=256      # 256 packs ≈ 2,1 M tokens por tanda
V4X_TANDAS=39,155,139     # slots que CABEN (Phi no cabe)
```

| Packs/tanda | Tokens (3 tandas) | Coste a 410 tok/s |
|---|---|---|
| 128 | 3,1 M | 2,13 h |
| **256** | **6,3 M** | **4,26 h** |
| 512 | 12,6 M | 8,53 h |

Los 410 tok/s son **PREVISTO-PAPEL(P)**. El piloto existe exactamente para sustituirlo por un número medido. El modo piloto **no** marca las tandas como completadas.

### (3) Phi — decisión por aritmética: **no entra**

| Concepto | GiB |
|---|---|
| Base congelada | 11,44 |
| Pesos bf16 (3.179,2 M) | 5,92 |
| Gradientes bf16 | 5,92 |
| AdamW fp32 (m + v + maestro) | 35,53 |
| **Total** | **58,81** |
| Techo LTUS-1 (29.000 MiB) | 28,32 |
| **Déficit** | **30,49** |

No es ajustado: falta más memoria que la que hay. El peso muerto es el estado AdamW (35,53 GiB), no las activaciones — por eso el gradient checkpointing no lo arregla.

Coste de dejarlo fuera: 0,423 B tokens = **287 h de reloj** (a 410 tok/s) = 19 semanas de las 89. Un 21 % del calendario a cambio de cero compromisos de calidad, porque Phi no se entrenaría en ningún caso dentro de este marco.

Las dos salidas necesitarían decretazo explícito, y ninguna es gratis:
- **Optimizador de 8 bits** (estado cuantizado, no pesos): baja AdamW a ~17,7 GiB, total ≈ 41 GiB. Sigue sin caber en 29.
- **Partir Phi en dos tandas de 8 capas**: 1,156 B params, total ≈ 26,5 GiB, **sí cabría**. Rompe el contrato "una tanda = un slot" y duplica el coste de interacción entre capas.

## 5. Lo que sigue sin estar medido

Todo el apartado GPU. Nada de esto se ha ejecutado en una T4: ni un paso, ni un tok/s, ni un MFU. Lo que hay es aritmética y simulación, más el tokenizador real. El 11,47× del `p0` sigue pendiente de la prueba de sombra ON/OFF con el mismo batch y la misma semilla.
