# RUNTIME_REQS.md — Checklist casa-first para "runtime que ejecute AI-ku"

**Pre-registrada**: 14-oct-2026, antes de la propuesta de ARGON (vuelve 23:24).
**Uso**: la propuesta del externo se coteja contra esta lista (regla 79: spec
externa en cuarentena; NO se le entrega esta lista — llega ciega). Si no
satisface un punto → al acta con el argumento; dirime medición, no debate.

## Extraído de los canónicos (modeling_v4x.py / configuration_v4x.py / config.json)

**Carga (obligatorio):**
- [ ] `AutoModelForCausalLM.from_pretrained(<carpeta>, trust_remote_code=True, torch_dtype=torch.bfloat16)`
- [ ] La carpeta contiene los 3 archivos de SYNC_MODELO.md con sus md5 (auto_map → `configuration_v4x.V4XConfig` + `modeling_v4x.V4XForCausalLM`; architectures=`V4XForCausalLM`)
- [ ] `config.json` íntegro: `num_logits_to_keep: 1` (¡cualquier eval de logits completos exige pasar 0 explícito — lección caza #4!), `v4x_router_top_k: 6`, `v4x_phi_span_mask: false`, routing por defecto `unified` (para tests de gate NATIVO: `v4x_routing_mode="off"` — caza #5)

**Versiones (obligatorio declarar, con pin):**
- [ ] python exacto
- [ ] torch exacto + cu_TARGET acorde a la GPU destino (T4 = sm_75 en Kaggle; si el runtime es otra GPU, declararla)
- [ ] transformers: el config fue generado con `transformers_version: 5.16.1` → la propuesta debe declarar su versión y justificar compatibilidad con auto_map/trust_remote_code

**Dependencias exóticas del modeling (todas opcionales con fallback, verificar):**
- [ ] `mamba_ssm` (triton selective_state_update + mamba_chunk_scan_combined) — fast path SSM; sin él, hay fallback local (RMSNorm con puerta, l.127). Declarable SOLO si acelera en la GPU destino (medición, no fe)
- [ ] `causal_conv1d` — fast path conv1d; sin él cae a conv PyTorch (veredicto ARGON-77: A/B con gate)
- [ ] `flash_attn_2` — ⚠️ REQUIERE sm_80+ → **NO corre en T4/sm_75**: en Kaggle debe forzarse SDPA/eager. Si el runtime propone flash-attn en T4, la propuesta falla aquí
- [ ] Vetos vigentes: fp8-e4m3 FUERA; KV flags default "none"; ssm-int8 solo con A/B

**Inferencia sana (obligatorio):**
- [ ] Modelo en `eval()` + `torch.no_grad()`; inputs_embeds solo si se sabe lo que se hace (FIX-06c: máscara pegada era el riesgo — ya curado, pero la celda no debe pasar phi_span sin input_ids)
- [ ] Generación vía GenerationMixin nativo (el modeling hereda); nada de parches de sampling externos sin A/B

**Penal de descalificación automática:**
- [ ] Cambiar/parchear archivos del modelo (los 3 son inmutables salvo CAMBIOS del árbitro)
- [ ] Instalar dependencias exóticas "porque sí" sin justificar contra la línea del canónico que las usa
- [ ] bf16 en entrenamiento (decreto: BF16 solo en pesos; entrenamiento fp16+loss-scale en sm_75 — caza #9)
