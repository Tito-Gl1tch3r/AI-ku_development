# AI-ku V4X · Los 177 expertos: qué entendí, qué no cuadra y qué haría
**Fecha:** 2026-11-11

---

## 1 · Lo que estás construyendo, en mis palabras

Un modelo **denso en información y disperso en cómputo**: los 177 expertos *opinan* sobre cada token, pero
solo unos pocos *ejecutan*. El router no es un portero que descarta — es el que decide **qué seis inteligencias
miran este token**, y el resultado es una sola respuesta, no seis.

La diferencia con un multiagente: aquí no hay mensajes entre procesos. Hay un **espacio de representación
compartido** por el que todos los expertos escriben y del que todos leen, dentro del mismo forward. Tu
filosofía es correcta y es la distinción que casi todo el mundo confunde: **colaborar no es repartir tareas,
es compartir estado.**

Hasta ahí, perfecto. Ahora lo que no cuadra.

---

## 2 · La contradicción que hay que resolver antes de entrenar nada

Tu `configuration_v4x.py` dice, literalmente:

```python
n_routed_experts=177,
num_experts_per_tok=177,    # router denso V4X
v4x_router_top_k=None,      # None -> num_experts_per_tok (denso)
```

Eso **no es top-6: es denso**. Y su factura:

| Configuración | params/token | pesos leídos por token |
|---|---|---|
| **177 ejecutados (lo que dice el config)** | **60,2 B** | **112,1 GiB** |
| **6 ejecutados de 177 puntuados** | **2,04 B** | 3,8 GiB |

Tu cifra de «~3,2 B activos por token» corresponde a una media de **15,2 M params por plaza**, que solo
sale si Phi-177 entra en ~1 de cada 10 plazas. Es aritmética de **top-6**, no de 177.

No es un detalle de estilo: **son dos modelos distintos**. Hay que decidir cuál manda antes de gastar 50.000
pasos, porque entrenar el router con la semántica equivocada entrena otra cosa.

**Mi lectura:** lo que quieres es *177 puntuados, 6 ejecutados*. El `177` del config es la **superficie de
decisión del router**, no el cómputo. Si es así, `num_experts_per_tok` debería ser 6 y el denso ir en otro
campo. Pero es tu decisión, no la mía.

---

## 3 · Las dos facturas: memoria y tiempo son problemas separados

### Memoria — aquí Q4 sí ayuda, y mucho

| Precisión | Tamaño | 1×T4 (15 GiB) | **2×T4 (30 GiB)** | RAM portátil (14,96) |
|---|---|---|---|---|
| fp16 | 87,9 GiB | NO | NO | NO |
| Q8 | 44,0 GiB | NO | NO | NO |
| **Q4** | **22,0 GiB** | NO | **SÍ** | NO |
| Q2 | 11,0 GiB | SÍ | SÍ | SÍ |

**Q4 es lo que hace que el modelo entero quepa — pero solo en LTUS-1.** En 1×T4 no cabe ni en Q4. En el
portátil, tampoco. Eso convierte «LTUS/LEUS para Q4» en **LTUS-1 para Q4**, no en las dos.

### Tiempo — aquí Q4 NO ayuda, estorba

| | GFLOP/token | tok/s en 1×T4 |
|---|---|---|
| fp16 | 19,2 | 1.104 |
| Q4 con dequant on-the-fly | 30,7 | **690** |

Q4 **reduce bytes leídos, no operaciones**. Y entrenar exige **descuantizar** para el backward: acabas
haciendo más trabajo que en fp16. **Q4 es un truco de capacidad, no de velocidad.**

Esto es una corrección a tu frase «necesitaríamos una LTUS/LEUS para Q4». Lo que necesitas tiene nombre y
está resuelto: **QLoRA**. Base 4-bit congelada + adaptadores entrenables en fp32/bf16. No hay que inventar
nada; hay que portarlo.

---

## 4 · Los 50.000 pasos: la unidad está mal

«50.000 pasos» no dice nada. Lo que se paga son **tokens**. Con `fwd+bwd ≈ 3×` y 3,2 B activos:

| pasos | tok/paso | B tokens | 1×T4 | **2×T4** | ¿Cabe en Kaggle? |
|---|---|---|---|---|---|
| 50.000 | 65.536 | 3,28 | 824 h | 412 h | **No: 2–3 meses de sesiones** |
| 50.000 | 8.192 | 0,41 | 103 h | 51,5 h | justo |
| **50.000** | **2.048** | **0,10** | 25,8 h | **12,9 h** | **sí, una semana** |
| 20.000 | 8.192 | 0,16 | 41,2 h | 20,6 h | sí |

**Propuesta:** 50.000 pasos con **T=2048** (12,9 h en 2×T4). El router aprende a *elegir*, y eso no necesita
contexto de 8k. Si luego hace falta comportamiento en contexto largo, se hace un tramo corto de ajuste
(2.000 pasos a T=8192) sobre el router ya maduro. **No al revés.**

---

## 5 · El punto jugoso no es solo el router

El router pesa **16,7 M params, 31,8 MiB, y consume el 0,83 % del cómputo**. Puntuar los 177 es
prácticamente gratis: no hay cuello ahí.

**Pero un router solo puede elegir; no puede hacer que se entiendan.** Si tus expertos son islas —
Nemotron con `relu2` e intermedia 1.856, Qwen con `silu` y 768, Phi-177 con 17.920—, elegir seis islas
distintas no las comunica. Obtienes **seis monólogos sumados**, que es exactamente lo que dijiste que no
querías.

Lo que crea colaboración son otras dos piezas, y son las que de verdad hay que entrenar:

| Pieza | Qué hace | Tamaño |
|---|---|---|
| **Router** | *a quién llamar* para este token | 16,7 M |
| **Proyecciones cruzadas** (por experto → espacio común) | *cómo se entiende* lo que dice cada uno | ~50–100 M |
| **Combine aprendido** (no media simple) | *cuánto pesa* cada voz, según el token | ~5–20 M |

El router aprende a convocar. **Las proyecciones aprenden a que se entiendan.** Sin las segundas, 177
activados son 177 monólogos — y con 177 *puntuados* + 6 ejecutados sigue habiendo colaboración real,
porque la comparten vía proyecciones. **Ese es el cambio que hace que tu filosofía sea implementable sin
que el cómputo explote.**

---

## 6 · Hipótesis tuyas que te cuestiono

| Hipótesis | Veredicto |
|---|---|
| «177 activos por token» | **Incompatible con 3,2 B/token.** Activar los 177 son 60,2 B y 112 GiB de lectura por token: imposible en T4, en 2×T4 y en tu portátil. La versión viable es *177 puntuados / 6 ejecutados*. |
| «Activar todos garantiza colaboración» | **Falso, y tú mismo lo dices.** Activar es condición de posibilidad, no de cooperación. |
| «El router es el punto jugoso» | **Es *un* punto jugoso, no el mayor.** Las proyecciones cruzadas pesan más en calidad. |
| «Hace falta LTUS/LEUS para Q4» | **Se llama QLoRA y ya existe.** Y Q4 no acelera: abarata memoria y encarece el paso. |
| «50.000 pasos» | **Unidad equivocada.** Son tokens. 50k×65k = 34 días; 50k×2048 = 13 h. |
| «Miku = experto 39» | **Cuidado.** En tu propia config, `[128]` es el **shared** y `[129..176]` son Qwen. El slot **39** cae dentro de los 128 Nemotron base. O «Miku» es otro experto, o la numeración no es la del manifiesto. **Verifícalo antes de nombrarlo en la doc.** |

---

## 7 · Riesgo que aparece en cuanto entrenas el router solo

Con los expertos congelados, el router tiene un atajo: **usar siempre los 5–10 que mejor puntúan**. Es el
colapso clásico de MoE, y con expertos heterogéneos es peor porque los grandes (Phi, 144,5 M) dominan en
capacidad. Si Phi entra sin la máscara de spans activa, el router aprenderá a abusar de él y te llevarás
el 96 % del presupuesto de cómputo en un experto.

**Gates obligatorios durante los 50k pasos:**
1. **Uso por experto** (histograma). Si >50 % de los slots caen en <10 expertos, hay colapso.
2. **Entropía del router**. Debe bajar *despacio*, no desplomarse.
3. **Load-balancing loss** con coeficiente pequeño (0,01), no cero.
4. **Máscara de spans de Phi activa desde el paso 0**, no después.

---

## 8 · Plan que propondría

| Fase | Qué | Coste | Gate de salida |
|---|---|---|---|
| **0** | Decidir denso vs top-6 y arreglar el config | 0 | una línea, pero cambia el modelo |
| **1** | QLoRA Q4, **solo router**, T=2048, 50k pasos, 2×T4 | **12,9 h** | entropía y uso por experto sanos |
| **2** | Añadir **proyecciones cruzadas** entrenables | ~×1,3 | loss baja sin colapso |
| **3** | Ajuste corto a T=8192 (2k pasos) | ~5 h | coherencia en contexto largo |

La fase 1 es lo más barato y de mayor retorno del proyecto entero: **16,7 M de parámetros que deciden cómo
se usa un modelo de 35 B**. Y cabe en una semana de Kaggle.

---

## 9 · Respuesta directa a tu pregunta

**¿Puede esto dar una mejora real a AI-ku?** Sí, y probablemente es la mejora con mejor relación
coste/efecto de todo el proyecto: es lo único grande que cabe en tu hardware y lo único que decide calidad
en un MoE. Pero con dos condiciones:

1. **El router solo no crea colaboración.** Sin proyecciones cruzadas entrenadas, tendrás 6 expertos
   ejecutando en paralelo, no una inteligencia colectiva. La fase 2 no es opcional si te tomas en serio tu
   propia filosofía.
2. **Q4 es para que quepa, no para que corra.** Y solo cabe en 2×T4. El portátil queda fuera de este
   entrenamiento: LEUS sirve para inferir, no para los 50k pasos.

Lo que haría mañana: resolver la fase 0 (una línea) y lanzar la fase 1 con T=2048. Trece horas después
tendrás la primera respuesta empírica a la pregunta que llevas meses haciendo en teoría.
