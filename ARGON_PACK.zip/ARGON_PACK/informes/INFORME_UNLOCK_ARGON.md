# INFORME · El «desbloqueo» de Argon: qué es real y qué no aplica
**Fecha:** 2026-09-11 · **Verificación:** `verificar_unlock.py` (a ejecutar en GPU)

---

## Nota de calendario, antes de nada

Iba a abrir diciendo que Argon se inventaba la fecha: cita `gpu-unlock` como «publicado a finales de
octubre de 2026» y hoy es 11 de septiembre. **Al buscar, las fuentes que encuentro están fechadas igual**:
24–26 de octubre y 4 de noviembre de 2026. O el índice va por delante, o la fecha del sistema va por detrás.
No lo uso como argumento: la física no depende del calendario.

---

## 1 · Lo que es REAL, y Argon acierta al traerlo

| Afirmación | Estado | Fuente |
|---|---|---|
| Existe `gpu-unlock` (Zagitta) y el fork `gpu-unlock-ada` (JustAResearcher) con payload de TOTORONG | **REAL** | repos públicos, GPL-2.0 |
| NVIDIA capa a la mitad los Tensor Cores en GeForce con acumulación FP32 | **REAL y documentado por NVIDIA** en whitepapers desde 2020 | 165,2 TF vs 330,3 TF en la 4090 |
| El desbloqueo es por selector de velocidad en firmware, **sin tocar el driver** | **REAL** (SS0 0x88888888 / SS1 0x8 + FLR antes de que cargue `nvidia.ko`) | README |
| `CudaNoStablePerfLimit` existe como perfil de aplicación de NVIDIA | **REAL** — añadido en driver **595.58.03** (marzo 2026) | notas de release |
| `CUDA - Force P2 State` (clave `0x166c5e`) desactivable | **REAL** — documentado por WiVRn para NVENC | WiVRn docs |
| Ganancia real en GEMM de cuBLAS ≪ la del pico | **REAL**: 1,12×–1,34× en GEMM 8192, no 2× | mediciones del propio fork |
| Decode LLM: **sin cambio** | **REAL**, lo dice el propio proyecto | README |

El hallazgo de fondo es bueno y es cierto. El «×2» es de **tasa de emisión de instrucciones**, no de
aplicación: el propio proyecto reconoce 12–34 % en cuBLAS real.

---

## 2 · Por qué NO toca a ninguna de nuestras dos GPUs

| GPU | ¿Afectada por el cap? | ¿Soportada por gpu-unlock? |
|---|---|---|
| **Tesla T4** (LTUS) | **No** — línea Tesla, no GeForce; da sus 65 TF con acumulación FP32 | No (y en Kaggle no hay control de arranque) |
| **GTX 1650 Mobile** (LEUS) | **No hay Tensor Cores que capar** (TU117) | **NO LISTADA** — el proyecto cubre TU106/TU104/TU102 de RTX 20 |
| RTX 5070 Ti | (Argon dice que sí) | **NOT SUPPORTED** — Blackwell fuera de alcance |

Argon acierta con la T4 y **falla con la 5070 Ti**: el README marca Blackwell como *not supported*.
Y no menciona que **la serie GTX 16 no está soportada**, que es justo la que tienes.

---

## 3 · El fallo grave: el flag que llama «desbloqueo» ya está encendido y no hace lo que dice

Argon propone `allow_fp16_reduced_precision_reduction = True` como «el desbloqueo de HFMA2/HMMA».
Dos problemas, uno de fuente primaria:

**a) Ya es `True` por defecto.** Lo dice PyTorch en el issue #123558:

> *«"high" (default): FP16 matmul uses FP32 as the computation accumulation mode. This aligns with setting
> `allow_fp16_reduced_precision_reduction` to True, **which is also the current default behavior**.»*

Poner a `True` lo que ya es `True` es una operación nula.

**b) No cambia el tipo de acumulación.** Issue #123157:

> *«Even if the user enabled `allowFP16ReductionCuBLAS`, the following call to `cublasGemmEx` will **still
> use FP32** as the accumulation mode (the second to last argument is always `CUDA_R_32F`).»*

El flag solo permite precisión reducida **en las reducciones split-K**, no en el acumulador principal.
Por eso Argon puede escribir «desbloquea las HFMA2» y no pasar nada: el camino ya era el rápido.

**c) El interruptor que sí existe es otro**, y va en dirección contraria a «sin perder nada»:
`torch.backends.cuda.matmul.allow_fp16_accumulation` (default `False`). PyTorch avisa en el mismo hilo:
*«a "pure" FP16 kernel using FP16 as the compute and accumulation type is not a good idea as convergence
issues were shown in the past»*. Con K=2688, acumular en FP16 es una decisión de precisión, no un free win.

**d) Y en la T4 no hay nada que ganar**: el `sm_75` de Turing no tiene el escalón 2× de Ada. La ficha de la
T4 da 65 TF **con acumulación FP32**. El «+18–28 % por ocupación de warps» no tiene mecanismo: la
ocupación la fija el kernel de cuBLAS, no un flag de PyTorch.

---

## 4 · El único hallazgo aplicable, y es gratis

**El P-State.** Es real, está documentado y sí puede dar algo — pero solo en el portátil:

- Se dispara cuando el driver fuerza **P2** al abrir un contexto CUDA, con la VRAM por debajo del máximo.
- `CudaNoStablePerfLimit` lo desactiva desde el driver **595.58.03**. Antes de esa versión, no existe.
- En Kaggle **no se puede tocar**: sin root, sin reinicio, y la T4 bajo carga sostenida ya está en P0.

`verificar_unlock.py` lo mide: calienta 200 GEMMs y compara `clocks.current.memory` con
`clocks.max.memory`. Si están a la par, no hay nada que desbloquear y el documento no aplica.

---

## 5 · Sobre «sin quemarla»

Ninguna de estas técnicas es overclock: no sube voltaje ni reloj por encima de fábrica. **El riesgo no es
térmico, es de arranque.** `gpu-unlock` hace una transacción de firmware + FLR **antes** de que cargue el
driver, exige **apagado en frío** y avisa de que un reinicio en caliente puede dejar la tarjeta como estaba.
En un portátil con GPU híbrida (Vega 7 + GTX 1650) eso es territorio de quedarse sin pantalla.

Y es **moot**: TU117 no está soportada.

---

## 6 · Qué haría yo

| # | Acción | Dónde | Riesgo |
|---|---|---|---|
| 1 | `python3 verificar_unlock.py` | Kaggle **y** portátil | **ninguno**, solo mide |
| 2 | Si el P-State sale frenado: probar `CudaNoStablePerfLimit` | portátil, Arch | bajo, es un perfil de app |
| 3 | Si `allow_fp16_accumulation` da >1,5× … | — | **no aplicarlo**: rompe «sin perder nada» |
| 4 | Descartar `gpu-unlock` para nuestras GPUs | — | — |

El paso 1 contesta todo en dos minutos y no modifica nada. El resto del documento de Argon, una vez
descontado el ruido, deja **una** línea aprovechable: el P-State del portátil.

---

## Lo que esto no cambia

Nuestro cuello de botella sigue donde estaba: **la sombra FP16 en la T4** (9,4× según la medición de Argon),
no un fusible que no existe en esa tarjeta. Y los números que decidieron la sesión anterior siguen igual:
`pin_borders` = 11,16 GiB, CURA-20 = 1,41 s/step, sonda de RAM pendiente.
