# INFORME · Ingeniería inversa de `gpu-unlock`: ¿se puede portar a T4 y GTX 1650?
**Fecha:** 2026-11-11 (según el reloj del servidor de GitHub) · **Repo:** `Zagitta/gpu-unlock`, 687 KiB, clonado en `/home/user/gpu-unlock`

---

## 0 · Corrección previa: Argon tenía razón con la fecha

Mi mensaje anterior abrió dudando de «finales de octubre de 2026». **Me equivocaba: la fecha del sistema que
me pasaron (11-sep-2026) va atrasada.** El propio GitHub respondió `date: Wed, 11 Nov 2026`. El proyecto es de
finales de octubre y hoy es noviembre. Argon no se inventó nada. Retiro la observación.

---

## 1 · Lo que hay de verdad en el código

No es un README con entusiasmo: es un módulo de kernel con la cadena completa.

| Pieza | Archivo | Contenido |
|---|---|---|
| Tabla de tarjetas | `kernel/gpu_unlock/recipes.c` | `cards[]` con `{device_id, chip_id, familia}` |
| Familia Turing | `recipes.c` | **`tu102` = «TU102/TU104/TU106»** |
| Payload Turing | `recipes.c` | `tu102_v67`: cadena de 6 escrituras con gadgets resueltos (score 1.0 en el fwmap) |
| Booter firmado | `recipes.h` | `booter_load_tu102.bin`, `sec2_bl_tu102.bin` |
| Firmware GSP | `recipes.h` | `gsp_tu10x.bin` — **un solo blob para la familia TU10x** |
| Registros | `registers.h` | `GU_TU102_FEAT_PLM_OFFSET 0x409650`, **`SS0 0x409664`**, **`SS1 0x40966c`**, `READOUT 0x409668` |
| Selectores | `registers.h` | `SS0_UNLOCK 0x88888888` (ocho campos de 4 bits) · `SS1_UNLOCK 0x8` |

Y el mapa de chips:

```c
#define TU102(id) { id, 0x162, &tu102 }   /* chip_id 0x162 */
#define TU104(id) { id, 0x164, &tu102 }   /* chip_id 0x164  ← el die de la T4 */
#define TU106(id) { id, 0x166, &tu102 }
```

Los device IDs TU104 soportados son **0x1e81/82/84/87/89/ec2/ec7** (RTX 2080 S, 2070 S, 2080, 2070).

---

## 2 · ¿Y la T4? Está a una línea… y no sirve de nada

**T4 = `10de:1eb8`, silicio TU104-895 (`chip_id 0x164`).** Es el **mismo die** que una RTX 2080, y ya está
en la familia `tu102`. Portarla sería literalmente añadir a `cards[]`:

```c
TU104(0x1eb8),   /* Tesla T4 — una línea */
```

Los registros caerían en la misma apertura (`0x409650`), el PLM y los selectores también.

**Pero no se hace, por tres razones que se acumulan:**

| Razón | Detalle |
|---|---|
| **No está capada** | Es línea Tesla/datacenter. NVIDIA no aplica el recorte de GeForce: da sus 65 TF **con acumulación FP32**. Desbloquear lo desbloqueado = 0 %. |
| **Kaggle no lo permite** | El módulo se carga **antes** que `nvidia.ko` desde el initramfs, exige root y apagado en frío. En Kaggle: sin root, sin initramfs, sin reinicio. |
| **El booter es por versión de driver** | `610.43.03`, fijo. La T4 de Kaggle corre otro. Habría que re-derivar los gadgets con `fwmap` para esa imagen. |

Veredicto T4: **portable en teoría, inútil en la práctica, imposible en Kaggle.** Y confirma lo del mensaje
anterior: si el proyecto, que sí soporta TU104, nunca incluyó la T4, es porque **no hay nada que desbloquear allí**.

---

## 3 · ¿Y la GTX 1650? Aquí no es una línea, es otro proyecto

**GTX 1650 Mobile = `10de:1f91` (TU117M).** No aparece en `cards[]`, y no es un olvido: falta **todo** lo que
hace falta para una familia nueva.

| Requisito | ¿Existe para TU117? |
|---|---|
| `chip_id` en la tabla (TU117 sería distinto de 0x162/0x164/0x166) | **No.** Habría que leer `PMC_BOOT_0` de tu tarjeta |
| Booter firmado `booter_load_tu117.bin` | **No.** El repo solo trae booters `_tu102`, `_ga100`, `_ga102`, `_ad102` |
| Firmware GSP | **No.** Solo `gsp_tu10x.bin`, que sirve a TU102/TU104/TU106. **TU117 queda fuera de esa familia** |
| Payload con gadgets | **No.** Los offsets del `tu102_v67` están atados al layout del booter firmado de TU102; para TU117 hay que **re-derivarlos** (el propio repo documenta que el port TU102→AD102 exigió remapear 4 gadgets y cambió el canario) |
| Apertura de registros FEAT | **Sin verificar.** Podría ser la misma, pero nadie lo ha comprobado en TU117 |

Y el remate: **TU117 no tiene Tensor Cores.** Aunque el port saliera perfecto al cuarto intento, el resultado
sería **0 TFLOPS ganados**, porque no hay nada que desbloquear. Es el mismo muro que ya te dije, ahora
confirmado leyendo el mecanismo: el desbloqueo escribe selectores de velocidad **de las unidades matriciales**.

Veredicto 1650: **meses de trabajo de firmware, con riesgo de dejar el portátil sin pantalla, para cero.**

---

## 4 · El detalle que sí vale la pena copiar (y por qué tampoco nos sirve)

El repo tiene un camino **de solo lectura**: `GU_TU102_FEAT_READOUT_OFFSET` (`0x409668`) con
`GU_SPEED_READOUT_MASK 0x07ffffff`. Permite comprobar si los selectores están a `0x88888888` (completo) o a
mitad, **sin escribir nada**. Es exactamente el tipo de sonda que me gusta: cero riesgo, respuesta binaria.

**Pero no la podemos usar:**
- En Kaggle: sin root y sin `/dev/mem` no se mapea BAR0.
- En el portátil: root sí hay, pero la 1650 no tiene Tensor Cores ⇒ leería un selector que no controla nada útil.

Aun así, deja una idea aprovechable para el futuro: **cualquier afirmación de «esto está capado» se zanja con
una lectura, no con un benchmark.** Es el mismo criterio que venimos usando.

---

## 5 · Un aviso del propio repo que sí importa para LEUS

> *«Laptops only stay unlocked if the dedicated GPU is never fully powered off. Many laptops power it down
> when idle, which silently resets the unlock.»*

Aunque el port funcionara, un portátil con GPU híbrida (Vega 7 + 1650) apaga la dGPU al estar ociosa y **el
desbloqueo se pierde en silencio**. Requeriría `NVreg_DynamicPowerManagement=0x00` — que a su vez sube el
consumo en reposo y la temperatura. Otro argumento para no intentarlo.

---

## 6 · Lo que sí sacamos de esta sesión

Ninguna cura para el motor, pero **tres certezas que cierran la puerta**:

1. **La T4 no está capada** — no es opinión: el proyecto soporta TU104 y aun así no la incluye.
2. **El «desbloqueo» es específico del die** (chip_id + booter firmado + GSP), no un flag universal. Por eso
   el argumento de Argon de «es el mismo `fmla32` que la 4090» no se sostiene: en Turing ni siquiera se llama así.
3. **TU117 no tiene unidades que desbloquear.** El techo de LEUS es 6,39 TF fp16 por CUDA cores, y ahí se queda.

Y la conclusión de siempre, ahora con el código delante: **nuestro cuello de botella sigue siendo la sombra
FP16 en la T4 (9,4× según Argon), `pin_borders` = 11,16 GiB, CURA-20 = 1,41 s/step y la sonda de RAM.**

---

## Anexo · Qué hay en el workspace

`/home/user/gpu-unlock` — clon superficial (687 KiB), GPL-2.0 + licencias MIT de NVIDIA. **No se ha
compilado, no se ha instalado y no se ha cargado nada.** Es lectura.
Si no lo quieres ocupando sitio, se borra con `rm -rf /home/user/gpu-unlock`.
