# INFORME · Auditoría de la Tabla 3 y fila 15 de Argon
**Fecha:** 2026-09-11 · **Motor:** `ltus0_autopista.py` md5 `30efd9c2…` (ISA 1.4-CASA-256)
**Método:** reproducir sus fórmulas con sus constantes y contrastarlas con el código real. Sin torch, sin GPU.
**Reproducible:** `python3 Argon/audit_tabla3.py` → `Argon/audit_tabla3.json`

---

## Veredicto en una línea

Su física del silicio es correcta y su aritmética del borde es correcta. **Sus dos puertas no pueden fallar
por construcción**, su tabla no sale de su simulador, y su `CURA-17` nos rompería el CE.

---

## 1 · Fila 15: 65 TF vs 21,2 TF — qué se sostiene

| Afirmación de Argon | Comprobación | Veredicto |
|---|---|---|
| Pico = 65 TF a 1590 MHz (`40 SM × 8 × 128 × GHz`) | Da **65,13 TF**. Coincide con ficha NVIDIA. | **CIERTO** |
| 21,2 TF = 32,6 % del pico | 21,2 / 65,13 = **32,6 %** exacto | **CIERTO** |
| BF16 cae a 2,25 TF (3,4 %) | 2,25 / 65,13 = **3,5 %**. Turing `sm_75` no tiene TC de BF16: PyTorch lo emula vía fp32. | **CIERTO** y da la razón a la sombra FP16 |

| Afirmación de Argon | Comprobación | Veredicto |
|---|---|---|
| ① Throttle 70 W baja 1590 → ~1260 MHz (−22 %) | A 1260 MHz el pico es 51,6 TF ⇒ 21,2 = **41,1 %** del pico *ya throttado*. El throttle explica ~14 de los 67,4 pp. | **CIERTO pero parcial** |
| ③ Wave quantization: "82 bloques, 2ª ola con 2 bloques en 1 SM" | La GEMM `[8192,2688]×[2688,17920]` con tiles 128×128 / 256×128 / 256×256 da **8960 / 4480 / 2240** bloques — todos múltiplos de 80. **Ninguna geometría da 82.** | **FALSO para esta GEMM** |
| Consecuencia: "dimensionar en múltiplos de 40 SMs" | Su propio simulador aplica `weff = 0,9882` ⇒ cuesta **1,2 %**, no explica la brecha. | **Consejo inofensivo, causa mal atribuida** |

**Lo que queda sin explicar son ~41 pp del pico throttado**, y ahí sí manda ② (memory-bound, RoPE, `segment_sum`, colas de HBM fuera de los 4 MiB de L2). Esa parte la clava; el orden de los factores no.

---

## 2 · Su tabla no la produce su simulador

Ejecutando `T4HardwareSimulator.simular_step_lteus` con sus propias constantes (`T=8192, K=8, fgl=18`):

| Escalón | `tok/s` en su Tabla 3 | `tok/s` de su simulador | Discrepancia |
|---|---|---|---|
| Baseline BF16, 1×T4 | 48,7 – 82,0 | **208,1** | tabla 2,5–4,3× **más pesimista** |
| LTEUS streaming, 1×T4 | 430 – 540 | **1.915,3** | tabla 3,5–4,5× **más pesimista** |
| Carrusel PEPS-D, 1×T4 | 610 – 760 | **1.916,9** | tabla 2,5–3,1× **más pesimista** |

La tabla está etiquetada `MODELADO / PREVISTO-PAPEL(P)` y dice reproducir el simulador. No es su salida.
Los números de la tabla son **más prudentes** que el modelo — o sea, alguien los corrigió a mano y no lo dice.
Prudencia bienvenida; trazabilidad no.

---

## 3 · Las dos puertas son constantes, no medidas

| Métrica | Cómo la calcula su código | ¿Puede fallar? |
|---|---|---|
| `GPU_busy_pct` (Gate 5 ≥ 90 %) | `t_wall = t_comp + t_exp + 0,065`. El único término ajeno al cómputo es **65 ms fijos**. | Solo si el step baja de **0,585 s**. Con `t_comp = 1 s` aún da 48 %, pero con cualquier step realista da **99,6–99,97 %**. No falsable. |
| `overlap_pct` (Gate 1 ≥ 70 %) | Si `t_h2d ≤ t_comp`, fija `t_exp = t_h2d / 52`. Entonces `overlap = 1 − 1/52`. | **Nunca.** Da **98,08 %** siempre, para cualquier `T`, `K`, lookahead o número de GPUs. |
| Tabla: 94,8 % y 99,2 % | No salen de esa fórmula (que solo produce 98,08 % o 100 %). | Sin origen trazable. |

Una puerta que no puede suspender no es una puerta: es decoración. **Gate 1 y Gate 5 hay que redefinirlos** con
los términos que sí varían (solape real medido con eventos por carril, y ocupación SM vía `ncu`/`CUPTI`).

---

## 4 · Su CURA-17 nos rompe el CE (rechazada)

Su helper `ce_step_con_shift_causal_cura17` desplaza `h[:, :-1]` / `labels[:, 1:]` **antes** de llamar a
`ce_loss_chunked`. En nuestro motor el shift ya está **dentro** de `_CEChunkFn` (CURA-18) y el docstring lo dice:

> *"Entrada: h de la capa superior [T,H] y labels [T] EN EL MISMO ÍNDICE (el shift se aplica DENTRO, CURA-18).
> El caller NO debe desplazar nada."*

Adoptarlo = **doble shift** = predecir `t−1` desde `t`. Cambiar un bug de identidad por un bug de retardo.
Su diagnóstico del bug original era correcto — llegó nueve curas tarde y a un fichero que ya no existe
(cita `81bf707e…`; el nuestro es `30efd9c2…`).

---

## 5 · Su CURA-18 (= nuestra R13): diagnóstico y aritmética correctos

| Magnitud | Cálculo | Argon | Veredicto |
|---|---|---|---|
| Un borde `(8192, 2688)` fp16 | 44.040.192 B = **42,00 MiB** | — | — |
| Copia H2D a 8,5 GB/s | **5,18 ms** | 5,2 ms | **CIERTO** |
| Copias por step | 34 capas (≥ `fgl=18`) × 8 micros = **272** | — | — |
| Coste serializado | 272 × 5,18 ms = **1,41 s/step** | 1,43 s | **CIERTO** |

Yo había estimado 52 capas y 2,15 s: **me equivoqué, el correcto es Argon.** `pin_borders` solo existe para
`l ≥ fgl` (34 capas). Crédito entero.

Y el test de holgura confirma que la cura es rentable: mover esa subida a `s_h2d` necesita solo
**0,351 GB/s** de media sobre un bus de 8,5 GB/s ⇒ **4,1 % de uso, margen 15×**. Se oculta entero.

---

## 6 · Lo que ninguno de los dos vio (**bloqueante**)

`LTUSAutopistaArena.__init__` reserva `pin_borders` para **todas** las capas ≥ `fgl`:

```python
self.pin_borders = {l: [torch.empty((T, H), dtype=torch.float16, pin_memory=True)
                        for _ in range(n_micros)] for l in range(self.fgl, self.n_layers)}
```

**Objetivo real: Kaggle** (corrección del usuario, 11-sep). El host Arch **no** es el destino de compilación;
el presupuesto se cierra contra la RAM de la sesión de Kaggle, y **esa cifra no está medida**.

| Concepto | Cifra |
|---|---|
| 34 capas × 8 micros × 42,00 MiB | **11,16 GiB de RAM pinned** |
| RAM de la sesión de Kaggle | **SIN MEDIR** — medir con `sonda_ram_kaggle.py` (bloqueante) |
| Si el borde se guarda en fp8 e4m3 | 5,58 GiB |
| Si el borde se guarda en fp4 | 2,79 GiB |

Esto no lo puede resolver la aritmética: **depende de la cuota real del contenedor de Kaggle**, que no
conocemos. Si la sesión da menos de ~11,2 GiB utilizables, revienta en la reserva y antes del step 1. Y explica
por qué nadie lo ha visto: el arnés en seco no construye la arena (`verificar_ltus.py` prueba la lógica, no la reserva).
La sonda `sonda_ram_kaggle.py` mide además `memory.max` del cgroup y `RLIMIT_MEMLOCK`, que son los dos sitios
donde una reserva pinned grande falla con un "out of memory" sin más pista.

**Tráfico real por step** (corrige la Tabla 3):

| Flujo | GB/step |
|---|---|
| Pesos (lo que declara la Tabla 3) | 12,85 |
| Borde H2D (34 × 8 × 42 MiB) | 11,98 |
| Borde D2H (ya va en `s_d2h`) | 11,98 |
| **Total PCIe** | **36,81 GB/step** (2,9× lo declarado) |

---

## Curas propuestas

| # | Cura | Riesgo | Estado |
|---|---|---|---|
| **CURA-20** | Mover `recomp_in.copy_(pin_borders)` de `s_comp` a `s_h2d` con doble buffer de frontera (R13 / su CURA-18) | medio (tape) | **pendiente de tu OK** |
| **CURA-21** | `pin_borders` en **fp8 e4m3** o ventana deslizante de sólo `lookahead` capas | medio | **bloqueada por la sonda de Kaggle** |
| **CURA-22** | Sustituir `GPU_busy` / `overlap` por métricas falsables (eventos por carril + `CUPTI`) | bajo | propuesta |
| — | Su CURA-17 (doble shift) | — | **RECHAZADA** |
| — | `V4X_SPLIT_LAYER = 31` | — | **sin dato**; su árbol es `_3`, no el nuestro |

---

## Límite declarado

Todo esto es aritmética sobre el código, no medición. **No prueba** tok/s, VRAM real, PCIe ni solape.
`208` y `1.915 tok/s` son la salida de *su* modelo, no una predicción mía: sirven para auditar su tabla, no
para presupuestar. Nada se ha ejecutado en GPU.
