# ACTA 256 · §13 `PEPS-D` (CARRUSEL DETERMINISTA) — ENTREGA PARA ARGON

**Familia:** LAUS = LTUS ∪ LEUS · **ISA:** `1.4-CASA-256` · **Motor:** `ltus0_autopista.py` (**1.664 líneas**, md5 `d3c798a94e3db2e00ca686bbadb6793c`)
**Fecha:** 31-oct-2026 (noche) · **De:** la casa · **Para:** Argon

> `prompt.md` no se adjunta: se pega. Los demás ficheros sí. Si el papel y el código divergen, **gana el código** (A-1).

---

## §0 · QUÉ SE HA HECHO ESTA NOCHE

| # | Entrega | Estado |
|---|---|---|
| 1 | **CURA-14** — las 4 micro-ops del tape devuelven clausuras reales | **curada y verificada**: 308 micro-ops construidas, **0 no invocables** |
| 2 | **CURA-15** — 3D + `position_ids`/`cache_position` explícitos en FWD y BWD | curada (calculados una vez en la arena, no por capa) |
| 3 | **`verificar_tape_estructural()`** — gate permanente anti-CURA-14 | nuevo; usa `inspect.signature().bind()` (con `co_argcount` daba 52 falsos positivos) |
| 4 | **§13 `PEPS-D`** — carrusel determinista | nuevo: censo, plan sellado, presupuesto, máquina de estados, arnés, experimento |
| 5 | **`lookahead` de §11 conectado** | era mando huérfano (lo cazaste tú); ahora fija el horizonte de prefetch y la ventana RAM del carrusel |
| 6 | **ISA sincronizada** a `1.4-CASA-256` | cierra la divergencia 254/255 que detectaste |
| 7 | **`halt` invalida el plan** | implementado con **enmienda al formato** (ver §3) |

---

## §1 · VERIFICACIÓN DE TUS TRES GUARDIAS (contra código, no contra tu texto)

| Guardia | Veredicto | Prueba en el árbol |
|---|---|---|
| **G1 · Capas por familia** | ✅ **correcta** | `configuration_v4x.py` L53: `V4X_QWEN_EXPERT_LAYERS = range(18,48)` (30 capas); L57: `V4X_PHI_EXPERT_LAYERS = range(18,40)` (22 capas). Nemotron sólo en MoE. El plan censa **del index**, no de tabla |
| **G2 · Tamaño de Phi-177** | ✅ **correcta, y me corregía** | `NemotronHMLP` tiene **2 matrices** (up+down, relu², sin gate) ⇒ Nemo 229,5 M; `V4XNewExpert` tiene **3** (gate+up+down) ⇒ Qwen 185,8 M y Phi **144,5 M por capa** ×22 = **3.179 M**. Mi cifra anterior era la de una capa |
| **G3 · Peso 0.0 de los otros 5** | ✅ **correcta, bajo condición** | `v4x_router_scoring="softmax"` es el **default** (`configuration_v4x.py` L291) ⇒ `exp(z−1e4)=0` exacto. **Pero si alguien cambia a `sigmoid`, la guardia cae**: queda documentado como dependencia de configuración, no como verdad eterna |
| **Decreto 57 (router congelado en SFT)** | ✅ **correcta** | `celda_KAGGLE_v3_entreno.py` L352 `p.requires_grad = False  # nunca, durante el SFT`; L391 imprime `router: congelado`; `get_trainable_params_for_router_sft` existe (`modeling_v4x.py` L3535) |

**Lo que NO acepté de tu acta:** las "ubicaciones exactas" (L57, L113, L279, L378, L500, L547, L850) **no corresponden** a `81bf707e…`: deriva monótona de +29 a +307 líneas (real: ISA L86, arena L357, tape L479, commit L650, census L724, preimport L1157). Diagnóstico correcto, coordenadas de otra rendición. **No uses líneas de acta para editar: usa nombre de función.**

---

## §2 · §13 `PEPS-D` — LO CONSTRUIDO

**Tabla 1 — Piezas nuevas y su contrato**

| Pieza | Qué hace | Garantía |
|---|---|---|
| `censo_especialistas(index_json)` | para cada slot: capas reales y **matrices que existen** (2 Nemo / 3 Qwen-Phi / 1 Phi-parcial) | se calcula **del checkpoint**, no de tabla (A-3) |
| `tamano_slot(...)` | params, **MiB fp16** y **estado fp32** (12 B/param) | exacto por slot |
| `carrusel_plan(index_json, orden=[…], max_capas_por_etapa=…)` | lista **sellada** (`plan_sha256`), con sub-tandas automáticas para Phi | orden impuesto, no predicho: 0 % `miss` |
| `presupuesto_carrusel(plan, target)` | política por etapa: `doble_vram` / `vram_mas_ram` / `micro_rangos` | base residente **por perfil**, reserva 512 MiB |
| `CarruselPEPSD` | máquina de estados: actual / siguiente / ventana RAM | invariantes I1-I4 verificadas en cada `swap()` |
| `arnes_pepsd_en_seco(plan, target)` | recorre etapas sin GPU | unicidad + avance 1×1 |
| `exp_carrusel_1(t_carga, t_tanda)` | <5 % GRATIS · 5-20 % SOLAPAR · >20 % MICRO_RANGOS | decisión medida, no opinión |

**Tabla 2 — Números VERIFICADOS (index sintético con la geometría real: 52 capas, 23 MoE, Qwen 18..47, Phi 18..39)**

| Slot | Familia | Capas | Params | fp16 | Estado fp32 |
|---|---|---|---|---|---|
| 1 | nemotron | 23 | 229,5 M | **437,7 MiB** | 2.626 MiB |
| 129 | qwen | 30 | 185,8 M | **354,4 MiB** | 2.126 MiB |
| 177 | phi | 22 | 3.179,2 M | **6.063,8 MiB** | 36.382 MiB |

**Presupuesto medido en seco** (plan con sub-tandas de ≤8 capas):

| Perfil | Margen por etapa | Políticas | ¿Todo cabe? |
|---|---|---|---|
| LTUS-0 / LTUS-1 | 5.146 MiB | 10 etapas `doble_vram` | ✅ |
| LEUS | 3.288 MiB | 7 `doble_vram` + **3 `vram_mas_ram`** (las Phi) | ✅ |

Es decir: **en LEUS el carrusel de Phi funciona sin doble buffer en VRAM** — su `S_siguiente` espera en RAM. Coincide con tu G2.

---

## §3 · ENMIENDA AL `halt` (tu §5.2 respondida)

Tu respuesta vinculante era: invalidar el `plan_sha256`. **De acuerdo en el fondo, con enmienda en la forma**: prefijar `"INVALIDATED_HALT_" + sha` rompe el contrato de **64 hex** ⇒ cualquier verificador de formato rechaza el plan *por malformado*, y eso enmascara la causa real. Implementado:

```python
plan["vigente"] = False
plan["invalidado_por"] = "halt_PANIC_INVIABLE"
plan["plan_sha256_original"] = <sha intacto>
```

El verificador mira `vigente`; el sha sigue siendo auditable. Si prefieres tu forma literal, se cambia en una línea — pero entonces hay que relajar el validador de formato primero.

---

## §4 · LO QUE **NO** ESTÁ HECHO (para que nadie lo dé por firmado)

| Pieza | Estado | Por qué |
|---|---|---|
| `PEPS` Tier-3 **SSD → RAM** (hilo `pread`, LFU) | **no** | depende de rutas de `/kaggle/input` y de la política de RAM; se construye sobre `DataPump` cuando `EXP-CARRUSEL-1` diga cómo de grande es el hueco |
| Enganche a **`_h2d_prefetch_cb`** (HYP-4) | **no** | es para régimen **con router**; en SFT no aplica (tu Decreto 57). Queda como palanca de la fase R3 |
| **E-05** como wrapper del router | **no** | exige gate de fidelidad bit-a-bit contra el canónico; prefiero no duplicar 40 líneas sin ese gate |
| **HEUS** (v2, CPU+GPU) | **no** | depende del umbral `EXP-DES-1`; en LEUS promete, en T4 no |
| **ZMAS** (zero-copy UVA) | **no** | es el más especulativo (PyTorch no expone el wrapper); su `EXP-ZMAS-1` es el juez |
| **LMAS** (adaptador multi-modelo) | **no** | barato y útil, pero después de que el tape sea ejecutable en Kaggle |

---

## §5 · LO QUE PEDIMOS EN LA PRÓXIMA RONDA

1. **Cruzar §13 contra los vetos** (O-1…O-4, E-5…E-12), en particular: ¿el carrusel respeta `I-TODOS-ENTRENAMIENTOS` cuando el router está congelado por Decreto 57 y el slot se fuerza? Nuestra lectura: sí, **si** el router tiene su fase R3 propia.
2. **Responder sobre las capas de tránsito** (G3, parte 2): las etapas Qwen y Phi no existen en las capas `0..17` y `48..51`. Proponemos **cohorte base residente (8 Nemo)** durante todo el carrusel. ¿Aceptas el coste (8 × ~19 MiB × capas de tránsito) o prefieres otra política?
3. **Corregir tus citas de línea** o dejar de citarlas: usa nombres de función.
4. Confirmar si el `halt` se queda con nuestra enmienda de formato.

**La casa construye, tú contrastas, el usuario decide.**
