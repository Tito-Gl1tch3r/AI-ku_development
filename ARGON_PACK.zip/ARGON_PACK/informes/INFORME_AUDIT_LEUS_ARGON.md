# INFORME · Auditoría del motor LEUS de Argon (TU117 / Ryzen 5 5600H)
**Fecha:** 2026-09-11 · **Método:** reimplementar sus costes en numpy y ejecutarlos. Sin torch, sin GPU.
**Reproducible:** `python3 Argon/audit_leus.py` → `Argon/audit_leus.json`

---

## Veredicto en una línea

La física de hardware está bien cazada y el análisis CPU-vs-PCIe es **correcto y valioso**. Pero el
componente que da nombre al invento —el Transporte Óptimo— **es código muerto que nunca dispara, y cuando
lo haría empuja en dirección contraria a la tesis del propio documento**.

---

## 0 · Corrección mía, antes de auditar nada

En mi mensaje anterior dije que la 1650 Mobile tenía **896 núcleos y 2,98 TF**. **Estaba mal.** Ese es el chip
de **escritorio**. La variante **Mobile es TU117M con 1024 shaders / 16 SMs**:

| | Escritorio GTX 1650 | **Mobile GTX 1650** | Argon dice |
|---|---|---|---|
| Shaders / SMs | 896 / 14 | **1024 / 16** | 1024 / 16 ✓ |
| fp32 (1,56 GHz) | 2,79 TF | **3,19 TF** | 3,19 TF ✓ |
| fp16 (HFMA2 2:1) | 5,59 TF | **6,39 TF** | 6,39 TF ✓ |
| L2 | 1 MiB | 1 MiB | 1 MiB ✓ |

Argon acierta; yo usé la ficha equivocada. Y su `is_tu117` (≤16 SMs) es correcto como heurística.
Lo que **sí** sigue en pie de mi aviso: sin Tensor Cores, el multiplicador fp16/fp32 es **≈2×, no ≈9,4×**.

---

## 1 · Lo que es cierto, y es mucho

| Afirmación | Comprobación | Veredicto |
|---|---|---|
| TU117 sin Tensor Cores; fp16 por `HFMA2` a 2× fp32 | Correcto: `sm_75` ≠ tensor cores. `sm_75` es arquitectura, no dotación | **CIERTO** |
| Qwen experto c=1: CPU **6,28×** más rápida que DMA | Reproducido: 2,069 ms DMA vs 0,329 ms CPU = **6,29×** | **CIERTO** |
| Nemotron: 6,21× · Phi: 6,32× | Reproducido: 6,29× y 6,34× | **CIERTO** |
| Punto de cruce `c* = P_cpu(1/BW_pcie + 1/BW_gddr6) ≈ 51` | Fórmula bien derivada; **`P_i` se cancela** ⇒ c* independiente del tamaño del experto. Reproducido | **CIERTO y elegante** |
| El `c*` es lo que decide arquitectura | Con `c ≤ 51` gana CPU; con `c > 51` gana GPU. La cuenta del Paper es **la única del documento que merece un paper** | **CIERTO** |
| Presupuesto VRAM **3.685 MiB ≤ 3.800** | Suma de sus 5 partidas: 561+1030+829+145+1120 = **3.685** exacto | **CIERTO** |
| KV cache **6 KiB/token** | 6 capas × 2 KV heads × 128 dim × 2 B × 2 (K,V) = **6.144 B** ✓ | **CIERTO** |
| PCIe 3.0 **x8** no x16 | El chip es x16-capaz; el enlace negociado lo dice `nvidia-smi`. Cezanne da 16 carriles (fuentes discrepan: 12 vs 16) ⇒ **plausible, medible** | **por medir** |
| 16 MiB L3 aloja un experto Qwen (11,81 MiB) | Aritmética ✓. Pero la L3 es compartida con todo el SO | **CIERTO con asterisco** |

El hallazgo «la RAM de CPU es 6,1× más rápida que el bus PCIe» es real, y convierte a la 1650 en algo que
**no es una T4 pequeña**: es una máquina con 6 GB/s de bus y 38 GB/s de RAM, donde el reparto CPU/GPU es una
decisión de arquitectura y no un remedio.

---

## 2 · Lo que se cae: el Transporte Óptimo es código muerto

Reproduje su `LEUSOptimalTransportScheduler` con su escenario decode. Matriz de coste (ms):

| experto | VRAM | DMA | CPU |
|---|---|---|---|
| 12 (Nemo, residente) | 0,138 | 0,138 | 0,526 |
| 130 (Qwen, residente) | 0,089 | 0,089 | 0,329 |
| 45 (Nemo, RAM) | 1e6 | 3,320 | 0,526 |
| 88 (Nemo, RAM) | 1e6 | 3,320 | 0,526 |
| 141 (Qwen, RAM) | 1e6 | 2,069 | 0,329 |
| 177 (Phi, RAM) | 1e6 | 47,782 | 7,533 |

**a) El centinela enmascara VRAM, pero no distingue DMA de CPU.** `C/max(1e4)` deja las columnas DMA y CPU
en `exp(−1e−3) ≈ 1`. El ratio `K_DMA/K_CPU` va de **0,984 a 1,0002**: el OT no ve diferencia entre ejecutar
en CPU y traer por PCIe — que es exactamente la única decisión que debía tomar.

**b) El marginal `v_target` es ruido.** `inv_cost` por columna sale `[18,5 · 19,6 · 11,9]`, y **18,5 de los
18,5 de la columna VRAM los aportan los dos residentes baratos** (1/0,138 + 1/0,089). La «capacidad» de un
destino la fija el experto más rápido, no cuántos caben. Se normaliza a `v_target = [0,370 · 0,392 · 0,238]`.

**c) Y con eso, el término del OT nunca dispara.**

```python
if finish_if_cpu <= finish_if_dma or (P_ot[idx, 2] > P_ot[idx, 1] and c <= 32):
```

`P_ot[:, CPU] > P_ot[:, DMA]` es cierto en **0 de 6 filas**, precisamente porque `v_target[DMA] > v_target[CPU]`.
El segundo término es **siempre `False`** ⇒ la condición equivale a `finish_if_cpu <= finish_if_dma`.

- El reparto real es **greedy LPT** (asignar al destino que antes queda libre). Eso es **buena ingeniería**.
- Pero **no es transporte óptimo**, y el umbral `c <= 32` está **escrito a mano**: no sale de ninguna matriz.
- Peor: la dirección que el OT *empujaría* (DMA) es la **contraria** a la tesis del documento («la CPU gana con c ≤ 32»).

**d) Arreglarlo no salva el OT en este régimen.** Con enmascarado limpio (`NaN` en vez de `1e6`), `v_target`
sigue siendo una media **por columna**: la agregación de Sinkhorn borra la fila y se queda la columna.
Con `M ≤ 6` y 3 destinos, Sinkhorn no aporta nada que el greedy no dé. Empezaría a aportar con `M` grande
(prefill denso) **y** topes de capacidad reales por destino — que hoy no existen en el modelo.

**Coste de oportunidad:** ~120 líneas, un hiperparámetro `ε` sin calibrar y una dependencia conceptual que
hay que defender en cada revisión. Sustituirlo por greedy LPT + el `c*` analítico da **el mismo reparto** con
un tercio del código. Yo lo tiraría.

---

## 3 · Lo que falta y no es cosmético

| Carencia | Por qué importa |
|---|---|
| **`sched_setaffinity` prometido y NO implementado** | El doc dedica un párrafo a «anclar a 4-5 núcleos físicos con `sched_setaffinity`» y la tabla lo lista como decisión. El código solo hace `torch.set_num_threads(5)`. En Linux eso **no fija afinidad**: el planificador reparte los 5 hilos por los 12 CPUs lógicos, y dos pueden caer en los hyperthreads del mismo núcleo — exactamente el fallo que el documento advierte. Es media línea: `os.sched_setaffinity(0, cpus_fisicos)`. |
| **No se mide el número de canales DDR4** | Argon asume 38,4 GB/s (dual-channel real). Si el equipo lleva **1×16 GB**, son ~19 GB/s y **el 6,28× se queda en 3,14×**. `/proc/meminfo` **no** dice canales. Hace falta `dmidecode -t 17` o `lshw -c memory`. Es la medición que decide si el invento es 6× o 3×. |
| **`os.cpu_count()`** | Devuelve CPUs del host, no del cgroup. En contenedor miente. Usar `len(os.sched_getaffinity(0))`. |
| **El techo por token no está calculado** | Su tabla compara **por capa**. La cifra que decide si LEUS sirve para interactivo es por **token**: ver abajo. |
| **«modo TCC»** | La GTX 1650 Mobile no tiene TCC (es exclusivo de Tesla/Quadro en Windows). Metáfora aceptable, pero no es una capacidad. |

---

## 4 · El número que su documento no da: techo de decode

Con su propio presupuesto de VRAM (tronco residente 2.420 MiB a 158 GB/s):

| Escenario | makespan/capa | 35 capas ⇒ tok/s |
|---|---|---|
| **Techo del tronco solo** (leer 2.420 MiB/token) | 16,06 ms | **62,3 tok/s** |
| Decode sin Phi-177 | 1,382 ms | **20,7 tok/s** |
| Decode con Phi en las 22 capas donde existe | 190,9 ms | **5,24 tok/s** |
| Decode con Phi en todas (peor caso) | 275,2 ms | **3,63 tok/s** |

**Ese es el titular real del LEUS: entre 5 y 20 tok/s en decode, con techo físico 62.** No es una locura —
es un banco de trabajo local honesto para un 35B con 3,8 GiB de VRAM. Y la cifra que lo decide no es el OT:
es **cuántas capas activan Phi-177** y si la máscara de spans lo mantiene fuera del camino caliente.

Corolario que sí es accionable: **si Phi-177 entra en el bloque de pensamiento de todas las capas, el sistema
cae a 3,6 tok/s por culpa de un solo experto**. La palanca no está en el planificador, está en la máscara
de spans y en la política de caché LFU.

---

## 5 · Qué hacer, en orden

| # | Acción | Coste | Retorno |
|---|---|---|---|
| 1 | `os.sched_setaffinity` a núcleos físicos reales (leer `thread_siblings_list`) | 10 min | cierra la contradicción del doc |
| 2 | Medir canales DDR4 (`dmidecode -t 17`) | 2 min | decide 6× vs 3× |
| 3 | Medir `pcie.link.width.current` y `current_link_speed` | 2 min | x8 vs x16 = 2× |
| 4 | Sustituir Sinkhorn por greedy LPT + `c*` analítico | −120 líneas | mismo reparto, menos deuda |
| 5 | Calcular tok/s por token, no por capa | 20 min | la cifra que decide el proyecto |
| 6 | Perfilar cuántas capas activan Phi en decode real | depende de datos | 5,2 → ? tok/s |

---

## Límite declarado

Todo lo anterior son **sus fórmulas ejecutadas**, no mediciones. **No prueba** GFLOPS reales, GB/s de PCIe,
canales de RAM ni tok/s. Sus 6,39 TF son de ficha: la máquina dará menos, y el boost depende de la SKU
(1493–1560 MHz). Nada se ha ejecutado en la GTX 1650.
