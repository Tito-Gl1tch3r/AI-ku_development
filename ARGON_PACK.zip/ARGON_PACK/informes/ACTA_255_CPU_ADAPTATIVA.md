# ACTA 255 · LTUS ADAPTATIVA A LA CPU (y controlador de régimen) — ESTADO PARA ARGON

**Familia:** LAUS = *Language Accelerator Unit Software* = **LTUS ∪ LEUS**
**ISA:** `1.3-CASA-255` · **Motor:** `ltus0_autopista.py` (1.334 líneas) · **Fecha:** acta 255
**Para:** Argon · **De:** la casa

> **Cómo usar esta carpeta:** `prompt.md` **no se adjunta** — se pega en el chat. Los demás ficheros se adjuntan. Todo md5 es literal del árbol; si el papel y el código divergen, **gana el código** (A-1). Esta acta sustituye a la 253.

---

## §0 · MANIFIESTO (10 ficheros + prompt)

| # | Fichero | md5 literal | Por qué lo tienes |
|---|---|---|---|
| 01 | `celda_GATE0_IFA_BIZONAL.py` | `fa3731efa01409cc681e28b890acfedb` | celda operativa viva: CURA-1…CURA-13 |
| 02 | `ltus0_autopista.py` | `81bf707e9ee8c4abd90195ed4a89b625` | **el software**: familia LAUS + controlador adaptativo (§11) |
| 03 | `modeling_v4x.py` | `4192b002a5c7397abbb2a15ad8df0b28` | canónico, sin cambios |
| 04 | `configuration_v4x.py` | `1c81ac67e0667a3f92386d71b92f7b76` | canónico, sin cambios |
| 05 | `acel_BF16_TURING.py` | `62afdd4594c893a09a4f3bbfcdf0f26a` | canónico, sin cambios |
| 06 | `celda_KAGGLE_v3_entreno.py` | `621611c1ecbaff122a43716eb2d2ca2b` | canónico: entreno v3 |
| 07 | `celda_P0_microbench.py` | `37c47645a4412e789d63c8d330e562d6` | microbench P0 (EXP-H1/H3) |
| 08 | `mini_MANIF_audit_v8.py` | `3578ff91a6cf64a15fb898120ac71ec6` | auditoría de manifiestos/censos |
| 09 | `LAB_CASA_TACHYON_OMEGA_COMPLETO.md` | `38887e53d2f0b53f00ccf1c3492694f4` | contexto del laboratorio |
| 10 | `ACTA_255_CPU_ADAPTATIVA.md` | *(este documento)* | estado + curas + controlador |
| — | `prompt.md` | *(no se adjunta: se pega)* | prompt de la ronda, con las ideas del usuario al final |

*Tabla 1 de 3.* Históricos en `_archivo/` (no se adjunta): `CAMBIOS_27SEP.md`, `celda_SESION1_v141.py` y el resto de material superado.

---

## §1 · DECRETO DE NOMBRE (acta 253, vigente)

**La S es por Software.** Regla universal y retroactiva; si es software, lleva S.

- **LAUS** = *Language Accelerator Unit Software* = **LTUS ∪ LEUS**. Es la **familia** y **no compila**: un plan se sella siempre contra un destino concreto. `target="LAUS"` aborta con error pedagógico.
- **LTUS** = acelerador de **ENTRENAMIENTO**: destinos `LTUS-0` (1×T4, 14.500 MiB, T≤8192) y `LTUS-1` (2×T4, 29.000 MiB, T≤8192, **defecto**).
- **LEUS** = banco local de **CALIBRACIÓN/inferencia**: destino `LEUS` (1×GTX 1650, 3.800 MiB, T≤1024).

En código: `LTUS_TARGETS`, `LAUS`, `laus_resumen()`, `validar_plan_en_toda_la_familia()`, `LAUS_TARGETS_CONCRETOS`, con `assert` de coherencia en import.

---

## §2 · LO NUEVO: §11 CONTROLADOR ADAPTATIVO AGRESIVO (decreto del usuario, acta 254)

**El argumento del usuario, que sostiene todo el diseño:** *"la CPU sólo se usa para entrenar"* — luego la inteligencia de control vive **entera en el host** y puede ser todo lo lista que queramos (<1% de CPU) sin robar un microsegundo de GPU. Una partitura fija es una máquina de estados **sin realimentación**; §11 le mete realimentación.

**Tres primitivas de circuito contra los tres peligros clásicos** (el usuario viene de un 10 en puertas lógicas; el marco es suyo):

1. **Histéresis** — entrar en STARVED exige `busy<88%`, salir exige `busy>92%`. Sin ella, el estado vibra en el umbral.
2. **Dwell** — 3 pasos de asentamiento antes de volver a tocar la misma perilla.
3. **Reserva (rail)** — margen duro de 512 MiB que **ninguna** acción puede invadir.

**Reglas de agresividad:** cambios **multiplicativos** (×1,5 / ×0,63), **una perilla por paso**, prioridad fija, y **memoria de regímenes**: si ya midió un régimen mejor que quepa, **salta a él** en vez de subir de uno en uno (`SALTO_A_REGIMEN`). Agresiva ≠ caótica.

| Estado | Se dispara cuando | Acción agresiva |
|---|---|---|
| `CRUISE` | busy≥88%, VRAM bajo techo | salto al mejor régimen medido; si no hay, sonda K (×1,5) con reserva |
| `STARVED` | busy<88% o `t_data_wait>1 ms` | lookahead ×2 (máx 8); si cabe, K ×1,5 |
| `CHOKED` | pico>techo o frag>1 GiB | K ×0,63 → ce_chunk/2 → lookahead/2 (en ese orden) |
| `PANIC` | OOM o free<256 MiB | drenaje total: K=1, lookahead=1, ce_chunk/2 |

**Dos salvaguardas que el banco en seco obligó a añadir** (bugs cazados **antes** de Kaggle):

- **Estimador de coste marginal**: la predicción de pico ya no es un `+25%` ciego; se **mide** `ΔMiB/ΔK` con dos puntos y se predice con él (+64 MiB de colchón). En el banco converge a `180.0 MiB/K` exactos.
- **Escalera de PANIC**: si tras drenar a `(K=1, lookahead=1, ce_chunk=128)` el OOM persiste, el controlador **declara INVIABLE y se detiene** (`halt`). No repite el mismo grito: eso sería vibrar, no diagnosticar.

**Lo que §11 NUNCA hace** (cruces con los decretos vigentes):
- **No sincroniza dentro del step** (AF-04): lee contadores en **fronteras** de paso; `mem_get_info` cada 5 pasos.
- **No cambia el plan a mitad de step**: las acciones se aplican en la frontera y **cada régimen se sella** con su `plan_sha256` → **linaje** auditable (DF-04). `linaje(plan_base)` devuelve un plan por régimen tocado.
- **No oculta cambios numéricos**: K/lookahead/ce_chunk alteran el orden de reducciones en coma flotante; por eso la paridad bit-a-bit (GATE-3) sólo se predica **dentro del mismo régimen**.

### §2.1 · Resultados del banco en seco (sin GPU; reproducible con `--sim-control`)

| Escenario | Inicio | Final | tok/s | Acciones | Oscilaciones |
|---|---|---|---|---|---|
| A · T4 sola (base 8.600 MiB, cap 14.500) | K=1, look=2 | K=28, look=4 | 199 → **2.244** (11,2×) | 9 | 0 |
| B · T4 + torre residente +900 MiB en paso 10 | K=1, look=2 | K=19, look=4 | 199 → **1.918** | 8 | 0 |
| C · LEUS factible (base 1.800, cap 3.800) | K=1, look=2 | K=6, look=4 | 199 → **969** | 5 | 0 |
| D · LEUS imposible (base 8.600 en cap 3.800) | — | `halt=True` en 4 pasos | — | 4 | 0 |

*Tabla 3 de 3.* **Etiqueta: SIMULADO-EN-SECO(§11)**, no es una medición de Kaggle. El modelo del entorno es del banco, no del modelo real: sirve para probar la **lógica de control** (que no vibre, que respete el rail, que declare inviabilidad), no para predecir tok/s reales. Los tok/s reales los dirán los gates 1/2/5 en la T4.


---

## §2bis · LO QUE EL USUARIO QUISO DECIR CON "ADAPTATIVA": LA CPU (acta 255)

Corrección de la casa, y va escrita para que no se repita: **la adaptatividad pedida es sobre los núcleos del procesador**, no sobre la VRAM. El §11 (controlador de régimen) se queda porque funciona y ayuda, pero **no era lo pedido**. Lo pedido es esto:

> *"que sea adaptativa por defecto, pero que pueda configurarla para que use X núcleos del procesador"*

### §12 · Gobernador de CPU (`V4X_LTUS_CPU_CORES`)

**Adaptativo por defecto:** `configurar_cpu()` sin argumentos usa los núcleos **realmente usables** (afinidad `sched_getaffinity` ∩ cuota de cgroup v1/v2 ∩ `cpu_count`) menos la reserva. **Fijable:** `configurar_cpu(X)` o `V4X_LTUS_CPU_CORES=X`.

Reparto automático (nada de "usa X y ya veremos"):

| Núcleos pedidos | principal (alimenta GPU) | DataPump (FF-01) | intra-op PyTorch |
|---|---|---|---|
| 1 | 1 | — | 1 |
| 2 | 1 | — | 1 |
| 3 | 1 | 1 | 1 |
| 4 (Kaggle 2×T4, perfil de referencia) | 1 | 1 | 2 |
| 8 | 1 | 1 | 6 |

**Dos puertas, porque la física manda:**
- `env_cpu_preimport(n)` → **antes de importar torch**: fija `OMP/MKL/NUMEXPR/VECLIB/OPENBLAS_NUM_THREADS`. Sólo así los pools de BLAS quedan coherentes toda la vida del proceso.
- `configurar_cpu(n)` → **en caliente**: `torch.set_num_threads()` cuantas veces se quiera, más nuestros hilos de datos.

**Tres honestidades que no se esconden:**
1. `os.cpu_count()` **miente** en contenedores (devuelve el host). Por eso se lee afinidad y cuota de cgroup.
2. El modo adaptativo **no es reproducible entre máquinas**: si un run debe ser comparable, se fija `V4X_LTUS_CPU_CORES=X`. El propio código lo avisa al activarse.
3. Si pides **más** núcleos de los usables: **aborta** (`estricto=True`, por defecto) — nada de recortes silenciosos. Con `estricto=False` recorta **avisando** de que el run no será comparable.

**La configuración de CPU se sella en la partitura** (`cpu_config` dentro del `plan_sha256`): un plan firmado dice con cuántos núcleos se compiló. Sin eso, dos runs "idénticos" podrían diferir sólo por la máquina.

*Etiqueta: `KAGGLE_VCPU_T4 = 4` es **PREVISTO-PAPEL(P)** hasta que el electrocardiograma de la celda lo confirme en la máquina real.*

---

## §3 · CURAS DE LA NOCHE (CAMBIOS 246 → 253) — siguen vigentes

| Cura | Síntoma | Causa raíz | Arreglo |
|---|---|---|---|
| CURA-8 | `assert ==23` | literal de capa fósil (A-3) | E-02 por **censo** |
| CURA-8b | OOM en kernel reutilizado | `model` retenido por `sys.last_traceback` | rompe la cadena + gc + empty_cache |
| CURA-9 | 6 META `adapter.V4X.net.*` | adapter de visión ausente del ckpt por diseño | nace determinista (SEED+424247) |
| CURA-10 | OOM en carga | kernel sucio | fail-fast: mide VRAM; <12 GiB ⇒ aborta |
| CURA-11 | `no attribute '_flag_hyp3'` | el mount no trae símbolos privados | **shim** de compatibilidad |
| CURA-12 | OOM 2 GiB en `Y_diag` | intermedia cuadrática con seq=1024 | smoke a seq 256 + electrocardiograma por GPU |
| CURA-13 | `cuda:0 vs cuda:1` en rotary | `position_ids` de dev0 re-pasado a cada capa | **escolta permanente** ≥ SPLIT_LAYER + `ce_chunk` definido (era fantasma) |

*Tabla 2 de 3.*

---

## §4 · HECHOS QUE SE ABSORBEN, NO SE DISCUTEN

1. **52 capas** (23 MoE + 23 Mamba + 6 atención). Nuestro censo 51 era el error; el de Argon era correcto. `V4X_SLAB_LAYERS=(0,52)`.
2. **La frontera bizonal es una banda, no un punto**: todo tensor generado arriba se escolta en **cada** capa cuyo destino ≠ dev0.
3. **`ce_chunk` era símbolo fantasma** (llamado y nunca definido). Ahora existe, y la celda se audita por AST.
4. Sigue **O-2 bloqueante**; **N-1** resuelto por `tower_source_probe`; **N-4** parametrizado en `tower_budget_report`; **N-3** y **N-5** abiertos en la versión de Argon.

---

## §5 · LO QUE ESPERAMOS DE TI

1. **Ratificar** LAUS como familia y la S como decreto.
2. **Cruzar §11 contra los vetos**: O-1…O-4, E-5…E-12. En particular, di si el `halt` por inviabilidad debe además **invalidar el plan sellado** o basta con marcarlo.
3. **Responder a las ideas del usuario** (pegadas al final de `prompt.md`) con las seis respuestas por idea: contrato · ubicación en LTUS · coste por perfil · etiqueta · gate · migración + riesgo Casper.
4. **Replantear si procede** — con migración (md5 que muere, md5 que lo sustituye) y sin presentar papel como medición.

**La casa construye, tú contrastas y puedes replantear, el usuario decide.**
