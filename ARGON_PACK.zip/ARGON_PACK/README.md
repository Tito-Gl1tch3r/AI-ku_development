# ARGON_PACK

Orden de lectura: `00_BRIEFING.md` → `PROMPT_ARGON.md` → `medidas/piloto_OPT1.json`.

| Carpeta | Contenido |
|---|---|
| `codigo/` | Celda de SFT actual, motor, arquitectura, sombra fp16, banco p0, la celda que produjo el piloto |
| `medidas/` | Todo lo medido: p0, piloto BASE/OPT1/acumulado, sesión 1, censo |
| `datos/` | Manifiesto v8: 141 tandas, 1.974.760.183 tokens |
| `informes/` | Arquitectura del router, auditorías, actas |

Dato que manda: **47,7 tok/s** (T=512, banco de 8 expertos) contra los 410 tok/s de papel.
Ese factor de 8,6× es el encargo.
