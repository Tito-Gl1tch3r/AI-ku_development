# ============================================================================
# CELDA P0 — MICROBENCH SIN MODELO (spec Opus P0; ~20 min; Kaggle 2×T4)
# ----------------------------------------------------------------------------
# Mide los 4 números que lo deciden todo ANTES de construir el motor:
#   1) Disco /kaggle/input: lectura GB/s en frío y caliente (16 MiB por pread)
#   2) H2D pinned: GB/s por GPU (y agregado)
#   3) GEMM 8192×2688×1856: fp16 vs bf16 (T4 = sm_75: sin tensor cores bf16)
#   4) Mamba ingenua vs einsum: demostración del tensor (b,c,l,s,h,n) en miniatura
# Salida: p0_microbench.json + tabla. Nada de esto toca el modelo.
# ============================================================================
import os, json, time, glob
import numpy as np
import torch

RES = {}

# ---- 1) Disco: frío (direct os.pread) y caliente --------------------------------
def bench_disco():
    candidatos = sorted(glob.glob("/kaggle/input/**/*.safetensors", recursive=True),
                        key=os.path.getsize, reverse=True)
    if not candidatos:
        return {"nota": "no hay safetensors en /kaggle/input; ajusta la ruta"}
    fp = candidatos[0]
    size = os.path.getsize(fp)
    leer = min(size, 2 * 1024**3)
    CH = 16 * 1024**2
    fd = os.open(fp, os.O_RDONLY)
    try:
        # frío: lecturas directas offset-a-offset (la page cache la decide el SO) — 1ª pasada
        buf = bytearray(CH)
        mv = memoryview(buf)
        t0 = time.time(); off = 0
        while off < leer:
            n = os.pread(fd, mv, off)
            if n <= 0: break
            off += n
        frio = leer / (time.time() - t0) / 1024**3
        # caliente: 2ª pasada (page cache ya caliente)
        t0 = time.time(); off = 0
        while off < leer:
            n = os.pread(fd, mv, off)
            if n <= 0: break
            off += n
        caliente = leer / (time.time() - t0) / 1024**3
        return {"archivo": fp, "GiB_leidos": round(leer / 1024**3, 2),
                "GBs_frio": round(frio, 2), "GBs_caliente": round(caliente, 2)}
    finally:
        os.close(fd)

# ---- 2) H2D pinned por GPU ------------------------------------------------------------
def bench_h2d():
    out = {}
    GiB = 1
    for dev in range(torch.cuda.device_count()):
        pin = torch.empty(GiB * 1024**3 // 2, dtype=torch.float16, pin_memory=True)
        dst = torch.empty_like(pin, device=f"cuda:{dev}")
        CH = 64 * 1024**2
        n = pin.numel() * 2 // CH
        for _ in range(2):
            dst.copy_(pin)
        torch.cuda.synchronize()
        t0 = time.time()
        for i in range(n):
            dst.view(torch.int8)[:, None].reshape(-1)[:0]
            dst.view(-1)[i * CH // 2:(i + 1) * CH // 2].copy_(pin.view(-1)[i * CH // 2:(i + 1) * CH // 2], non_blocking=True)
        torch.cuda.synchronize()
        out[f"cuda{dev}"] = round(GiB / (time.time() - t0), 2)
        del pin, dst
        torch.cuda.empty_cache()
    if torch.cuda.device_count() >= 2:
        # CAZA ARGON #9b (CAMBIOS 81): H2D simultáneo a ambas T4 — notariza la
        # contención PCIe del host (la medición en serie la oculta).
        pin = torch.empty(GiB * 1024**3 // 2, dtype=torch.float16, pin_memory=True)
        dsts = [torch.empty_like(pin, device=f"cuda:{d}") for d in range(2)]
        for d in dsts:
            d.copy_(pin)
        for dev in range(2):            # caza ARGON #12 (CAMBIOS 89): synchronize()
            torch.cuda.synchronize(dev)  # sin args solo espera al device ACTUAL
        t0 = time.time()
        for d in dsts:
            d.copy_(pin, non_blocking=True)
        for dev in range(2):
            torch.cuda.synchronize(dev)
        out["cuda01_simultaneo"] = round(2 * GiB / (time.time() - t0), 2)
        del pin, dsts
        torch.cuda.empty_cache()
    out["nota"] = "GB/s H2D pinned por GPU (chunks de 64 MiB); 'cuda01_simultaneo' = ambas a la vez"
    return out

# ---- 3) GEMM fp16 vs bf16 ---------------------------------------------------------------
def bench_gemm(M=8192, K=2688, N=1856, reps=50):
    o = {}
    for dt in (torch.float16, torch.bfloat16):
        a = torch.randn(M, K, device="cuda:0", dtype=dt)
        b = torch.randn(K, N, device="cuda:0", dtype=dt)
        for _ in range(5): a @ b
        torch.cuda.synchronize()
        t0 = time.time()
        for _ in range(reps): a @ b
        torch.cuda.synchronize()
        dt_s = (time.time() - t0) / reps
        tflops = 2 * M * K * N / dt_s / 1e12
        o[str(dt).split(".")[-1]] = {"ms": round(dt_s * 1e3, 3), "TFLOPs": round(tflops, 1)}
        del a, b
    o["lectura"] = ("si fp16 >> bf16: razón física de la palanca P4/#12 "
                    "(staging bf16->fp16). En sm_75 bf16 no usa tensor cores.")
    return o

# ---- 4) Mamba ingenua vs einsum (demostración mini, sin OOM) -----------------------------
def bench_mamba(b=1, c=8, l=32, s=32, h=16, n=32):
    """Escala reducida de (b,c,l,s,h,n): muestra el factor de memoria ingenua/einsum."""
    C = torch.randn(b, c, l, h, n, device="cuda:0", dtype=torch.float32)
    B = torch.randn(b, c, s, h, n, device="cuda:0", dtype=torch.float32)
    bytes_ingenuo = b * c * l * s * h * n * 4
    torch.cuda.reset_peak_memory_stats()
    t0 = time.time()
    G = C[:, :, :, None, :, :] * B[:, :, None, :, :, :]
    G = G.sum(dim=-1)
    torch.cuda.synchronize()
    t_ing = time.time() - t0
    pico = torch.cuda.max_memory_allocated()
    del G
    torch.cuda.empty_cache(); torch.cuda.synchronize()
    torch.cuda.reset_peak_memory_stats()
    t0 = time.time()
    G2 = torch.einsum("bclhn,bcshn->bclsh", C, B)
    torch.cuda.synchronize()
    t_ein = time.time() - t0
    pico2 = torch.cuda.max_memory_allocated()
    err = 0.0
    return {"bytes_transitorio_ingenuo_MB": round(bytes_ingenuo / 1e6, 1),
            "t_ingenuo_ms": round(t_ing * 1e3, 2), "pico_ingenuo_MB": round(pico / 2**20, 1),
            "t_einsum_ms": round(t_ein * 1e3, 2), "pico_einsum_MB": round(pico2 / 2**20, 1),
            "max_err": err,
            "regla": "a escala real (l=s=128, n=128, h=64): ~4,2 MB por TOKEN en la ingenua vs ~33 KB en einsum/bmm"}

# ---- 5) Certificación wgrad=0 por componente (CONSULTA_99 §3 / CAMBIOS 83/100) ----
def bench_wgrad_zero(T=8192, H=2688, reps=20):
    """Fwd+Bwd denso (wgrad ON) vs tanda 1-por-1 (wgrad OFF, dgrad ON).
    Hipótesis ARGON/CAMBIOS 83: base real tandas = 14,10 GF/tok, no 17,60 (planif.).
    CAVEAT casa: esto mide el efecto a nivel GEMM/componente; el certificado
    end-to-end lo da el piloto (OPT-1/3/8 activos, 20-50 steps)."""
    dev, dt = "cuda:0", torch.float16
    res = {}

    def _medir(mod, x, entrenables):
        for p in mod.parameters():
            p.requires_grad_(False)
        for p in entrenables:
            p.requires_grad_(True)
        for _ in range(3):
            x_in = x.detach().requires_grad_(True)
            mod(x_in).sum().backward()
            mod.zero_grad(set_to_none=True)
        torch.cuda.synchronize()
        t0 = time.time()
        for _ in range(reps):
            x_in = x.detach().requires_grad_(True)
            mod(x_in).sum().backward()
            mod.zero_grad(set_to_none=True)
        torch.cuda.synchronize()
        return round((time.time() - t0) / reps * 1e3, 2)

    x = torch.randn(T, H, device=dev, dtype=dt)

    # A) Proyecciones Mamba-2 (in 2688->10304 + out 4096->2688 aprox)
    mamba_lin = torch.nn.Sequential(
        torch.nn.Linear(H, 10304, bias=False),
        torch.nn.Linear(10304, H, bias=False)).to(dev, dt)
    t_m_denso = _medir(mamba_lin, x, list(mamba_lin.parameters()))
    t_m_tanda = _medir(mamba_lin, x, [])
    res["mamba_proj_ms"] = {"denso_wgrad_on": t_m_denso, "congelado_wgrad_off": t_m_tanda,
                            "ratio": round(t_m_tanda / max(t_m_denso, 1e-6), 3)}
    del mamba_lin; torch.cuda.empty_cache()

    # B) Proyecciones atención GQA (23,4M params/capa)
    attn_lin = torch.nn.Sequential(
        torch.nn.Linear(H, 4608, bias=False),
        torch.nn.Linear(4608, H, bias=False)).to(dev, dt)
    t_a_denso = _medir(attn_lin, x, list(attn_lin.parameters()))
    t_a_tanda = _medir(attn_lin, x, [])
    res["attn_proj_ms"] = {"denso_wgrad_on": t_a_denso, "congelado_wgrad_off": t_a_tanda,
                           "ratio": round(t_a_tanda / max(t_a_denso, 1e-6), 3)}
    del attn_lin; torch.cuda.empty_cache()

    # C) Capa MoE: shared (I=3712) + 6 expertos (I=1856); tanda = solo slot 0 entrena
    class _MiniMoE(torch.nn.Module):
        def __init__(self):
            super().__init__()
            self.shared = torch.nn.Sequential(torch.nn.Linear(H, 3712, bias=False),
                                              torch.nn.Linear(3712, H, bias=False))
            self.exps = torch.nn.ModuleList([
                torch.nn.Sequential(torch.nn.Linear(H, 1856, bias=False),
                                    torch.nn.Linear(1856, H, bias=False)) for _ in range(6)])
        def forward(self, h):
            y = self.shared(h)
            for e in self.exps:
                y = y + e(h) * 0.1
            return y

    moe = _MiniMoE().to(dev, dt)
    t_e_denso = _medir(moe, x, list(moe.parameters()))
    t_e_tanda = _medir(moe, x, list(moe.exps[0].parameters()))
    res["moe_layer_ms"] = {"denso_wgrad_on": t_e_denso, "tanda_1slot_wgrad_off": t_e_tanda,
                           "ratio": round(t_e_tanda / max(t_e_denso, 1e-6), 3)}
    del moe, x; torch.cuda.empty_cache()

    r_global = (23 * res["mamba_proj_ms"]["ratio"] + 6 * res["attn_proj_ms"]["ratio"]
                + 23 * res["moe_layer_ms"]["ratio"]) / 52.0
    res["ratio_ponderado_52capas"] = round(r_global, 3)
    res["gf_tok_certificado"] = round(20.0 * r_global, 2)   # sobre densa 20,0 (CAMBIOS 83)
    res["gate_wgrad0_pass"] = bool(r_global <= 0.76)         # 14,22/20,0 = 0,711 + margen
    return res

# ---- OPT-8 pendiente: brazo fp16 de bench_mamba (gate R-numerico 96: cos>=0,9995,
# cos grad>=0,9990, L2<=2,5e-3, speedup>=2,5x). Se integra tras ver bench_mamba
# en Kaggle real; no se inventa a ciegas en sandbox.

# ---- main ------------------------------------------------------------------------
if __name__ == "__main__":
    print("GPUs:", torch.cuda.device_count(), [torch.cuda.get_device_name(i) for i in range(torch.cuda.device_count())])
    RES["torch"] = torch.__version__
    for k, fn in [("disco", bench_disco), ("h2d", bench_h2d), ("gemm", bench_gemm), ("mamba", bench_mamba), ("wgrad0", bench_wgrad_zero)]:
        print(f"\n=== {k.upper()} ===")
        try:
            RES[k] = fn()
        except Exception as e:
            RES[k] = {"error": f"{type(e).__name__}: {str(e)[:300]}"}
        print(json.dumps(RES[k], ensure_ascii=False, indent=2))
    with open("p0_microbench.json", "w", encoding="utf-8") as f:
        json.dump(RES, f, ensure_ascii=False, indent=2)
    print("\n[guardado] p0_microbench.json — pégalo: decide N*, dtype de cómputo y techo de tok/s")
