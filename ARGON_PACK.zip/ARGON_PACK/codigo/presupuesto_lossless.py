#!/usr/bin/env python3
# ─────────────────────────────────────────────────────────────────────────────
# presupuesto_lossless.py — ¿qué mejoras aceleran SIN perder nada?
#
# Dos clases, y no se mezclan:
#   CLASE A (bit-exacta): mismo resultado matemático, bit a bit. Cambia el ORDEN
#                         de las operaciones o el sitio donde viven los datos.
#   CLASE B (acotada)   : cambia el dtype de algo. El resultado NO es idéntico.
#                         Se puede medir cuánto se pierde, pero se pierde.
#
# Este script: (1) simula un entrenamiento real en las tres precisiones para
# medir si la sombra FP16 cuesta calidad; (2) calcula la frontera memoria-vs-
# recomputo de pin_borders. Sin torch: numpy puro.
# ─────────────────────────────────────────────────────────────────────────────
import numpy as np

rng_global = np.random.default_rng(0)
OUT = {}


def sec(t):
    print("\n" + "═" * 74)
    print(t)
    print("═" * 74)


# ═══ EXPERIMENTO 1 · ¿La sombra fp16 cuesta calidad? ════════════════════════
# Simulación honesta del patrón real: pesos en un master FP32, copia redondeada
# al dtype de cómputo para el forward/backward, gradiente en fp32 que se aplica
# AL MASTER. Es exactamente lo que hace una sombra FP16 bien hecha.
class MLP:
    def __init__(self, d_in, d_hid, d_out, seed):
        r = np.random.default_rng(seed)
        self.W1 = (r.standard_normal((d_in, d_hid)) * np.sqrt(2.0 / d_in)).astype(np.float32)
        self.b1 = np.zeros(d_hid, np.float32)
        self.W2 = (r.standard_normal((d_hid, d_out)) * np.sqrt(2.0 / d_hid)).astype(np.float32)
        self.b2 = np.zeros(d_out, np.float32)

    def forward(self, X, cast=None):
        W1, W2 = self.W1, self.W2
        if cast is not None:
            W1, W2 = W1.astype(cast).astype(np.float32), W2.astype(cast).astype(np.float32)
        z1 = X @ W1 + self.b1
        a1 = np.maximum(z1, 0.0)
        logits = a1 @ W2 + self.b2
        return z1, a1, logits, W1, W2


def softmax_ce(logits, y):
    m = logits.max(axis=1, keepdims=True)
    e = np.exp(logits - m)
    p = e / e.sum(axis=1, keepdims=True)
    n = len(y)
    loss = -np.log(np.clip(p[np.arange(n), y], 1e-12, None)).mean()
    g = p.copy()
    g[np.arange(n), y] -= 1.0
    return loss, g / n


def entrenar(cast, seed, pasos=400, lr=3e-3, bs=64):
    r = np.random.default_rng(seed + 1000)
    d_in, d_hid, d_out, N = 64, 128, 32, 1024
    X = r.standard_normal((N, d_in)).astype(np.float32)
    # tarea no lineal: la clase depende de una proyección aleatoria + ruido
    Wt = r.standard_normal((d_in, d_out)).astype(np.float32)
    y = np.argmax(np.tanh(X @ Wt) + 0.5 * r.standard_normal((N, d_out)), axis=1)

    m = MLP(d_in, d_hid, d_out, seed)
    st = {k: (np.zeros_like(v), np.zeros_like(v)) for k, v in
          (("W1", m.W1), ("b1", m.b1), ("W2", m.W2), ("b2", m.b2))}
    b1_, b2_, eps, wd, t = 0.9, 0.999, 1e-8, 0.01, 0
    curva = []
    for paso in range(pasos):
        idx = r.integers(0, N, bs)
        xb, yb = X[idx], y[idx]
        z1, a1, logits, W1c, W2c = m.forward(xb, cast)
        loss, gl = softmax_ce(logits, yb)
        # backward CON LOS PESOS REDONDEADOS (como haría el kernel fp16)
        gW2 = a1.T @ gl + wd * W2c
        gb2 = gl.sum(0)
        ga1 = gl @ W2c.T
        gz1 = ga1 * (z1 > 0)
        gW1 = xb.T @ gz1 + wd * W1c
        gb1 = gz1.sum(0)
        t += 1
        for k, g in (("W1", gW1), ("b1", gb1), ("W2", gW2), ("b2", gb2)):
            m1, v1 = st[k]
            # el gradiente se aplica al MASTER en fp32 ⇒ sin deriva acumulada
            m1 *= b1_; m1 += (1 - b1_) * g
            v1 *= b2_; v1 += (1 - b2_) * (g * g)
            mh = m1 / (1 - b1_ ** t)
            vh = v1 / (1 - b2_ ** t)
            p = {"W1": m.W1, "b1": m.b1, "W2": m.W2, "b2": m.b2}[k]
            p -= lr * (mh / (np.sqrt(vh) + eps))
        curva.append(loss)
    return np.array(curva, dtype=np.float32)


sec("1 · ¿La sombra FP16 cuesta calidad? (entrenamiento real, 400 pasos, 5 semillas)")
print("Patrón: master FP32 + cómputo en el dtype + gradiente aplicado al master.\n")
modos = [("fp32 (referencia)", None), ("fp16 (sombra)", np.float16),
         ("bf16 (emulado)", None), ("fp16 SIN master", np.float16)]
res = {}
for nombre, cast in (("fp32 (referencia)", None), ("fp16 (sombra)", np.float16)):
    finals = []
    for s in range(5):
        c = entrenar(cast, s)
        finals.append(float(c[-50:].mean()))
    res[nombre] = finals
    print(f"  {nombre:20s} loss final = {np.mean(finals):.5f} ± {np.std(finals):.5f} "
          f"(semillas: {[round(f,4) for f in finals]})")

# bf16 emulado: cuantizar a bf16 = truncar mantisa a 8 bits
def a_bf16(a):
    v = a.astype(np.float32).view(np.uint32)
    return ((v + 0x8000) & 0xFFFF0000).view(np.float32)


class MLPbf(MLP):
    def forward(self, X, cast=None):
        z1 = X @ a_bf16(self.W1) + a_bf16(self.b1)
        a1 = np.maximum(z1, 0.0)
        logits = a1 @ a_bf16(self.W2) + a_bf16(self.b2)
        return z1, a1, logits, a_bf16(self.W1), a_bf16(self.W2)


def entrenar_bf16(seed, pasos=400, lr=3e-3, bs=64):
    r = np.random.default_rng(seed + 1000)
    d_in, d_hid, d_out, N = 64, 128, 32, 1024
    X = r.standard_normal((N, d_in)).astype(np.float32)
    Wt = r.standard_normal((d_in, d_out)).astype(np.float32)
    y = np.argmax(np.tanh(X @ Wt) + 0.5 * r.standard_normal((N, d_out)), axis=1)
    m = MLPbf(d_in, d_hid, d_out, seed)
    st = {k: (np.zeros_like(v), np.zeros_like(v)) for k, v in
          (("W1", m.W1), ("b1", m.b1), ("W2", m.W2), ("b2", m.b2))}
    b1_, b2_, eps, wd, t = 0.9, 0.999, 1e-8, 0.01, 0
    curva = []
    for _ in range(pasos):
        idx = r.integers(0, N, bs)
        xb, yb = X[idx], y[idx]
        z1, a1, logits, W1c, W2c = m.forward(xb)
        loss, gl = softmax_ce(logits, yb)
        gW2 = a1.T @ gl + wd * W2c
        gb2 = gl.sum(0)
        gz1 = (gl @ W2c.T) * (z1 > 0)
        gW1 = xb.T @ gz1 + wd * W1c
        gb1 = gz1.sum(0)
        t += 1
        for k, g in (("W1", gW1), ("b1", gb1), ("W2", gW2), ("b2", gb2)):
            m1, v1 = st[k]
            m1 *= b1_; m1 += (1 - b1_) * g
            v1 *= b2_; v1 += (1 - b2_) * (g * g)
            p = {"W1": m.W1, "b1": m.b1, "W2": m.W2, "b2": m.b2}[k]
            p -= lr * ((m1 / (1 - b1_ ** t)) / (np.sqrt(v1 / (1 - b2_ ** t)) + eps))
        curva.append(loss)
    return np.array(curva, dtype=np.float32)


fb = [float(entrenar_bf16(s)[-50:].mean()) for s in range(5)]
res["bf16 (emulado)"] = fb
print(f"  {'bf16 (emulado)':20s} loss final = {np.mean(fb):.5f} ± {np.std(fb):.5f}")

base = np.mean(res["fp32 (referencia)"])
print()
for k, v in res.items():
    if k == "fp32 (referencia)":
        continue
    d = np.mean(v) - base
    pct = 100 * d / base
    veredicto = ("dentro del ruido" if abs(d) < 2 * np.std(v) else "DIFERENCIA REAL")
    print(f"  {k:20s} Δloss = {d:+.5f} ({pct:+.2f} %)  ⇒ {veredicto}")
OUT["precision"] = {k: {"mean": round(float(np.mean(v)), 5), "std": round(float(np.std(v)), 5)}
                    for k, v in res.items()}
print("\n  Lectura: la sombra FP16 sólo es 'no perder nada' si el Δ cae dentro del ruido")
print("  entre semillas. Si cae fuera, es una mejora ACOTADA, no exenta de coste.")

# ═══ EXPERIMENTO 2 · Frontera memoria vs recomputo de pin_borders ═══════════
sec("2 · Los 11,16 GiB de pin_borders: ¿qué se puede hacer SIN perder nada?")
T, H, K, FGL, NL = 8192, 2688, 8, 18, 52
borde = T * H * 2
capas = NL - FGL
GiB = 2 ** 30
total = capas * K * borde
print(f"  borde fp16 = {borde/2**20:.2f} MiB · {capas} capas × {K} micros = {total/GiB:.2f} GiB\n")
print("  Opciones, con su coste real:")
print()
print("  A) Tal cual (guardar los 34 bordes en pinned fp16)")
print(f"     memoria {total/GiB:6.2f} GiB · recomputo 0 · calidad BIT-EXACTA")
print()
print("  B) fp8 e4m3 en los bordes")
print(f"     memoria {total/GiB/2:6.2f} GiB · recomputo 0 · calidad PERDIDA (el gradiente cambia)")
print("     ⇒ NO es 'no perder nada'. Descartada bajo tu criterio.")
print()
print("  C) Checkpoint por grupos: guardar 1 de cada N capas y recomputar el resto en el bwd")
for N in (2, 4, 8):
    mem = total / N
    extra = (N - 1) / N  # fracción de un forward extra por capa
    print(f"     N={N}: memoria {mem/GiB:6.2f} GiB · forwards extra ≈ {extra*100:4.0f} % · calidad BIT-EXACTA")
print()
print("  D) Reducir los TOKENS por step (no K: la memoria es capas × K·T × H × 2,")
print("     así que depende del producto K·T, no de cómo se trocee)")
toks = K * T
for frac, lbl in ((1.0, "65536 tok (hoy)"), (0.5, "32768 tok"), (0.25, "16384 tok")):
    t2 = int(toks * frac)
    print(f"     {lbl:16s}: memoria {capas*t2*H*2/GiB:6.2f} GiB · BIT-EXACTO por token, "
          f"pero {frac*100:3.0f} % de tokens/step")
print()

# coste real de C, medido en tiempo de step
sec("3 · ¿Merece la pena pagar recomputo para ahorrar transferencia?")
t_comp_fp16 = 3.63     # s/step, de la fórmula de Argon con sombra FP16
t_xfer = 11.98 / 8.5   # GB / BW, el borde que hoy cruza el bus
print(f"  Con sombra FP16: cómputo {t_comp_fp16:.2f} s · transferencia de borde {t_xfer:.2f} s")
print("  Si el borde se queda en VRAM/RAM sin cruzar el bus, se ahorran esos segundos.")
print()
for N in (1, 2, 4, 8):
    extra = (N - 1) / N * t_comp_fp16 * 0.5   # recomputo del forward de una capa ≈ 1/3 del paso
    ahorro = t_xfer if N == 1 else t_xfer
    neto = t_comp_fp16 + extra
    print(f"  N={N}: step ≈ {neto:5.2f} s (recomputo +{extra:4.2f} s) vs hoy {t_comp_fp16+t_xfer:5.2f} s "
          f"⇒ {'GANA' if neto < t_comp_fp16 + t_xfer else 'PIERDE'}")
print()
print("  Ojo: con N=1 (guardar todo) ya ganas si el borde NO cruza el bus. El problema de A")
print("  no es el tiempo, es que 11,16 GiB no caben. Recomputar es el precio de que quepan.")

with open("presupuesto_lossless.json", "w") as f:
    import json
    json.dump(OUT, f, indent=2, ensure_ascii=False)

sec("RESUMEN")
print("CLASE A (bit-exacta, sin coste de calidad): CURA-20, orden del tape, reuso de buffers,")
print("        checkpoints por grupo (N) y reducción de K. Estas son las que puedes llamar 'gratis'.")
print("CLASE B (acotada, SÍ cuesta): sombra FP16 (medida arriba), fp8 en bordes, cualquier cast.")
print("⇒ 'Acelerar sin perder nada' = sólo clase A. Todo lo demás hay que medirlo y aceptarlo.")
