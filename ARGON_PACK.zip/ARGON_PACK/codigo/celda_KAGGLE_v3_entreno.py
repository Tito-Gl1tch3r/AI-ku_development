#!/usr/bin/env python3
# =============================================================================
# CELDA KAGGLE v2 — ENTRENAMIENTO AI-ku V4X (SFT por tandas, 2×T4)
# Sucesora de celda_7 (kit viejo): reescrita desde cero en AI-ku_New.
#
# DECRETOS INTEGRADOS (registro en CAMBIOS_27SEP.md):
#   57 — 177 tandas, 1-por-1, aislamiento en optimizador; router semilla-42
#        CONGELADO; curriculum 177 -> emb -> atenciones -> compartido(+emb+gate)
#   59 — top_k = 6 (supersede 8)
#   63/64 — nada de encoders en el motor; backbone tronco 10,59 GiB medidos
#   70 — LLAVE 4: manifiesto K=1,15 (suelo + puente 15%); telemetría domínios
#        LLAVE 5: máscara phi<->spans 12..13 (FIX-06 en modeling, bordes
#        demostrados; flag config v4x_phi_span_mask)
#   73 — REGLA pre-tokenizer: prohibido truncar por derecha; ventanas T=8192
#        contiguas conservando system+tools y cierre de trayectoria (Oro
#        train_cursor 55-70k tok/línea); alias URT normalizados o suelo doble
#   Saneamiento kit veto: SIN LoRA (full-SFT), SIN model.eval(), SIN NF4
#        (BF16 íntegro), autocast fp16 opcional por flag.
#
# PENDIENTE DEL NOTARIO (no atar constantes a poesía):
#   P0 — p0_microbench.json (disco/H2D/GEMM/einsum) -> alimenta SECCIÓN 6
#   P5 — ruta SSD einsum de Mamba en entrenamiento (bloqueante T>=4k): toggle
#        V4X_P5_SSD_TRANSFORMS espera medición; de momento fail-fast si una
#        capa mamba entra con use_mamba_kernels=True y training=True (CAMBIOS 56)
# =============================================================================

import glob
import json
import os
import sys          # CAMBIOS 216: faltaba para _instalar_kernels_sm75 (NameError en Kaggle)
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

# ---------------------------------------------------------------------------
# SECCIÓN 0a — KNOBS DE SILICIO (CURA-25, acta 258): ANTES de importar torch
#
# "Aprovechar hasta el último átomo" = no dejar rendimiento sobre la mesa por
# variables que se leen UNA VEZ al arrancar el intérprete. Estas tres tienen que
# fijarse aquí; después del `import torch` ya no hacen nada.
# ---------------------------------------------------------------------------
# 1) Workspace de cuBLASLt. El default (256 KiB) impide ciertos tiles split-K en
#    formas rectangulares como 2688×768 (Qwen) y 2688×17920 (Phi).
#    :4096:8 = 32 MiB · :8192:8 = 64 MiB. Si el usuario ya lo fijó, se respeta.
os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":8192:8")
# 2) Alocador: expandable_segments reduce la fragmentación que, con slots de
#    cientos de MiB, es la causa típica de "reservé 28 GiB y me quedo sin VRAM".
os.environ.setdefault("PYTORCH_CUDA_ALLOC_CONF", "expandable_segments:True")
# 3) Carga de módulos CUDA perezosa: acorta el arranque de cada sesión de Kaggle.
os.environ.setdefault("CUDA_MODULE_LOADING", "LAZY")
# 4) NO hay TF32 que activar: sm_75 no lo tiene. Dejarlo explícito evita que un
#    default de PyTorch de otra versión prometa una aceleración que no existe.
os.environ.setdefault("NVIDIA_TF32_OVERRIDE", "0")

import torch

torch.backends.cudnn.benchmark = True          # autotune de kernels (coste único)
torch.backends.cuda.matmul.allow_tf32 = False # sm_75: no hay TF32, que no engañe

# ---------------------------------------------------------------------------
# SECCIÓN 0 — FLAGS / GUARDIAS (bajado del decreto, no de ARGON ni del kit viejo)
# ---------------------------------------------------------------------------

V4X_REPO = os.environ.get(
    "V4X_REPO",
    "/kaggle/input/models/gl1tch3r/ai-ku-v4x-thinker-max-50b/other/default/21")  # CAMBIOS 212: modelo+código viven en el mismo mount del Hub
OUT_DIR = os.environ.get("V4X_OUT", "/kaggle/working/tandas")

V4X_TOPK = int(os.environ.get("V4X_TOPK", "6"))            # Decreto 59
V4X_SPAN_PHI_MASK = os.environ.get("V4X_SPAN_PHI_MASK", "1") == "1"  # Llave 5 (70)
FULL_SFT = True            # Decreto 57: LoRA vetado, sin excepción
AUTOCAST_FP16 = os.environ.get("V4X_AUTOCAST_FP16", "1") == "1"
SEED = 42                  # router y curriculum, semilla fija (A3/57)

# Guardias de la casa (rompen antes que construir sobre aire — lección 63)
assert FULL_SFT, "LoRA está vetado por decreto 57; esta celda solo hace full-SFT"
for var in ("V4X_LOAD_4BIT", "V4X_NF4", "V4X_QLORA"):
    assert os.environ.get(var, "0") != "1", f"!! {var}=1 viola el veto NF4/quant (CALIDAD URT)"

torch.manual_seed(SEED)

# ── ACELERACIÓN CASA Ω (CAMBIOS 192/193): flags dormidos → default ON ──
# (Veto intocable: quant/fp8/bf16-entrenables/LoRA. Todo lo demás es celda-legal.)
import subprocess  # CAMBIOS 209: instalación kernels oficiales (legal: celda, no modeling)
def _instalar_kernels_sm75():
    """CAMBIOS 209: mamba_ssm + causal_conv1d son los DOS únicos kernels HF que:
    (1) soportan sm_75 en el path fp16 (nuestro camino sombra),
    (2) ya son importados por modeling_v4x.py si existen (L146-152),
    (3) no son quant ni GPU-vedada. pip install = acelerador legitimado.
    Idempotente: si ya existen, no-op."""
    for pkg in ("causal-conv1d", "mamba-ssm"):
        try:
            # CAMBIOS 217: en local (sin CUDA) falla la build CUDA harder. Lo que
            # Kaggle DEBE hacer: primero intentar con wheels nuevos pre-compilados
            # (sm75 incluido); si falla, el fallback ya vive en modeling.
            env_skip = os.environ.copy()
            if pkg == "mamba-ssm": env_skip["MAMBA_SKIP_CUDA_BUILD"] = "TRUE"
            elif pkg == "causal-conv1d": env_skip["CAUSAL_CONV1D_SKIP_CUDA_BUILD"] = "TRUE"
            r = subprocess.run([sys.executable, "-m", "pip", "install", "-q", pkg],
                               check=False, timeout=600, env=env_skip,
                               capture_output=True, text=True)  # Solo -q en 217 (sin no-build, Kaggle no tiene nvcc)
            # si instala OK, modeling lo encuentra. Si no, fallback PyTorch.
            print(f"[k-Ω209] {pkg}: {'✓' if r.returncode==0 else 'skip (fallback legal)'}")
        except Exception as e:
            print(f"[k-Ω209] {pkg}: skip ({e.__class__.__name__})")
if os.environ.get("V4X_KERNELS_CUDA", "1") == "1":
    _instalar_kernels_sm75()

torch.backends.cudnn.benchmark = True                 # conv1d/kernels del mixer
os.environ.setdefault("V4X_OPT8_FP16", "1")           # 153: ×2,47 mixer Mamba (medido)
os.environ.setdefault("V4X_OPT1_NOGRAD_PREFIX", "1")  # 151: prefijos frozen sin backward
os.environ.setdefault("V4X_HYP1_MOE_NOCKPT", "1")     # 104: MoE sin recompute (gate VRAM)
os.environ.setdefault("V4X_HYP3_EXPD2", "1")          # 104: expertos frozen sin grafo
# ψ-26 (CAMBIOS 223, auditoría Gemini): TURBO-1a era exacto por causalidad desde
# el 104 pero nacía apagado (default "0"). Nace ON; el recorte se alinea a 128
# para no pagar F.pad en las 23 capas Mamba (CAMBIOS 151 G2).
os.environ.setdefault("V4X_TURBO1", "1")
os.environ.setdefault("V4X_ACEL_BF16", "1")           # 193: sombra fp16 frozen (turing)

T_TOKENS = 8192            # ventana de packs (73: ventanas contiguas, no truncado)
GRAD_ACCUM = 8             # microbatches por paso de optimizador (ajusta SECCIÓN 6 tras P0)
LR = float(os.environ.get("V4X_LR", "1e-5"))
WARMUP_STEPS = 40

TOK = {"start": 10, "end": 11, "think": 12, "thought": 13}  # verificado tokenizer (73)


# ---------------------------------------------------------------------------
# SECCIÓN 1 — MANIFIESTO (LLAVE 4: K=1,15 suelo + puente 15%, telemetría dominios)
# Formato del archivo manifiesto.json (lo genera el script de la casa, separado):
#   {
#     "tandas": {
#       "177/sub_0": {"lineas": [{"fichero": "...", "offset": N, "tokens": M}, ...],
#                      "capas": [18, 24]},
#       "037":       {"lineas": [...],   "capas": null},
#       "emb": {...}, "attn": {...}, "shared": {...}
#     },
#     "cobertura": {"037": {"tokens_obj": 12000000, "tokens_real": 12345678}, ...}
#   }
# Reglas ya selladas que DEBE cumplir quien lo construye:
#   - K medio = 1,15: 85% de líneas a 1 tanda (con suelo mínimo por tanda),
#     15% (percentil superior de co-afinidad) también en 2ª tanda.
#   - Telemetría PRIMARIA = etiquetas de dominio de metadata (68). Votos del
#     router: solo como refinamiento posterior (costaría medio mes de silicio).
#   - Alias URT normalizados (c2<->command-and-control, recon<->reconnaissance,
#     red-team<->redteam, pentesting<->penetration-testing) o suelo doble (73).
#   - Grupo-A élite (Oro x3, Programming, Maths, Frontier...): cobertura 100%,
#     puente liberal (cuesta ~3-5h en total, regalado). Oro x3 = multiplicidad
#     de élite DISEÑADA, no violación de K=1,15 (nota contable 73).
#   - Orden dentro de tanda por estrato pedagógico 00 -> 13 con shuffle SOLO
#     intra-bloque y sub-órdenes estrictos (V0.1->base->superprogrammer,
#     train_cursor->trajectory) (73/§5).
# ---------------------------------------------------------------------------


@dataclass
class Tanda:
    nombre: str
    slot: Optional[int]              # 1..177 o None para tandas no-experto (emb/attn/shared)
    capas_phi: Optional[Tuple[int, int]]  # solo 177: sub-tanda [lo, hi) de capas phi
    lineas: List[dict] = field(default_factory=list)
    tokens_total: int = 0
    lr: float = 0.0                  # DISC-10 fix: receta del manifiesto (Oro 3e-6, cyber 8e-6…)
    T: int = 8192                    # DISC-10 fix: ventana del manifiesto (qwen 8192, cyber/prog 4096)


def leer_manifiesto(ruta_manifesto: str) -> List[Tanda]:
    with open(ruta_manifesto, "r", encoding="utf-8") as f:
        manif = json.load(f)

    tandas: List[Tanda] = []
    # Curriculum decretado: phi (3 sub-tandas) -> 176 slots -> emb -> attn -> shared
    PHI_SUB = [(18, 25), (25, 32), (32, 40)]  # 7+7+8 = 22 capas exactas (CAZA ARGON #1, CAMBIOS 81: antes saltaba 24/31/39)
    orden = [f"177/sub_{i}" for i in range(3)] + [str(s) for s in range(1, 177)] + ["emb", "attn", "shared"]

    for clave in orden:
        if clave not in manif["tandas"]:
            continue
        info = manif["tandas"][clave]
        if clave.startswith("177/sub_"):
            slot, capas = 177, PHI_SUB[int(clave.split("_")[1])]
        elif clave.isdigit():
            slot, capas = int(clave), None
        else:
            slot, capas = None, None
        tandas.append(Tanda(clave, slot, capas, info["lineas"],
                            sum(l["tokens"] for l in info["lineas"]),
                            lr=float(info.get("lr", LR)), T=int(info.get("T", T_TOKENS))))

    # TABLA DE COBERTURA — requisito de la firma (70): el usuario la audita
    print("\n=== TABLA DE COBERTURA POR TANDA (auditar antes de sonar campana) ===")
    print(f"{'tanda':>12} | {'tokens_real':>13} | {'tokens_obj':>13} | {'ratio':>6}")
    for t in tandas:
        obj = manif.get("cobertura", {}).get(t.nombre, {}).get("tokens_obj")
        ratio = (t.tokens_total / obj) if obj else float("nan")
        flag = " (!BAJO SUELO!)" if obj and ratio < 0.95 else ""
        obj_s = f"{obj:13,d}" if obj else "         n/a"
        print(f"{t.nombre:>12} | {t.tokens_total:13,d} | {obj_s} | {ratio:6.2f}{flag}")
    print("=" * 72 + "\n")
    return tandas


# ---------------------------------------------------------------------------
# SECCIÓN 2 — CARGA DEL MODELO (AI-ku_New; trunk-only; encoders fuera del motor)
    # Regla (63/64/77-78): Whisper/MERT/torres Qwen3-Omni/DeepSeek NO entran
    # al motor. (Gemma4 y los adapters muertos: fumigados en CAMBIOS 77-78.)
# ---------------------------------------------------------------------------


def prefijos_excluidos_encoders() -> Tuple[str, ...]:
    # FIX ψ-33 (CAMBIOS 224, auditoría Argon): los nombres reales en modeling son
    # V4X_Audio y V4X_Vision (pasantes de Qwen3). Los nombres _Vid_Aud/_Vid_Vis
    # eran fantasía heredada y no anulaban NADA: ~6,5 GiB vivas por mil años.
    return (
        "V4X_Transcription.", "V4X_Music.", "V4X_Audio.", "V4X_Vision.",
        "V4XDeepSeekVision", "adapter.V4X.", "V4XMERT", "V4XQwen3",
    )


def claves_slot(slot: int, capas_phi: Optional[Tuple[int, int]]) -> List[str]:
    """Claves del índice safetensors a tocar en esta tanda (1-por-1, 57)."""
    if slot is None:
        return []  # emb/attn/shared tocan el tronco (definido en el motor)
    lo_hi = "" if capas_phi is None else f"capas {capas_phi[0]}..{capas_phi[1]-1}"
    print(f"[tanda] slot {slot} {lo_hi} -> solo sus claves de experto viajan")
    return [f"experts.{slot}"]   # el motor resuelve a tensores reales vía índice


def _warm_init_router_desde_gate(model: torch.nn.Module) -> int:
    """CAZA #15b (CAMBIOS 92): el checkpoint SÍ trae gate Nemotron entrenado para
    los slots 0..127 -> copia caliente a v4x_router (filas 0..127 de cada capa MoE).
    Sobre meta-device no copia (P2 la invoca tras materializar los pesos)."""
    aplicados = 0
    for bloque in model.modules():
        gate = getattr(bloque, "gate", None)
        vr = getattr(bloque, "v4x_router", None)
        if gate is not None and vr is not None and not getattr(gate.weight, "is_meta", True):
            n = gate.weight.shape[0]
            with torch.no_grad():
                vr.weight[:n] = gate.weight.to(vr.weight.dtype)
                # #22 (CAMBIOS 94): igualar magnitudes de logit entre familias:
                # filas nuevas (qwen 128..176 + phi 177) al std real del gate.
                std_gate = gate.weight.float().std().item()
                if std_gate > 1e-12:
                    vr.weight[n:] *= std_gate / 0.02
            aplicados += 1
    print(f"[warm-init] v4x_router[0..127] inicializados desde gate Nemotron en {aplicados} capas MoE")
    return aplicados


def cargar_modelo(deferred_ok: bool = True) -> torch.nn.Module:
    """Instancia V4XForCausalLM en meta + streaming del tronco y del slot.

    PENDIENTE motor P2/P3 (barrido de capas + split 2×T4): por ahora el loader
    respeta estrictamente la exclusión de encoders y el slot 1-por-1.
    """
    import sys
    sys.path.insert(0, V4X_REPO)
    from configuration_v4x import V4XConfig
    from modeling_v4x import V4XForCausalLM

    cfg = V4XConfig.from_pretrained(os.path.join(V4X_REPO))
    # FIX ψ-21 (CAMBIOS 223, auditoría Gemini — trampa confirmada): el config.json del
    # checkpoint puede traer v4x_router_top_k=null; modeling (router L660) caería al
    # fallback `or num_experts_per_tok` = 177 DENSO (29,5× filas GEMM de experto).
    # La celda impone el Decreto 59 ANTES de instanciar; el assert sigue de sello.
    if cfg.v4x_router_top_k is None:
        print("[modelo] config traía top_k=None (trampa denso-177) -> Decreto 59 impone 6")
        cfg.v4x_router_top_k = V4X_TOPK
    assert cfg.v4x_router_top_k == V4X_TOPK, f"top_k config ({cfg.v4x_router_top_k}) != decreto ({V4X_TOPK})"
    # FIX E-01b (CAMBIOS 225, auditoría Argon): mi fix ψ-21 imponía top_k=6 pero
    # NUNCA fijaba routing_mode -> con el default "off" (configuration L284) el
    # v4x_router NO sustituye al gate y los 49 expertos Qwen + Phi-177 recibían
    # 0 tokens y 0 gradiente EN TODAS las tandas. Sin esto, ψ-21 era letra muerta.
    cfg.v4x_routing_mode = os.environ.get("V4X_ROUTING_MODE", "unified")
    cfg.v4x_phi_span_mask = V4X_SPAN_PHI_MASK   # Llave 5 (FIX-06)
    # FIX ψ-T5a (CAMBIOS 221, auditoría Gemini): el modeling por defecto instancia
    # las 6 capas de atención en "eager" (matriz O(T²) fp32 por capa = 8 GiB a
    # T=8192). Cambio de CONFIG, modeling intocable. SDPA en sm75 cae a mem-
    # efficient (CUTLASS). Apagable con V4X_ATTN_IMPL=eager para el A/B del gate.
    cfg._attn_implementation = os.environ.get("V4X_ATTN_IMPL", "sdpa")
    # FIX ψ-T5b (CAMBIOS 237, CAZA en Kaggle): ψ-T5a (221) pedia sdpa por config pero
    # transformers modelado_utils valida contra _supports_sdpa y V4XForCausalLM JAMAS
    # lo declaro -> ValueError al construir (mina dormida: entrenar() nunca habia
    # arrancado). modeling intocable -> bandera desde celda (legal; el modeling SI
    # tiene NemotronHSdpaAttention L1373 y el mapa "sdpa" L1515).
    import modeling_v4x as _M5b
    _M5b.NemotronHPreTrainedModel._supports_sdpa = True   # CURA-6b (238): base -> cubre backbone y causalLM
    print(f"[modelo] top_k={cfg.v4x_router_top_k} phi_span_mask={cfg.v4x_phi_span_mask} attn={cfg._attn_implementation}")

    # PENDIENTE P2/P3: aquí irá el cargador por láminas con split de capas
    # (0-25 / 26-51) cuando el microbench fije constantes. Marcador explícito:
    print("[motor] PENDIENTE split P3 (constantes a fijar con p0_microbench.json)")
    with torch.device("meta"):   # CAZA #17 (CAMBIOS 92): instanciar en meta = 0 bytes
        model = V4XForCausalLM(cfg)  # de RAM (antes: ~187 GB fp32 en CPU, boom)
    # FIX ψ-22+ψ-32 (CAMBIOS 223+224, auditoría Argon): modeling L1915 lee
    # _V4X_FLAG_HYP1 (constante import-time) y _flag_hyp1() nació huérfana (0 llamadas).
    # Celda-legal: re-sellamos las constantes del módulo tras leer env.
    # ADEMÁS (ψ-32): la celda NUNCA activaba gradient_checkpointing y el flag
    # manual en backbone dejaba _gradient_checkpointing_func sin inicializar
    # (AttributeError en la 1ª capa entrenable). Forma legal HF:
    # gradient_checkpointing_enable() propaga el flag Y registra la función ckpt.
    import modeling_v4x as _M22
    _M22._V4X_FLAG_HYP1 = os.environ.get("V4X_HYP1_MOE_NOCKPT", "1") == "1"
    _M22._V4X_FLAG_HYP3 = os.environ.get("V4X_HYP3_EXPD2", "1") == "1"
    _M22._V4X_FLAG_OPT1 = os.environ.get("V4X_OPT1_NOGRAD_PREFIX", "1") == "1"
    try:
        model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={"use_reentrant": False})
    except (TypeError, AttributeError):
        # PreTrainedModel antiguo sin kwargs o backbone no registrado por la API:
        # fallback manual explícito funcionalmente idéntico
        import functools
        import torch.utils.checkpoint as _ck
        model.backbone.gradient_checkpointing = True
        model.backbone._gradient_checkpointing_func = functools.partial(_ck.checkpoint, use_reentrant=False)
    print(f"[motor] ckpt={model.backbone.gradient_checkpointing} HYP1={_M22._V4X_FLAG_HYP1} HYP3={_M22._V4X_FLAG_HYP3} OPT1={_M22._V4X_FLAG_OPT1}")
    # ψ-33: nombres REALES de las torres (modeling __init__ L1839-1842);
    # antes se anulaban fantasmas y quedaban 6,5 GiB de Qwen3 audio/visión vivas.
    for torre in ("V4X_Transcription", "V4X_Music", "V4X_Audio", "V4X_Vision"):
        if hasattr(model, torre):
            setattr(model, torre, None)   # Decreto 63/64: encoders ni se instancian
    # FIX E-02 (CAMBIOS 225, auditoría Argon): _warm_init_router_desde_gate sobre
    # meta-device es NO-OP (guardia is_meta) — aquí queda llamada barata; la llamada
    # VINCULANTE la hará el cargador A-01 DESPUÉS de materializar los shards, y allí
    # aplicados DEBE ser 23. Si esa llamada falta, los routers nacen ciegos (std=0.02).
    aplicados_pre = _warm_init_router_desde_gate(model)
    if aplicados_pre == 0:
        print("[warm-init] 0 capas (meta expected): el cargador A-01 debe re-invocar "
              "post-materialización y exigir aplicados==23 — si no, gate E-02 FAIL")
    return model


def _pertenece_a_tanda_tronco(nombre: str, tanda: str) -> bool:
    """Filtro por tandas de tronco (CAZA ARGON #3, CAMBIOS 81).

    CAZA #7: las 6 capas de atención del tronco suman 140,38M params en total
    (23,40M/capa) -> estados ~1,3-1,8GiB -> tanda 'attn' full-SFT en UNA pieza.
    """
    if tanda == "emb":
        return nombre.startswith("backbone.embeddings.")
    if tanda == "attn":
        return nombre.startswith("backbone.layers.") and any(
            k in nombre for k in (".q_proj.", ".k_proj.", ".v_proj.", ".o_proj."))
    if tanda == "shared":   # decreto 57: compartido + lm_head + gate Nemotron
        return (
            (nombre.startswith("backbone.layers.") and (".shared_experts." in nombre or ".gate." in nombre))
            or nombre.startswith("lm_head.")
        )
    return False


def fijar_router_y_requires_grad(model: torch.nn.Module, tanda: Tanda) -> List[torch.nn.Parameter]:
    """Aislamiento 1-por-1 (57): SOLO el slot de la tanda tiene requires_grad.
    Router: SEMILLA 42 + CONGELADO durante todo el SFT (A3/57)."""
    if tanda.slot is None:
        model._first_grad_layer = 0
    elif tanda.slot == 177:
        model._first_grad_layer = tanda.capas_phi[0] if tanda.capas_phi else 18
    elif tanda.slot >= 129:
        model._first_grad_layer = 18    # Qwen vive en 18..47: capas 0..17 sin backward
    else:
        model._first_grad_layer = 1     # Nemotron: primera MoE en capa 1
    for p in model.parameters():
        p.requires_grad = False
        # FIX ψ-T1b (CAMBIOS 221, auditoría Gemini): re-sombra legal — el slot que
        # cierra quedaba fp32 para siempre. Si cerró entrenado y queda congelado,
        # vuelve a fp16-sombra si cabe en rango (fp16 max 65504); si no, fp32.
        if getattr(p, "_casa_slot_fp32", False):
            if p.numel() > 0 and p.data.abs().max().item() <= float(torch.finfo(torch.float16).max):
                p.data = p.data.to(torch.float16)
                p.casa_dtype_sombra = True   # sigue siendo peso sombra (forense SYNC)
            p._casa_slot_fp32 = False
    entrenables = []
    for nombre, p in model.named_parameters():
        if "router" in nombre.lower():
            p.requires_grad = False   # nunca, durante el SFT
        elif tanda.slot is not None and f"experts.{tanda.slot}." in nombre:
            if tanda.capas_phi is None or _capa_dentro_rango(nombre, tanda.capas_phi):
                p.requires_grad = True
                if getattr(p, "casa_dtype_sombra", False):
                    p.data = p.data.float()            # ← restore fp32 slot (acel-Ω)
                    p.casa_dtype_sombra = False
                    p._casa_slot_fp32 = True           # FIX ψ-T1b: marca para re-sombra al cerrar
                entrenables.append(p)
        elif tanda.slot is None and _pertenece_a_tanda_tronco(nombre, tanda.nombre):
            p.requires_grad = True
            entrenables.append(p)

    # #15a (CAMBIOS 94): ancla del slot en el router si el flag está ON (default OFF)
    # CAZA #24 (ARGON/96): este bucle queda FUERA de entrenables. Mi inserción del
    # 94 se coló tras el elif-tronco SIN su append -> tandas emb/attn/shared vacías
    # y 35 copias del último parámetro en entrenables -> ValueError en AdamW.
    ancla = os.environ.get("V4X_ANCLA_SLOT", "0") == "1"
    for bloque in model.modules():
        vr = getattr(bloque, "v4x_router", None)
        if vr is not None:
            vr._forced_slot = (tanda.slot if ancla else None)
    # OPT-1 (CAMBIOS 104): frontera de prefijo congelado SOLO en tandas de experto.
    # Guarda estructural: slot None (emb/attn/shared) -> 0 siempre (cortaría el
    # grafo a los entrenables de tronco de capas inferiores).
    # FIX ψ-T1c (CAMBIOS 221, auditoría Gemini): el `else 18` pisaba Nemotron: con
    # OPT-1 activo las 8 MoE inferiores (capas 1..17) quedaban sin gradiente.
    if tanda.slot is None:
        fgl = 0
    elif tanda.capas_phi is not None:
        fgl = tanda.capas_phi[0]
    elif tanda.slot >= 129:
        fgl = 18   # Qwen vive en 18..47
    else:
        fgl = 1    # Nemotron: primera MoE en capa 1
    bb = getattr(model, "backbone", None)
    if bb is not None:
        bb._first_grad_layer = fgl
    n = sum(p.numel() for p in entrenables)
    print(f"[tanda {tanda.nombre}] params entrenables: {n/1e6:.1f}M | router: congelado")
    assert entrenables, f"tanda {tanda.nombre}: 0 params entrenables -> revisar claves"
    return entrenables


def _capa_dentro_rango(nombre: str, lo_hi: Tuple[int, int]) -> bool:
    for tok in nombre.split("."):
        if tok.isdigit():
            return lo_hi[0] <= int(tok) < lo_hi[1]
    return False


# ---------------------------------------------------------------------------
# SECCIÓN 3 — DATOS: pretokenizado con las REGLAS 73 (ventanas, no truncado)
# Nota: el script que PRODUCE los packs vive aparte (trabajo de la casa);
# aquí solo se CONSUMEN packs tokenizados conforme al contrato:
#   - documentos largos -> ventanas contiguas T=8192 (system+tools al inicio de
#     cada ventana, cierre de trayectoria conservado; sin [:8192] jamás)
#   - brainstorming: reasoning_trace/alternative_hypotheses DENTRO de 12..13
#   - labels: -100 fuera de assistant (w_i=0); packs por estrato 00->13
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# SECCIÓN 3 — DATOS: lector real de packs (CURA-26, contrato 73)
#
# El manifiesto v8 asigna 836 ficheros a 141 tandas, con offset=0 en todos
# (verificado: 836/836). No hay directorio de packs pre-hechos: los packs los
# construye esta celda a partir de las fuentes crudas (json / jsonl / parquet /
# gz). Por eso el lector hace tokenización en streaming, con caché en disco para
# que el coste se pague UNA vez y no por sesión de Kaggle.
#
# Decisión de diseño (acta 258): la caché NO se comprime. zlib sobre 64 KiB por
# pack añade ~1-2 ms de CPU por pack y ahorra disco que en Kaggle sobra. En el
# camino crítico manda el tiempo de GPU, no el disco.
# ---------------------------------------------------------------------------

PACKS_DIR = os.environ.get("V4X_PACKS", os.path.join(OUT_DIR, "packs"))
PREFETCH_PACKS = int(os.environ.get("V4X_PREFETCH", "8"))
SALTAR_SIN_SUPERVISION = os.environ.get("V4X_SALTAR_SINSUP", "1") == "1"
TOKENIZER = None          # lo inyecta entrenar() antes de la primera tanda
_ROLES_SUPERVISADOS = ("assistant",)
_RUTAS_CACHE: Dict[str, str] = {}


def _raiz_datos() -> str:
    """Raíz de las fuentes. El manifiesto trae una ruta Windows (C:\\AI-ku_SFT);
    en Kaggle eso no existe. Orden de búsqueda: env > raiz del manifiesto > glob.
    """
    env = os.environ.get("V4X_DATOS")
    if env and os.path.isdir(env):
        return env
    try:
        with open(_ruta_manifiesto(), "r", encoding="utf-8") as f:
            r = json.load(f).get("raiz") or ""
    except Exception:
        r = ""
    if r and os.path.isdir(r):
        return r
    for pat in ("/kaggle/input/*/AI-ku_SFT", "/kaggle/input/*", "/kaggle/working/AI-ku_SFT",
                "/content/drive/MyDrive/AI-ku_SFT"):
        hits = sorted(glob.glob(pat))
        for h in hits:
            if os.path.isdir(h):
                return h
    return r or "/kaggle/input"


def _resolver(rel: str, raiz: str) -> str:
    """Resuelve 'fichero' del manifiesto. Tolera separadores Windows y también
    el caso de que Kaggle haya montado el dataset con un nivel extra."""
    if rel in _RUTAS_CACHE:
        return _RUTAS_CACHE[rel]
    rel = rel.replace("\\", "/").lstrip("/")
    cand = [os.path.join(raiz, rel)]
    base = os.path.basename(rel)
    cand += sorted(glob.glob(os.path.join(raiz, "**", base), recursive=True))
    for c in cand:
        if os.path.isfile(c):
            _RUTAS_CACHE[rel] = c
            return c
    _RUTAS_CACHE[rel] = ""
    return ""


def _abrir_texto(ruta: str):
    if ruta.endswith(".gz"):
        import gzip
        return gzip.open(ruta, "rt", encoding="utf-8", errors="replace")
    return open(ruta, "r", encoding="utf-8", errors="replace")


def _mensajes_de_objeto(obj) -> Optional[List[dict]]:
    """Acepta las formas vistas en el censo: lista de mensajes, {'messages':...},
    {'conversations':...}, {'data':...} y variantes de nombre de campo."""
    if isinstance(obj, list):
        if not obj:
            return None
        if isinstance(obj[0], dict) and ("role" in obj[0] or "from" in obj[0]):
            return obj
        out = []
        for o in obj:
            m = _mensajes_de_objeto(o)
            if m:
                out.extend(m)
        return out or None
    if isinstance(obj, dict):
        for k in ("messages", "conversations", "conversation", "data", "examples", "samples"):
            if k in obj:
                return _mensajes_de_objeto(obj[k])
        if "role" in obj or "from" in obj:
            return [obj]
    return None


def _normalizar_mensaje(m: dict) -> dict:
    """Unifica {'from':'human','value':...} (ShareGPT) con {'role','content'}."""
    rol = m.get("role") or m.get("from") or "user"
    rol = {"human": "user", "gpt": "assistant", "system_prompt": "system"}.get(rol, rol)
    c = m.get("content", m.get("value", ""))
    if isinstance(c, list):   # multimodal: solo las partes de texto
        c = "\n".join(p.get("text", "") for p in c if isinstance(p, dict) and p.get("text"))
    return {"role": rol, "content": "" if c is None else str(c)}


def _docs_de_fichero(ruta: str):
    """Generador de listas de mensajes. Dispatch por extensión real del fichero."""
    baja = ruta.lower()
    base = baja[:-3] if baja.endswith(".gz") else baja
    if base.endswith(".parquet"):
        import pandas as pd
        try:
            df = pd.read_parquet(ruta, columns=None)
        except Exception:
            import pyarrow.parquet as pq
            df = pq.read_table(ruta).to_pandas()
        col = next((c for c in ("messages", "conversations", "conversation", "data",
                                "text", "content") if c in df.columns), None)
        if col is None:
            print(f"!! [packs] {os.path.basename(ruta)}: sin columna de mensajes ({list(df.columns)[:6]})")
            return
        for v in df[col].tolist():
            if isinstance(v, str):
                try:
                    v = json.loads(v)
                except Exception:
                    v = [{"role": "user", "content": v}]
            m = _mensajes_de_objeto(v)
            if m:
                yield [_normalizar_mensaje(x) for x in m]
        return
    if base.endswith(".jsonl") or base.endswith(".ndjson"):
        with _abrir_texto(ruta) as f:
            for linea in f:
                linea = linea.strip()
                if not linea:
                    continue
                try:
                    m = _mensajes_de_objeto(json.loads(linea))
                except Exception:
                    continue
                if m:
                    yield [_normalizar_mensaje(x) for x in m]
        return
    if base.endswith(".json"):
        with _abrir_texto(ruta) as f:
            try:
                obj = json.load(f)
            except Exception as e:
                print(f"!! [packs] {os.path.basename(ruta)}: JSON ilegible ({e})")
                return
        m = _mensajes_de_objeto(obj)
        if m:
            yield [_normalizar_mensaje(x) for x in m]
        return
    print(f"!! [packs] extensión no soportada: {os.path.basename(ruta)}")


def _ids_de_mensajes(tok, msgs: List[dict]):
    """Devuelve (input_ids, labels) con -100 fuera de los turnos assistant.

    Cuatro caminos, del más barato al más tolerante:
      A) return_assistant_tokens_mask=True — sólo si la plantilla trae bloques
         {% generation %}. Medido: la plantilla de Qwen2.5 NO los trae, así que
         en la práctica este camino devuelve máscara nula y se cae al B.
      B) RENDERIZADO DE PREFIJOS EN TEXTO + TOKENIZACIÓN ÚNICA CON OFFSETS.
         Por qué así: el camino ingenuo (tokenizar cada prefijo) es O(n²) en
         TOKENIZACIONES y con documentos de 60 turnos eso domina el arranque de
         la tanda. Aquí se renderiza O(n²) en CARACTERES (barato, Python puro) y
         se tokeniza UNA sola vez, mapeando los tramos de carácter a tokens con
         return_offsets_mapping. Requiere tokenizador rápido (el de Kaggle lo es).
      C) tokenización de prefijos — último recurso si no hay offsets.
      D) sin plantilla: marcadores TOK de la regla 73 y máscara manual.
    """
    if not msgs:
        return [], []
    tener_plantilla = getattr(tok, "chat_template", None) is not None
    if tener_plantilla:
        # --- A ---
        try:
            out = tok.apply_chat_template(msgs, tokenize=True, add_generation_prompt=False,
                                          return_assistant_tokens_mask=True)
            ids, mask = (out["input_ids"], out["assistant_masks"]) if isinstance(out, dict) \
                else (out[0], out[1]) if isinstance(out, tuple) and len(out) == 2 else (out, None)
            if mask is not None and len(mask) == len(ids) and any(mask):
                return list(ids), [-100 if m == 0 else int(t) for t, m in zip(ids, mask)]
        except Exception:
            pass
        # --- B ---
        try:
            textos = [""] + [tok.apply_chat_template(msgs[:k], tokenize=False,
                                                     add_generation_prompt=False)
                             for k in range(1, len(msgs) + 1)]
            cadena_ok = all(textos[k].startswith(textos[k - 1]) for k in range(1, len(textos)))
            if cadena_ok:
                full = textos[-1]
                enc = tok(full, add_special_tokens=False, return_offsets_mapping=True)
                ids = list(enc["input_ids"])
                offs = enc["offset_mapping"]
                mask = [0] * len(ids)
                for k in range(1, len(msgs) + 1):
                    if msgs[k - 1]["role"] not in _ROLES_SUPERVISADOS:
                        continue
                    a, b = len(textos[k - 1]), len(textos[k])
                    for j, (o0, o1) in enumerate(offs):
                        if o1 > o0 and o0 >= a and o1 <= b:
                            mask[j] = 1
                if any(mask):
                    return ids, [-100 if m == 0 else int(t) for t, m in zip(ids, mask)]
        except Exception:
            pass
        # --- C ---
        try:
            ids_prev: List[int] = []
            ids_tot: List[int] = []
            lab: List[int] = []
            for k in range(1, len(msgs) + 1):
                ids_act = list(tok.apply_chat_template(msgs[:k], tokenize=True,
                                                       add_generation_prompt=False))
                trozo = ids_act[len(ids_prev):]
                sup = msgs[k - 1]["role"] in _ROLES_SUPERVISADOS
                ids_tot.extend(trozo)
                lab.extend(list(trozo) if sup else [-100] * len(trozo))
                ids_prev = ids_act
            if ids_tot:
                return ids_tot, lab
        except Exception:
            pass
    # --- D ---
    ids_tot, lab = [TOK["start"]], [-100]
    for m in msgs:
        trozo = tok(str(m["content"]), add_special_tokens=False)["input_ids"]
        sup = m["role"] in _ROLES_SUPERVISADOS
        ids_tot.extend(trozo)
        lab.extend(list(trozo) if sup else [-100] * len(trozo))
        ids_tot.append(TOK["end"])
        lab.append(TOK["end"] if sup else -100)
    return ids_tot, lab


def _eos_id(tok) -> int:
    for a in ("eos_token_id", "pad_token_id"):
        v = getattr(tok, a, None)
        if isinstance(v, int):
            return v
    return TOK["end"]


def _pack_path(tanda: Tanda, i: int) -> str:
    d = os.path.join(PACKS_DIR, tanda.nombre.replace("/", "__"))
    return os.path.join(d, "p%06d.bin" % i)


def _escribir_pack(ruta: str, ids, labels, T: int) -> None:
    import numpy as np
    os.makedirs(os.path.dirname(ruta), exist_ok=True)
    arr = np.empty((2, T), dtype=np.int32)
    arr[0, :len(ids)] = ids
    arr[1, :len(labels)] = labels
    if len(ids) < T:
        arr[0, len(ids):] = 0
        arr[1, len(ids):] = -100
    tmp = ruta + ".tmp"
    with open(tmp, "wb") as f:
        f.write(arr.tobytes())
        f.flush(); os.fsync(f.fileno())
    os.replace(tmp, ruta)


def _leer_pack(ruta: str, T: int):
    import numpy as np
    import torch
    a = np.fromfile(ruta, dtype=np.int32)
    if a.size != 2 * T:
        raise ValueError(f"pack corrupto {ruta}: {a.size} != {2*T}")
    ids = torch.from_numpy(a[:T].astype(np.int64)).unsqueeze(0)
    lab = torch.from_numpy(a[T:].astype(np.int64)).unsqueeze(0)
    return ids, lab


def _indice_tanda(tanda: Tanda) -> str:
    return os.path.join(PACKS_DIR, tanda.nombre.replace("/", "__"), "_index.json")


def _construir_packs(tanda: Tanda, raiz: str) -> int:
    """Tokeniza la tanda entera a caché .bin. Devuelve nº de packs escritos."""
    if TOKENIZER is None:
        raise RuntimeError("TOKENIZER no inicializado: el manifiesto necesita un "
                           "tokenizador para construir packs (regla 73).")
    T = int(tanda.T or T_TOKENS)
    _necesario_gb = (tanda.tokens_total / T) * 2 * T * 4 / 1e9
    _libre = _espacio_libre_gb(PACKS_DIR)
    if _libre == _libre and _libre < _necesario_gb * 1.2:
        raise RuntimeError(
            f"disco insuficiente para la tanda {tanda.nombre}: necesita "
            f"{_necesario_gb:.1f} GB y quedan {_libre:.1f} GB. Poda "
            f"V4X_PACKS o sube V4X_PODA_PACKS=1.")
    eos = _eos_id(TOKENIZER)
    buf_i: List[int] = []
    buf_l: List[int] = []
    n = 0
    faltan = []
    for linea in tanda.lineas:
        ruta = _resolver(linea["fichero"], raiz)
        if not ruta:
            faltan.append(linea["fichero"])
            continue
        vistos = 0
        for msgs in _docs_de_fichero(ruta):
            try:
                ids, lab = _ids_de_mensajes(TOKENIZER, msgs)
            except Exception:
                continue
            if not ids:
                continue
            # El EOS de cierre SOLO se supervisa si el documento acaba en turno
            # assistant: se entrena a "terminar mi turno", no a cerrar el del
            # usuario. Si acaba en user/tool, ese EOS es contexto (-100).
            _sup = msgs[-1]["role"] in _ROLES_SUPERVISADOS
            ids.append(eos); lab.append(eos if _sup else -100)
            vistos += len(ids)
            buf_i.extend(ids); buf_l.extend(lab)
            while len(buf_i) >= T:                    # ventanas CONTIGUAS
                _escribir_pack(_pack_path(tanda, n), buf_i[:T], buf_l[:T], T)
                n += 1
                del buf_i[:T]; del buf_l[:T]
        if vistos == 0:
            print(f"!! [packs] {linea['fichero']}: 0 tokens (¿formato?)")
    if any(l != -100 for l in buf_l):                 # cola: una ventana parcial más
        _escribir_pack(_pack_path(tanda, n), buf_i, buf_l, T)
        n += 1
    idx = {"tanda": tanda.nombre, "T": T, "packs": n,
           "tokens": n * T,   # incluye relleno de la última ventana parcial
           "ficheros": len(tanda.lineas) - len(faltan), "faltan": faltan[:12]}
    with open(_indice_tanda(tanda), "w", encoding="utf-8") as f:
        json.dump(idx, f)
    if faltan:
        print(f"!! [packs] {len(faltan)} ficheros NO encontrados; ej: {faltan[:3]}")
    return n


PODA_PACKS = os.environ.get("V4X_PODA_PACKS", "1") == "1"


def _poda_packs(tanda: Tanda) -> None:
    """Borra la caché de packs de una tanda ya completada.

    ARITMÉTICA QUE OBLIGA A ESTO (medida, no estimada):
      pack T=8192 = 2 x 8192 x 4 B = 65.536 B
      1.974.760.183 tok / 8192  = 241.060 packs = 15,80 GB
    Kaggle da 20 GB en /kaggle/working. Los packs de TODO el manifiesto dejan
    el disco sin sitio para checkpoints. Reconstruir una tanda cuesta ~43 s de
    CPU de media (medido: 325 Ktok/s por núcleo); perder una sesión de GPU
    cuesta horas. Se poda.
    """
    if not PODA_PACKS:
        return
    import shutil
    d = os.path.join(PACKS_DIR, tanda.nombre.replace("/", "__"))
    if os.path.isdir(d):
        shutil.rmtree(d, ignore_errors=True)
        print(f"[packs] caché podada: {tanda.nombre}")


def _espacio_libre_gb(ruta: str) -> float:
    try:
        st = os.statvfs(ruta if os.path.isdir(ruta) else os.path.dirname(ruta) or ".")
        return st.f_bavail * st.f_frsize / 1e9
    except Exception:
        return float("nan")


def _productor(tanda: Tanda, raiz: str, cola, desde: int) -> None:
    """Hilo productor: lee packs de disco (o los construye) y los encola."""
    T = int(tanda.T or T_TOKENS)
    idx_p = _indice_tanda(tanda)
    n = 0
    if os.path.isfile(idx_p):
        try:
            n = int(json.load(open(idx_p, encoding="utf-8"))["packs"])
        except Exception:
            n = 0
    if n == 0 or (n and not os.path.isfile(_pack_path(tanda, n - 1))):
        print(f"[packs] {tanda.nombre}: construyendo caché (T={T})…")
        t0 = time.time()
        n = _construir_packs(tanda, raiz)
        print(f"[packs] {tanda.nombre}: {n} packs en {time.time()-t0:.1f}s "
              f"({n*T/1e6:.1f}M tok)")
    for i in range(desde, n):
        cola.put(_leer_pack(_pack_path(tanda, i), T))
    cola.put(None)


def iter_packs(tanda: Tanda, desde_packs: int = 0):
    """Generador de (input_ids[1,T], labels[1,T]) para una tanda."""
    import queue
    import threading
    raiz = _raiz_datos()
    cola: "queue.Queue" = queue.Queue(maxsize=max(1, PREFETCH_PACKS))
    th = threading.Thread(target=_productor, args=(tanda, raiz, cola, desde_packs),
                          daemon=True)
    th.start()
    saltados = 0
    while True:
        item = cola.get()
        if item is None:
            break
        ids, lab = item
        if SALTAR_SIN_SUPERVISION and not bool((lab != -100).any()):
            saltados += 1
            continue                      # fwd+bwd de coste pleno y gradiente 0
        yield ids, lab
    if saltados:
        print(f"[packs] {tanda.nombre}: {saltados} packs sin supervisión saltados "
              f"({saltados*int(tanda.T or T_TOKENS)/1e6:.1f}M tok de cómputo ahorrado)")

# ---------------------------------------------------------------------------
# SECCIÓN 4 — PASO DE ENTRENAMIENTO (full-SFT, sin model.eval(), CE-chunk)
# CE-chunk (P8 de Opus): la CE sobre 204.800 x tokens jamás se materializa
# entera; se computa por chunks de 4096 tokens en el lm_head.
# ---------------------------------------------------------------------------


def ce_chunk(model, hidden, labels, lm_head, chunk: int = 4096, pesos: torch.Tensor = None) -> torch.Tensor:
    """Cross-entropy por chunks (P8) con shift causal, eje T correcto y w_mult.

    CAZA ARGON #2 (CAMBIOS 81): hidden [B,T,H] -> [-1,H]; shift h[:-1]/y[1:];
    checkpoint por chunk (CAMBIOS 77).
    CAMBIOS 88 (firma usuario "lo mismo en menos tiempo"): `pesos` mismo shape que
    `labels` (None = uniforme) — sustituye el upsampling FÍSICO de los gigantes
    por peso de loss w_mult {1.0, 1.25, 1.5}: efecto idéntico, ~3.000M pasadas menos.
    """
    shift_h = hidden[..., :-1, :].contiguous().view(-1, hidden.size(-1))
    shift_y = labels[..., 1:].contiguous().view(-1).to(shift_h.device)
    # OPT-6 (CAMBIOS 94): compacción de posiciones -100 ANTES de lm_head. z_t = W·h_t
    # es punto a punto: los -100 aportan exactamente 0 a la pérdida y al gradiente.
    valid = shift_y.ne(-100)
    if not bool(valid.any()):
        return shift_h.sum() * 0.0   # ventana 100% contexto: pérdida 0 diferenciable
    if pesos is not None:
        shift_w = pesos[..., 1:].contiguous().view(-1).to(shift_h.device, torch.float32)
    else:
        shift_w = None
    if not bool(valid.all()):
        shift_h = shift_h[valid]
        shift_y = shift_y[valid]
        if shift_w is not None:
            shift_w = shift_w[valid]
    if shift_w is not None:  # w_mult: peso del token a predecir
        count = shift_w.sum().clamp_min(1e-9)

        def _piece(h, y, w):
            ce = torch.nn.functional.cross_entropy(
                lm_head(h.to(lm_head.weight.dtype)).float(), y,
                ignore_index=-100, reduction="none")
            return (ce * w).sum()
    else:
        count = float(max(int(shift_y.numel()), 1))

        def _piece(h, y):
            return torch.nn.functional.cross_entropy(
                lm_head(h.to(lm_head.weight.dtype)).float(), y,
                ignore_index=-100, reduction="sum")

    total = shift_h.new_zeros((), dtype=torch.float32)
    for i in range(0, shift_h.size(0), chunk):
        h_c, y_c = shift_h[i:i + chunk], shift_y[i:i + chunk]
        if not bool((y_c != -100).any()):
            continue
        args = (h_c, y_c) if pesos is None else (h_c, y_c, shift_w[i:i + chunk])
        if model.training and h_c.requires_grad:
            total = total + torch.utils.checkpoint.checkpoint(_piece, *args, use_reentrant=False)
        else:
            total = total + _piece(*args)
    return total / count


def paso_entrenamiento(model, packs_vistos: int, scaler=None) -> int:
    """CAZA #16b (CAMBIOS 92): yield en cada GRAD_ACCUM micros + cola final de
    tanda; suma_loss por ventana (antes se inflaba desde el 2º yield).
    CAZA #19: GradScaler fp16 en el backward (underflow fp16 sin scaler)."""
    # FIX ψ-17 (CAMBIOS 222, auditoría Gemini): float(loss) por micro disparaba
    # cudaStreamSynchronize() bloqueante ×8 por step. Ahora el acumulador vive en
    # GPU (escalar 0-D) y solo baja a CPU en el yield de GRAD_ACCUM. Misma suma.
    suma_loss, micros, acc, saltadas = None, 0, 0, 0
    turbo1 = os.environ.get("V4X_TURBO1", "0") == "1"   # TURBO-1a (CAMBIOS 104)
    autocast_ctx = torch.autocast("cuda", dtype=torch.float16) if AUTOCAST_FP16 else torch.autocast("cuda", dtype=torch.bfloat16)
    for input_ids, labels in iter_packs_actual:
        # TURBO-1a (CAMBIOS 104): recorte de cola tras el ÚLTIMO label supervisado.
        # Causalidad estricta: ningún token t > t_end influye en t <= t_end -> exacto.
        if turbo1 and labels.shape[1] > 1:
            _nz = (labels != -100).nonzero()
            if _nz.numel() > 0:
                _t_end = max(int(_nz[:, 1].max()) + 1, 2)
                # ψ-26: redondear hacia ARRIBA al múltiplo de 128 (chunks Mamba).
                # Alargar con contexto real es causalmente inocuo: tokens extra
                # (t >= t_end) nunca influyen en los supervisados (t < t_end).
                _t_end = min(labels.shape[1], ((_t_end + 127) // 128) * 128)
                if _t_end < labels.shape[1]:
                    input_ids = input_ids[:, :_t_end]
                    labels = labels[:, :_t_end]
        # CAZA #26 (ARGON/96): ventana 100% contexto (-100 en todo labels[:, 1:])
        # devolvia loss=0 con grafo vivo -> el backward RECOMPUTABA las 52 capas
        # para acumular 0 (~10,4 EF muertos en prefijos LongCtx). Comprobado en CPU
        # (0 syncs GPU): se salta forward+backward. OPT-7 reintroducira el forward
        # no_grad de calentado (TBPTT P12) a nivel motor.
        supervisado = bool((labels[:, 1:] != -100).any())
        if supervisado:
            input_ids, labels = input_ids.cuda(), labels.cuda()
            with autocast_ctx:
                # FIX ψ-T4a (CAMBIOS 221, auditoría Gemini): llamar a model(...) con
                # labels=None devuelve out.loss=None y disparaba el marcador
                # _loss_desde_hidden (NotImplementedError) -> entrenar() moría en el
                # primer micro supervisado. Vía legal: backbone + ce_chunk existente.
                # FIX-06b: la máscara phi-span vive en V4XForCausalLM.forward; al ir
                # por backbone la cableamos aquí con EL MISMO helper del modeling
                # (modeling intocable: reuso de su función, semántica idéntica).
                if getattr(model.config, "v4x_phi_span_mask", False):
                    import modeling_v4x as _M
                    if not hasattr(model, "_cached_v4x_routers"):
                        object.__setattr__(model, "_cached_v4x_routers",
                            tuple(m for m in model.modules() if isinstance(m, _M.V4XRouter)))
                    _span, _ = _M._v4x_build_phi_span_mask(input_ids, prev_in_think=None)
                    for _r in model._cached_v4x_routers:
                        _r._phi_span_mask = _span.reshape(-1)
                bb_out = model.backbone(input_ids=input_ids, use_cache=False)
                hidden = bb_out.last_hidden_state if hasattr(bb_out, "last_hidden_state") else bb_out[0]
                loss = ce_chunk(model, hidden, labels, model.lm_head) / GRAD_ACCUM   # #23a (CAMBIOS 94): /GRAD_ACCUM SIEMPRE
            (scaler.scale(loss) if scaler is not None else loss).backward()
            suma_loss = loss.detach() * GRAD_ACCUM if suma_loss is None else suma_loss + loss.detach() * GRAD_ACCUM
        else:
            saltadas += 1
        micros += 1   # packs consumidos del manifiesto (cuentan siempre)
        # CAZA #27 (ARGON/98, sobre mi parche #26 del 96): acc/yield SOLO en micros
        # SUPERVISADOS. Antes: 8 skips seguidos -> yield con 0 backward -> GradScaler
        # abortaba ("No inf checks were recorded") en Oro/LongCtx; y con k<8 skips,
        # el grupo de 8 traia solo 8-k backward -> gradiente diluido (8-k)/8 (interaccion
        # con #23a: /GRAD_ACCUM siempre). Ahora el divisor y el paso cuentan lo mismo.
        if supervisado:
            acc += 1
            if acc == GRAD_ACCUM:
                yield packs_vistos + micros, float(suma_loss) / acc   # ψ-17: única sync por step
                suma_loss, acc = None, 0
    if saltadas:
        print(f"[#26] ventanas 100% -100 saltadas (0 compute muerto): {saltadas}")
    if acc:   # caza #16: la cola de tanda (< GRAD_ACCUM micros) TAMBIÉN actualiza
        assert suma_loss is not None, "acc>0 sin pérdida acumulada: revisar bucle ψ-17"
        yield packs_vistos + micros, float(suma_loss) / acc   # ψ-17 idem en cola de tanda


def _loss_desde_hidden(out, labels):
    raise NotImplementedError("CE-chunk real llega con el motor P2 (lm_head chunked)")


# ---------------------------------------------------------------------------
# SECCIÓN 5 — OPTIMIZADOR (estados por capa a temp ≡ P1(b); llave-1 pendiente)
# Decreto vivo: aislamiento en optimizador por tanda. La elección AdamW-(b) vs
# Muon-capas sigue EN MANO DEL USUARIO (llave 1, 70): aquí el interfaz neutro.
# ---------------------------------------------------------------------------


def construir_optimizador(entrenables, tanda: Tanda):
    """PENDIENTE llave 1. De momento: AdamW fp32 master + estados efímeros por
    capa evacuados a /tmp (P1(b) adoptado 68); Muon queda como backend 'muon'
    certificable por el A/B del piloto."""
    backend = os.environ.get("V4X_OPT", "adamw_temp")
    assert backend in ("adamw_temp", "muon_temp"), f"optimizador desconocido: {backend}"
    if backend == "muon_temp":
        print("[opt] PENDIENTE certificación del piloto: Muon-capas (llave 1)")
        raise NotImplementedError("Muon se activa tras el A/B del piloto (llave 1)")
    lr_tanda = tanda.lr if tanda.lr > 0 else LR          # receta por tanda (DISC-10)
    # FIX ψ-T7a (CAMBIOS 221, auditoría Gemini): fused=True en CUDA = 1 kernel por
    # paso en lugar del bucle multi-kernel. Numéricamente idéntico (mismo algoritmo
    # AdamW); si el torch del lane no lo soporta, cae al clásico.
    _fused = torch.cuda.is_available() and os.environ.get("V4X_ADAMW_NOFUSED", "0") != "1"
    try:
        opt = torch.optim.AdamW(entrenables, lr=lr_tanda, betas=(0.9, 0.95), weight_decay=0.1, fused=True) if _fused \
            else torch.optim.AdamW(entrenables, lr=lr_tanda, betas=(0.9, 0.95), weight_decay=0.1)
    except TypeError:
        opt = torch.optim.AdamW(entrenables, lr=lr_tanda, betas=(0.9, 0.95), weight_decay=0.1)
    print(f"  [receta] {tanda.nombre}: lr={lr_tanda:g} · T={tanda.T}")
    for g in opt.param_groups:
        g["_base_lr"] = g["lr"]   # #23b: rampa warmup (WARMUP_STEPS estaba sin conectar)
    # P1(b): hook de evacuación de estados a /tmp por capa — llega con el motor.
    return opt


# ---------------------------------------------------------------------------
# SECCIÓN 6 — CONSTANTES DEL NOTARIO (p0_microbench.json o defaults POROSÍA)
# Sin este archivo, TODO número de throughput sigue siendo papel (68-72).
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# SECCIÓN 0b — MEDIDOR DE MFU (CURA-25)
# El MFU es LA constante que decide si una tanda cabe en 12 h. Se mide con un
# contador en GPU y una sola lectura por ventana; nunca por micro.
# ---------------------------------------------------------------------------

FLOP_TOK_FWD = float(os.environ.get("V4X_FLOP_TOK", "14.18e9"))  # certificado en p0


def _gpus_visibles() -> int:
    try:
        return max(1, torch.cuda.device_count())
    except Exception:
        return 1


def mfu(packs: int, T: int, segundos: float, tf_peak_por_gpu: float = 21.8) -> Dict:
    """MFU = FLOPs útiles / FLOPs de pico. fwd+bwd se modela como 3× el forward.

    OJO: el factor 2× del backward es el estándar para atención/MLP; MoE con
    expertos congelados baja de 3× porque no hay wgrad en el 99 % de los params.
    Por eso el valor que devuelve es una COTA SUPERIOR del coste, y por tanto una
    COTA INFERIOR del MFU real. Si sale >100 %, el factor 3× no aplica: manda el
    tok/s medido.
    """
    if segundos <= 0 or packs <= 0:
        return {"tok_s": 0.0, "mfu_pct": 0.0, "flop_tok": FLOP_TOK_FWD}
    tok_s = packs * T / segundos
    flops = 3.0 * FLOP_TOK_FWD
    pico = tf_peak_por_gpu * 1e12 * _gpus_visibles()
    return {"tok_s": round(tok_s, 1),
            "mfu_pct": round(100.0 * tok_s * flops / pico, 2),
            "flop_tok": flops,
            "gpus": _gpus_visibles(),
            "pico_tf": round(pico / 1e12, 1)}

def _recortar(gen, limite: Optional[int]):
    """Corta un generador tras `limite` elementos (modo piloto)."""
    if limite is None:
        yield from gen
        return
    n = 0
    for x in gen:
        yield x
        n += 1
        if n >= limite:
            return


def cargar_p0(ruta: str = os.path.join(V4X_REPO, "p0_microbench.json")) -> dict:
    defaults = {
        "estado": "POESÍA (defaults, no validados)",
        # CAZA ARGON #9 (CAMBIOS 81): sm_75 tiene TC fp16 nativos; bf16 NO.
        # CURA-22 (acta 258): los valores anteriores (65 / 8 TF) eran el PICO DE
        # FICHA, no lo medido. Argon midió 21,2 TF fp16 y 2,25 TF bf16 en la T4.
        # Los defaults anteriores sobreestimaban 3,07x y 3,56x: cualquier decisión
        # de scheduling tomada con ellos era papel. Ahora llevan lo medido.
        "disco_mbs": 500.0, "h2d_gbs": 8.5,
        "gemm_fp16_ts": 21.2, "gemm_bf16_ts": 2.25,
        "einsum_ok_ssd": None, "T_recomendado": T_TOKENS, "grad_accum_reco": GRAD_ACCUM,
    }
    if os.path.exists(ruta):
        with open(ruta) as f:
            p0 = json.load(f)
        p0 = _normalizar_p0(p0)
        p0["estado"] = "NOTARIZADO"
        _verificar_notario(p0)
        return p0
    print("!! p0_microbench.json no encontrado -> constantes en MODO POESÍA")
    print(f"   [p0] usando {defaults['gemm_fp16_ts']} TF fp16 / "
          f"{defaults['gemm_bf16_ts']} TF bf16 (MEDIDOS por Argon, no ficha)")
    return defaults


def _normalizar_p0(p0: dict) -> dict:
    """CURA-23 (acta 258): el p0_microbench.json REAL tiene otro esquema que el
    que esta celda esperaba. El de campo (`p0_microbench_v1`) trae bloques
    anidados:

        {"gemm": {"float16": {"TFLOPs": 21.8}, "bfloat16": {"TFLOPs": 1.9}},
         "h2d":  {"cuda0": 11.44, ...},
         "disco": {"error": "..."},
         "wgrad0": {"ratio_ponderado_52capas": 0.709, "gf_tok_certificado": 14.18}}

    y la celda leia `p0['gemm_fp16_ts']` / `p0['T_recomendado']` planos. Sin este
    adaptador, cargar el JSON de campo marcaba NOTARIZADO y acto seguido
    `print(p0['T_recomendado'])` lanzaba KeyError: la celda moria en la primera
    linea de entrenar(), ANTES de tocar la GPU.

    Acepta ambos esquemas y sanea lo fisicamente imposible.
    """
    plano = dict(p0)
    gemm = p0.get("gemm", {}) if isinstance(p0.get("gemm"), dict) else {}
    h2d = p0.get("h2d", {}) if isinstance(p0.get("h2d"), dict) else {}
    disco = p0.get("disco", {}) if isinstance(p0.get("disco"), dict) else {}
    wg = p0.get("wgrad0", {}) if isinstance(p0.get("wgrad0"), dict) else {}

    def _tf(bloque, clave="TFLOPs"):
        d = gemm.get(bloque)
        return d.get(clave) if isinstance(d, dict) else None

    mapa = {
        "gemm_fp16_ts": _tf("float16"),
        "gemm_bf16_ts": _tf("bfloat16"),
        "h2d_gbs": h2d.get("cuda0"),
        "disco_mbs": disco.get("mbs", disco.get("MBs")),
        "gf_tok": wg.get("gf_tok_certificado"),
        "ratio_wgrad0": wg.get("ratio_ponderado_52capas"),
    }
    for k, v in mapa.items():
        if k not in plano and v is not None:
            plano[k] = v
    plano.setdefault("T_recomendado", T_TOKENS)
    plano.setdefault("grad_accum_reco", GRAD_ACCUM)

    # --- saneo fisico: PCIe 3.0 x16 = 15,75 GB/s teoricos, ~12 reales ---
    h = plano.get("h2d_gbs")
    if isinstance(h, (int, float)) and h > 15.75:
        print(f"!! [p0] h2d_gbs={h} GB/s es IMPOSIBLE en PCIe 3.0 (max teorico 15,75).")
        print("   Descartado: se usan los 8,5 de referencia. Revisa el microbench:")
        print("   un valor asi suele ser una copia que NO cruzo el bus (tensor ya")
        print("   residente, pageable, o el medidor contando L2).")
        plano["h2d_gbs"] = 8.5
        plano["_h2d_descartado"] = h
    for k in ("gemm_fp16_ts", "gemm_bf16_ts"):
        v = plano.get(k)
        if isinstance(v, (int, float)) and v > 30.0:
            print(f"!! [p0] {k}={v} TF parece pico de ficha, no medicion.")
    return plano


def _verificar_notario(p0: dict) -> None:
    """CURA-22 (acta 258): el notario estaba DESCONECTADO del motor.

    p0['T_recomendado'] y p0['grad_accum_reco'] se imprimían pero NO alimentaban
    nada: el motor usa T_TOKENS y GRAD_ACCUM, constantes de módulo. Un JSON que
    dijera accum=4 no cambiaba nada y nadie se enteraba. Aquí se cierra el agujero:
    si el notario discrepa del motor, se aborta con el motivo a la vista.
    """
    discrepancias = []
    if int(p0.get("T_recomendado", T_TOKENS)) != T_TOKENS:
        discrepancias.append(
            f"T_recomendado={p0['T_recomendado']} vs T_TOKENS={T_TOKENS}")
    if int(p0.get("grad_accum_reco", GRAD_ACCUM)) != GRAD_ACCUM:
        discrepancias.append(
            f"grad_accum_reco={p0['grad_accum_reco']} vs GRAD_ACCUM={GRAD_ACCUM}")
    for k in ("gemm_fp16_ts", "gemm_bf16_ts"):
        if k in p0 and p0[k] > 30.0:
            discrepancias.append(
                f"{k}={p0[k]} parece PICO DE FICHA, no medición (la T4 da ~21,2 fp16)")
    if discrepancias:
        raise AssertionError(
            "NOTARIO INCOHERENTE (CURA-22): el p0_microbench.json no describe el motor "
            "que se va a ejecutar:\n  - " + "\n  - ".join(discrepancias) +
            "\nRe-notariza con p0_microbench.json coherente o borra el archivo.")
    print("[p0] notario COHERENTE con el motor (T, accum y TFLOPS medidos)")


# ---------------------------------------------------------------------------
# SECCIÓN 7 — LOOP PRINCIPAL DE TANDAS (curriculum 57 + checkpoints por slot)
# ---------------------------------------------------------------------------


def entrenar(ruta_manifesto: str):
    p0 = cargar_p0()
    print(f"[p0] estado: {p0['estado']} | T={p0['T_recomendado']} | accum={p0['grad_accum_reco']}")

    tandas = leer_manifiesto(ruta_manifesto)

    # CURA-26: selección de tandas. Sin esto, el piloto de 3 tandas empieza por
    # 177/sub_0..sub_2 (Phi) y muere por VRAM antes de medir nada: el
    # presupuesto de Phi es 58,81 GiB sobre 29 GiB. V4X_TANDAS=39,155,139
    # pilota sobre slots que SÍ caben.
    _filtro = [x.strip() for x in os.environ.get("V4X_TANDAS", "").split(",") if x.strip()]
    if _filtro:
        antes = len(tandas)
        tandas = [t for t in tandas if any(f == t.nombre or f == str(t.slot) for f in _filtro)]
        print(f"[tandas] filtro V4X_TANDAS={_filtro}: {antes} -> {len(tandas)}")
        if not tandas:
            raise SystemExit("V4X_TANDAS no casa con ninguna tanda del manifiesto")

    # CURA-26: el lector de packs necesita el tokenizador del REPO. Es el único
    # punto donde se fija; si falta, iter_packs aborta con mensaje explícito en
    # vez de entrenar sobre ids inventados.
    global TOKENIZER
    try:
        from transformers import AutoTokenizer
        TOKENIZER = AutoTokenizer.from_pretrained(V4X_REPO, trust_remote_code=True)
        if TOKENIZER.pad_token_id is None and TOKENIZER.eos_token_id is not None:
            TOKENIZER.pad_token = TOKENIZER.eos_token
        print(f"[packs] tokenizador: vocab {len(TOKENIZER)} | "
              f"plantilla={'sí' if TOKENIZER.chat_template else 'NO (camino C)'}")
    except Exception as e:
        raise RuntimeError(f"tokenizador no cargable de {V4X_REPO}: {e}")

    model = cargar_modelo()
    if os.environ.get("V4X_ACEL_BF16", "1") == "1":
        try:
            # FIX ψ-T1a (CAMBIOS 221, auditoría Gemini confirmada por casa):
            # instalar_sombra_fp16 tiene guardia `if p.requires_grad: skip` y tras
            # V4XForCausalLM(cfg) TODO nace con requires_grad=True -> convertidos=0
            # y el entrenamiento quedaba ENTERO en bf16 emulado (2,25 TFLOPS).
            # Orden legal: congelar todo primero; fijar_router re-activa por tanda.
            for p in model.parameters():
                p.requires_grad_(False)
            from acel_BF16_TURING import instalar_sombra_fp16
            SOMBRA = instalar_sombra_fp16(model)
            print(f"[acel-Ω] sombra fp16 instalada: {SOMBRA}")
        except ImportError:
            print("[acel-Ω] acel_BF16_TURING.py no en path — corre sin sombra (legado)")
    model.train()  # NUNCA model.eval() (saneamiento; la trampa se documentó en 56)

    _st0 = _estado_runs()
    hechas = set(_st0.get("completadas", []))
    if hechas:
        print(f"[ckpt] reanudando: {len(hechas)} tandas ya completadas de {len(tandas)}")

    for ti, tanda in enumerate(tandas):
        if tanda.nombre in hechas:
            print(f"\n##### SKIP {ti+1}/{len(tandas)}: {tanda.nombre} (ya completada)")
            continue
        print(f"\n##### TANDA {ti+1}/{len(tandas)}: {tanda.nombre} ({tanda.tokens_total/1e6:.1f}M tok)")
        _presupuesto_tanda(tanda, TOK_S_ESTIMADO)
        entrenables = fijar_router_y_requires_grad(model, tanda)
        opt = construir_optimizador(entrenables, tanda)

        inicio = time.time()
        packs = 0
        loss, _tok_s = None, 0.0   # CURA-26: si la tanda no emite ni un pack
                                   # (p. ej. todo contexto sin supervisión), el
                                   # cierre no puede leer variables sin definir.
        scaler = torch.amp.GradScaler("cuda") if AUTOCAST_FP16 else None   # caza #19
        pasos_opt = 0   # #23b: contador para la rampa warmup
        global iter_packs_actual  # el motor la sustituirá por clase Dataset real
        # CURA-26: reanudación a MITAD de tanda. El cursor lo escribía CURA-24
        # pero nadie lo leía: se rehacía la tanda desde el pack 0 (hasta 134 h
        # de 177/sub_2 tiradas a la basura en la 2.ª sesión).
        _en_curso = (_st0.get("en_curso") or {})
        desde = int(_en_curso.get("packs_vistos", 0)) if _en_curso.get("tanda") == tanda.nombre else 0
        if desde:
            print(f"[ckpt] reanudando {tanda.nombre} desde el pack {desde:,}")
        iter_packs_actual = iter_packs(tanda, desde_packs=desde)
        _limite = PILOTO_PACKS if PILOTO_PACKS > 0 else None
        for step, loss in _recortar(paso_entrenamiento(model, packs, scaler), _limite):
            packs = step
            # CAZA #16 (CAMBIOS 92): opt.step en CADA ventana acumulada (antes
            # solo 1 de cada 10: gradiente 10x inflado y colas <80 packs perdidas).
            pasos_opt += 1
            if WARMUP_STEPS and pasos_opt <= WARMUP_STEPS:   # #23b: warmup conectado (CAMBIOS 94)
                for g in opt.param_groups:
                    g["lr"] = g["_base_lr"] * pasos_opt / WARMUP_STEPS
            if scaler is not None:
                scaler.unscale_(opt)
                torch.nn.utils.clip_grad_norm_(
                    [p for grp in opt.param_groups for p in grp["params"] if p.grad is not None], 1.0)
                scaler.step(opt); scaler.update()
            else:
                torch.nn.utils.clip_grad_norm_(
                    [p for grp in opt.param_groups for p in grp["params"] if p.grad is not None], 1.0)
                opt.step()
            opt.zero_grad(set_to_none=True)
            _tok_s = packs * T_TOKENS / max(time.time() - inicio, 1e-9)
            if step % (GRAD_ACCUM * 10) == 0:   # ahora SOLO telemetría
                print(f"  step {step}: loss {loss:.4f} | {_tok_s:.0f} tok/s")
            # CURA-24: checkpoint periódico con cursor (reanudable a mitad de tanda).
            # Cada CKPT_CADA_PASOS pasos de optimizador = cada CKPT_CADA*GRAD_ACCUM packs.
            if CKPT_CADA_PASOS and pasos_opt % CKPT_CADA_PASOS == 0:
                _checkpoint_tanda(model, tanda, opt=opt, cursor=packs, loss=loss)
                _guardar_tok_s(tanda.nombre, _tok_s)

        _checkpoint_tanda(model, tanda, opt=opt, cursor=None, loss=loss,
                          completar=(PILOTO_PACKS == 0))
        _guardar_tok_s(tanda.nombre, _tok_s)
        if PILOTO_PACKS > 0:
            print(f"[piloto] {tanda.nombre}: {packs} packs a {_tok_s:.0f} tok/s | "
                  f"MFU {mfu(1, T_TOKENS, T_TOKENS/max(_tok_s,1e-9))['mfu_pct']:.1f} %")
        else:
            _poda_packs(tanda)   # CURA-26: 15,8 GB de packs no caben junto a los ckpt
        print(f"##### FIN {tanda.nombre}: {(time.time()-inicio)/3600:.2f}h")


# ---------------------------------------------------------------------------
# SECCIÓN 7b — CHECKPOINT REAL Y REANUDACIÓN (CURA-24, acta 258)
#
# POR QUÉ ESTO ES BLOQUEANTE Y NO UNA MEJORA:
#   del manifiesto v8 salen 1.975 B tokens en 141 tandas. A 410 tok/s (40 % MFU
#   en 2×T4) son 1.338 h de reloj. Kaggle da 30 GPU-h/semana y con 2×T4 cada
#   hora de reloj cuesta 2 GPU-h ⇒ 15 h de reloj/semana.
#   16 tandas (0,83 B tokens = 42 % del total) NO caben en una sesión de 12 h.
#   La mayor, 177/sub_2, son 134 h = 11 sesiones.
#   Con el `_checkpoint_tanda` anterior (que solo imprimía "[ckpt] ..."), esas 16
#   tandas eran irrecuperables: se perdía el trabajo cada 12 h. No era lento:
#   era imposible.
#
# DISEÑO:
#   - slot-aislado: solo se guardan los tensores con requires_grad (el slot de la
#     tanda + el router). NO se toca model.safetensors.index.json (decreto 61:
#     la fusión entre máquinas es natural si no se rompe el índice).
#   - atómico: escribir a .tmp + fsync + os.replace. Si Kaggle mata la sesión a
#     mitad, el checkpoint anterior sigue íntegro.
#   - reanudable a MITAD de tanda: run_state.json guarda (tanda, packs_vistos).
#   - poda configurable: por defecto conserva los 3 últimos deltas.
# ---------------------------------------------------------------------------

CKPT_CADA_PASOS = int(os.environ.get("V4X_CKPT_CADA", "20"))   # pasos de optimizador
CKPT_OPT = os.environ.get("V4X_CKPT_OPT", "1") == "1"          # estados AdamW
CKPT_PODA = int(os.environ.get("V4X_CKPT_PODA", "3"))
TOK_S_ESTIMADO = float(os.environ.get("V4X_TOK_S", "410"))  # 40 % MFU 2×T4
# Piloto: N packs por tanda y NO marcar la tanda como completada. Sirve para
# medir MFU real con 3 tandas sin quemar la cuota de la semana.
PILOTO_PACKS = int(os.environ.get("V4X_PILOTO_PACKS", "0"))
def _guardar_tok_s(tanda: str, tok_s: float) -> None:
    """CURA-25: el tok/s medido se persiste. Sin esto cada sesión de Kaggle
    empieza sin saber cuál es el MFU real de la máquina, que es LA constante que
    decide si una tanda cabe en 12 h."""
    ruta = os.path.join(OUT_DIR, "throughput.json")
    datos = {}
    if os.path.exists(ruta):
        try:
            with open(ruta, encoding="utf-8") as f:
                datos = json.load(f)
        except (json.JSONDecodeError, OSError):
            datos = {}
    datos[tanda] = {"tok_s": round(float(tok_s), 1),
                    "t": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}
    vals = [v["tok_s"] for v in datos.values() if v.get("tok_s")]
    datos["_media"] = round(sum(vals) / len(vals), 1) if vals else 0.0
    _escribir_atomico(ruta, lambda t: open(t, "w", encoding="utf-8").write(
        json.dumps(datos, indent=2)))


def _leer_tok_s() -> float:
    """Media de tok/s medida en sesiones previas. 0.0 = NO HAY MEDICIÓN.

    Devolver aquí TOK_S_ESTIMADO (410) era el fallo: el llamador no podía
    distinguir "medido 410" de "no he medido nada" y el papel se disfrazaba de
    dato. El valor de papel lo pone quien llama, no esta función.
    """
    ruta = os.path.join(OUT_DIR, "throughput.json")
    try:
        with open(ruta, encoding="utf-8") as f:
            return float(json.load(f).get("_media", 0.0))
    except (OSError, json.JSONDecodeError, ValueError):
        return 0.0
_RUN_STATE = os.path.join(OUT_DIR, "run_state.json")



# CURA-26 — ORDEN IMPORTA: esto va DESPUÉS de definir _leer_tok_s. Colocado
# antes, el try/except se comía el NameError y la medición real nunca entraba.
try:
    _med = _leer_tok_s()
    if _med and _med > 0:
        TOK_S_ESTIMADO = float(_med)
        print(f"[tok/s] media medida en sesiones previas: {_med:.0f} tok/s "
              f"(MFU ~ {mfu(1, T_TOKENS, T_TOKENS / _med)['mfu_pct']:.1f} %)")
except Exception as _e:
    print(f"[tok/s] sin medición previa usable ({type(_e).__name__}); "
          f"uso {TOK_S_ESTIMADO:.0f} tok/s de papel")

def _escribir_atomico(ruta: str, escribir_fn) -> None:
    """Escribe en .tmp, fsync y os.replace. Un kill a mitad no corrompe nada."""
    tmp = ruta + ".tmp"
    escribir_fn(tmp)
    with open(tmp, "rb") as f:
        os.fsync(f.fileno())
    os.replace(tmp, ruta)


def _guardar_safetensors(tensores: Dict[str, "torch.Tensor"], ruta: str) -> str:
    """Intenta safetensors; si no está, cae a torch.save (mismo contenido)."""
    try:
        from safetensors.torch import save_file
        _escribir_atomico(ruta, lambda t: save_file(
            {k: v.contiguous().clone() for k, v in tensores.items()}, t))
        return ruta
    except ImportError:
        ruta_t = ruta.replace(".safetensors", ".pt")
        _escribir_atomico(ruta_t, lambda t: torch.save(tensores, t))
        return ruta_t


def _estado_runs() -> dict:
    if os.path.exists(_RUN_STATE):
        try:
            with open(_RUN_STATE, encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError):
            print("[ckpt] run_state.json corrupto -> se reconstruye")
    return {"version": 1, "completadas": [], "en_curso": None, "historial": []}


def _guardar_estado_runs(st: dict) -> None:
    os.makedirs(OUT_DIR, exist_ok=True)
    _escribir_atomico(_RUN_STATE,
                      lambda t: open(t, "w", encoding="utf-8").write(
                          json.dumps(st, indent=2, ensure_ascii=False)))


def _tanda_ya_completada(tanda: Tanda) -> bool:
    return tanda.nombre in _estado_runs().get("completadas", [])


def _poda_deltas(conservar: int = CKPT_PODA) -> None:
    """Conserva los `conservar` deltas más recientes. Kaggle /working es finito."""
    try:
        entradas = []
        for d in os.listdir(OUT_DIR):
            ruta = os.path.join(OUT_DIR, d)
            if not os.path.isdir(ruta):
                continue
            f = os.path.join(ruta, "delta.safetensors")
            if not os.path.exists(f):
                f = os.path.join(ruta, "delta.pt")
            if os.path.exists(f):
                entradas.append((os.path.getmtime(f), ruta))
        entradas.sort(reverse=True)
        for _, ruta in entradas[conservar:]:
            import shutil
            shutil.rmtree(ruta, ignore_errors=True)
            print(f"[ckpt] podado (política {conservar}): {os.path.basename(ruta)}")
    except OSError as e:
        print(f"[ckpt] poda omitida: {e}")


def _checkpoint_tanda(model, tanda: Tanda, opt=None, cursor: Optional[int] = None,
                      loss: Optional[float] = None, completar: bool = True) -> None:
    """Guarda el estado de una tanda de forma ATÓMICA y REANUDABLE.

    cursor = packs_vistos en el momento del guardado. Si es None, la tanda se
    marca completada. Si es un entero, queda "en_curso" y la próxima sesión
    retoma desde ahí.
    """
    import time as _t
    t0 = _t.time()
    dir_tanda = os.path.join(OUT_DIR, tanda.nombre.replace("/", "_"))
    os.makedirs(dir_tanda, exist_ok=True)

    # 1) DELTA: solo lo entrenable (slot-aislado, decreto 57)
    tensores = {n: p.detach().to("cpu", torch.float16)
                for n, p in model.named_parameters() if p.requires_grad}
    n_params = sum(t.numel() for t in tensores.values())
    ruta_delta = os.path.join(dir_tanda, "delta.safetensors")
    ruta_delta = _guardar_safetensors(tensores, ruta_delta)

    # 2) OPTIMIZADOR (para reanudar a mitad sin perder momento/varianza)
    if opt is not None and CKPT_OPT and cursor is not None:
        est_opt = {"state": opt.state_dict()["state"],
                   "param_groups": opt.state_dict()["param_groups"]}
        torch.save(est_opt, os.path.join(dir_tanda, "opt.pt.tmp"))
        os.replace(os.path.join(dir_tanda, "opt.pt.tmp"),
                   os.path.join(dir_tanda, "opt.pt"))

    # 3) ESTADO GLOBAL
    st = _estado_runs()
    entrada = {"tanda": tanda.nombre, "slot": tanda.slot,
               "tokens": tanda.tokens_total, "loss": loss,
               "t": _t.strftime("%Y-%m-%dT%H:%M:%SZ", _t.gmtime()), "modo": "delta"}
    if cursor is None and completar:
        if tanda.nombre not in st["completadas"]:
            st["completadas"].append(tanda.nombre)
        st["en_curso"] = None
    else:
        st["en_curso"] = {"tanda": tanda.nombre, "packs_vistos": int(cursor)}
    st["historial"].append(entrada)
    _guardar_estado_runs(st)
    _poda_deltas()

    dt = _t.time() - t0
    est = ("COMPLETA" if completar else "PILOTO (no cierra)") if cursor is None \
        else f"cursor={cursor}"
    print(f"[ckpt] {tanda.nombre}: {n_params/1e6:.1f} M params, {est}, "
          f"{os.path.getsize(ruta_delta)/2**20:.1f} MiB en {dt:.1f} s")


def _presupuesto_tanda(tanda: Tanda, tok_s: float, horas_sesion: float = 12.0) -> float:
    """Avisa si la tanda no cabe en la sesión. Devuelve las horas estimadas."""
    if tok_s <= 0:
        return 0.0
    horas = tanda.tokens_total / tok_s / 3600.0
    if horas > horas_sesion:
        n = horas / horas_sesion
        print(f"!! [presupuesto] {tanda.nombre}: {horas:.1f} h = {n:.1f} sesiones de "
              f"{horas_sesion:.0f} h. REANUDACIÓN OBLIGATORIA (CURA-24).")
    return horas


def _ruta_manifiesto() -> str:
    """CAMBIOS 211+212/213: celda-corre-como-notebook. Jerarquía dura:
    1) env V4X_MANIFIESTO (Session Options)
    2) el modelo mismo (V4X_REPO): si configuration_v4x.py está allí, su
       manifiesto_ESPECIALISTAS_v8.json también viaja pegado
    3) búsqueda amplia en input/working/Drive
    4) crash limpio con mensaje (la casa no adivina rutas)."""
    env = os.environ.get("V4X_MANIFIESTO")
    if env:
        return env
    # intento el dir del modelo (CAMBIOS 212): en Kaggle el modelo lleva el manifiesto
    repo_man = os.path.join(V4X_REPO, "manifiesto_ESPECIALISTAS_v8.json")
    if os.path.exists(repo_man):
        print(f"[manifiesto] del propio modelo: {repo_man}")
        return repo_man
    import glob
    hits = glob.glob("/kaggle/input/**/manifiesto*.json", recursive=True) or \
           glob.glob("/kaggle/working/**/manifiesto*.json", recursive=True) or \
           glob.glob("/content/drive/MyDrive/**/manifiesto*.json", recursive=True)
    if hits:
        print(f"[manifiesto] autodetectado: {hits[0]}")
        return hits[0]
    raise FileNotFoundError(
        "manifiesto ESPECIALISTAS no encontrado. Modelo mountado en V4X_REPO? "
        "o sube manifiesto_ESPECIALISTAS_v8.json suelto. Ver CAMBIOS 212.")


# CAMBIOS 212: celda SOLO define funciones. Mensaje de cómo arrancar tras pegarla:
try:
    print("—— celda v3 cargada ✓ (sin arrancar; eso es trabajo de la celda PROTO_ARGON_v1)")
except NameError:
    pass
# Nunca entrenar() en el import: el usuario lanza PROTO_ARGON_v1 después.
