# ─────────────────────────────────────────────────────────────────────────────
# acel_BF16_TURING.py — "ACELERADOR CASA" para T4/P100 (sm_75/sm_60 SIN bf16-HW)
# CAMBIOS 193 · Decisión usuario: "crea tus propios aceleradores BF16".
# REGLAS DE LA CASA: (1) NO se toca modeling_v4x.py (todo vive aquí, inyección celda).
# (2) bf16/quant veto SOLO aplica a pesos ENTRENABLES (CAMBIOS 135): aquí no
#     cuantiza nada — fp16 sombra tiene MÁS mantisa que bf16 (10 vs 8 bits).
# (3) Pesos entrenables quedan intocados fp32-master + GradScaler.
#
# 3 modos, de simple a quirúrgico:
#   A) SOMBRA-FP16 en el loader (frozen weights cast a fp16 con ASSERT de rango)
#      — CAMBIOS 135 ya lo preveía (staging bf16→fp16). Coste VRAM: 0 extra.
#   B) KERNEL TRITON fusionado bf16→fp16→HMMA (conversión en registro, 0 copia)
#      — para los casos que queden fuera de la sombra (activos bf16, embeds).
#   C) SPLIT-EXACTO (2 GEMMs fp16 = bf16EXACTO) solo si el scan CPU marca
#      tensores con |w|>65504 o |w|<6,1e-5 (fuera de rango fp16-finito).
# ─────────────────────────────────────────────────────────────────────────────
import os
import torch
import torch.nn as nn
import torch.nn.functional as F

FP16_MAX, FP16_MIN_NORM = 65504.0, 6.103515625e-05

# ═══ A.0) ESCANEO CPU DE RANGO (cuota-0 local: solo lectura/análisis) ═══
def escanear_rango_bf16(state_dict: dict, ruta_log: str = "scan_rango_bf16.json") -> dict:
    """Recorre el ckpt en CPU y audita qué tensores bf16 caben en fp16-finito.
    Devuelve {'ok':[...], 'peligro':[...]} y lo escribe en JSON. ~3-5 min/Ryzen."""
    ok, peligro = [], []
    for nombre, t in state_dict.items():
        if t.dtype != torch.bfloat16:
            continue
        mx = t.float().abs().max().item() if t.numel() else 0.0
        nz = t[t != 0].float().abs()
        mn = nz.min().item() if nz.numel() else float("inf")
        if mx > FP16_MAX or (mn < FP16_MIN_NORM and nz.numel()):
            peligro.append({"tensor": nombre, "max": mx, "min_nz": mn,
                            "accion": "modo C (split-exacto) o queda bf16 emulado"})
        else:
            ok.append(nombre)
    import json
    json.dump({"ok": ok, "peligro": peligro}, open(ruta_log, "w"), indent=1)
    print(f"[scan bf16] ok={len(ok)} tensores · peligro={len(peligro)} → {ruta_log}")
    if peligro:
        print("  ⚠ tensores fuera de rango fp16:", [p["tensor"] for p in peligro][:8])
    return {"ok": ok, "peligro": peligro}

# ═══ A/B.1) MOTOR DE RESIDENCIA: frozen bf16→fp16 con assert de rango ═══
@torch.no_grad()
def instalar_sombra_fp16(model: nn.Module, set_peligro: set | None = None) -> dict:
    """Paso 1 del PROTO-B1Ω: cast IN-PLACE de frozen bf16→fp16 con assert de rango
    (camino legal: CAMBIOS 135 prevía staging bf16→fp16 con assert). Los pesos
    entrenables NO se tocan aquí; la celda los repone a fp32-master por tanda.
    set_peligro: nombres desde el scan CPU que FUERZAN dejar bf16 (fuera de rango).
    Devuelve estadísticas para el JSON del gate."""
    peligro = set_peligro or set()
    stats = {"convertidos": 0, "fuera_de_rango": 0, "entrenables_intactos": 0}
    for nombre, p in model.named_parameters():
        if p.dtype != torch.bfloat16:
            continue
        if p.requires_grad:
            stats["entrenables_intactos"] += 1
            continue
        if nombre in peligro or p.float().abs().max().item() > FP16_MAX:
            stats["fuera_de_rango"] += 1
            continue  # queda bf16 (GEMM emulado pero CORRECTO) → modo C si acaso
        p.data = p.data.to(torch.float16)
        p.casa_dtype_sombra = True   # marca forense para el SYNC y para el restore
        stats["convertidos"] += 1
    bf16_restantes = sum(1 for p in model.parameters()
                         if p.dtype == torch.bfloat16 and not p.requires_grad)
    stats["mantenidos_bf16"] = bf16_restantes
    print(f"[acel-Ω/A] frozen→fp16: {stats['convertidos']} tensores convertidos · "
          f"{stats['fuera_de_rango']} fuera de rango · residuo bf16={bf16_restantes}")
    return stats

# ═══ B) KERNEL TRITON bf16→fp16→HMMA (para residuos bf16 sin copia) ═══
_TRITON_OK = False
try:
    import triton
    import triton.language as tl
    _TRITON_OK = True

    @triton.jit
    def _casa_gemm_bf16hmma(A, B, C, M, N, K,
                            sam, sak, sbk, sbn, scm, scn,
                            BM: tl.constexpr, BN: tl.constexpr, BK: tl.constexpr):
        """GEMM [M,K] fp16/bf16 × [K,N] bf16-almacenado → out fp32 acumulada.
        La conversión bf16→fp16 ocurre EN REGISTRO: cero copias, HMMA nativo."""
        pm, pn = tl.program_id(0), tl.program_id(1)
        rm = pm * BM + tl.arange(0, BM)
        rn = pn * BN + tl.arange(0, BN)
        acc = tl.zeros((BM, BN), dtype=tl.float32)
        for k0 in range(0, K, BK):
            rk = k0 + tl.arange(0, BK)
            a = tl.load(A + rm[:, None] * sam + rk[None, :] * sak)
            b = tl.load(B + rk[:, None] * sbk + rn[None, :] * sbn)
            acc += tl.dot(a.to(tl.float16), b.to(tl.float16))   # ← el "acelerador"
        tl.store(C + rm[:, None] * scm + rn[None, :] * scn, acc.to(tl.float16))

    def gemm_acelerador(a: torch.Tensor, b_bf16: torch.Tensor) -> torch.Tensor:
        """Auto-fallback: si Triton no está o shape rara → convertir+cuBLAS fp16."""
        M, K, N = a.shape[0], a.shape[1], b_bf16.shape[0]
        if not (_TRITON_OK and a.is_cuda and M % 16 == 0 and K % 16 == 0 and N % 16 == 0):
            return F.linear(a, b_bf16.to(torch.float16))
        c = torch.empty(M, N, device=a.device, dtype=torch.float16)
        grid = (triton.cdiv(M, 64), triton.cdiv(N, 64))
        _casa_gemm_bf16hmma[grid](a, b_bf16, c, M, N, K,
                                  a.stride(0), a.stride(1),
                                  b_bf16.stride(0), b_bf16.stride(1),
                                  c.stride(0), c.stride(1),
                                  BM=64, BN=64, BK=32)
        return c
except ImportError:  # sin Triton en el entorno (p.ej. sandbox CPU)
    def gemm_acelerador(a, b_bf16):
        return F.linear(a, b_bf16.to(torch.float16))

# ═══ C) SPLIT-EXACTO (solo si el scan marca 'peligro') ═══
def gemm_split_exacto(a_fp16: torch.Tensor, w_bf16: torch.Tensor) -> torch.Tensor:
    """w = hi + lo/2^11 (ambas fp16). w@a = hi@a + (lo@a)/2^11 → bf16-exacto
    con HMMA en T4. 2 GEMMs ≈ 65/2 = 32 TF efectivos ≫ 8 TF emulados."""
    hi = w_bf16.to(torch.float16)
    lo = ((w_bf16.float() - hi.float()) * (1 << 11)).to(torch.float16)
    return F.linear(a_fp16, hi) + F.linear(a_fp16, lo) / (1 << 11)

# ═══ GATE PROTO-B1Ω: A/B formal vs bf16 emulado ═══
@torch.no_grad()
def proto_b1omega_gemm(M=4096, K=2688, N=2688, iters=20, device="cuda"):
    """Mide tok-equivalente GEMM/s: bf16-emulado vs acelerador vs sombra fp16.
    Gate de la casa: cos(y_sombra, y_bf16) ≥ 0.9999 Y speedup ≥ 1.5."""
    a   = torch.randn(M, K, device=device, dtype=torch.bfloat16)
    w   = torch.randn(K, N, device=device, dtype=torch.bfloat16)
    w16 = w.to(torch.float16)

    def crono(fn, *args):
        for _ in range(3): fn(*args)
        torch.cuda.synchronize()
        t0 = torch.cuda.Event(True); t1 = torch.cuda.Event(True)
        t0.record()
        for _ in range(iters): fn(*args)
        t1.record(); torch.cuda.synchronize()
        return t0.elapsed_time(t1) / iters

    ms_bf16   = crono(lambda x, y: F.linear(x, y), a, w)
    ms_sombra = crono(lambda x, y: F.linear(x.to(torch.float16), y),
                      a, w16)
    ms_kernel = crono(gemm_acelerador, a, w)

    y_ref = F.linear(a.float(), w.float())
    y_som = F.linear(a.to(torch.float16), w16).float()
    cos = F.cosine_similarity(y_ref.flatten(), y_som.flatten(), dim=0).item()
    rel = (y_ref - y_som).norm() / y_ref.norm().clamp_min(1e-9)

    print(f"[PROTO-B1Ω] bf16 emulado : {ms_bf16:7.3f} ms")
    print(f"[PROTO-B1Ω] sombra fp16  : {ms_sombra:7.3f} ms  (×{ms_bf16/ms_sombra:5.2f})")
    print(f"[PROTO-B1Ω] kernel Triton: {ms_kernel:7.3f} ms  (×{ms_bf16/ms_kernel:5.2f})")
    print(f"[PROTO-B1Ω] cos(y)={cos:.8f} · rel_l2={rel:.2e} · gate cos≥0,9999: "
          f"{'PASS' if cos >= 0.9999 else 'FAIL'}")
    return {"ms_bf16": ms_bf16, "ms_sombra": ms_sombra, "ms_kernel": ms_kernel,
            "speedup_sombra": ms_bf16 / ms_sombra, "speedup_kernel": ms_bf16 / ms_kernel,
            "cos": cos, "rel_l2": rel.item(), "gate": cos >= 0.9999}

# ═══ Plan de inyección en la celda (SIN tocar modeling) ═══
INYECCION_CELDA = '''
# En celda_KAGGLE_v2_entreno.py, justo tras cargar_modelo() y ANTES de la tanda 1:
#   from acel_BF16_TURING import instalar_sombra_fp16, resolver_entrenables
#   if os.environ.get("V4X_ACEL_BF16", "1") == "1":
#       SOMBRA = instalar_sombra_fp16(model)   # frozen bf16 → fp16 HMMA
# y en el optimizer tanda-a-tanda, tras fijar_router_y_requires_grad(...):
#       # los params entrenables VUELVEN a fp32-master antes de entrenar el slot
#       for n, p in model.named_parameters():
#           if p.requires_grad and getattr(p, "casa_dtype_sombra", False):
#               p.data = p.data.float()      # master fp32 del slot (regla 135)
'''
if __name__ == "__main__":
    print(__doc__[:400], "\n…usa las funciones según la guía de aceleradores casa.")
