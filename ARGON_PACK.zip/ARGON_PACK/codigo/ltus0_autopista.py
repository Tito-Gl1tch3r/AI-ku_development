#!/usr/bin/env python3
# ═════════════════════════════════════════════════════════════════════════════
# ltus0_autopista.py — LTUS-0 MODO AUTOPISTA · construcción de la casa (acta 244 → 245)
#
# CHECKLIST ANTI-OLVIDO (cada exigencia de acta → dónde vive en este archivo):
#   Gate 1 overlap>=70% .................... ejecutar_partitura_autopista() → overlap_pct
#   Gate 2 VRAM<=14.500 MiB ................ mismo → vram_peak_mib (cuenta TODO, arena o no)
#   Gate 3 reproducibilidad ................ sellar_partitura_sha256 (DF-04) + CUBLAS fijo (DF-03)
#   Gate 4 Anti-Casper ..................... CANONICAL_MD5_244 literal (Decreto 244, NO recitar)
#   Gate 5 GPU_busy>=90% ................... gpu_busy_pct (L-HOST-FREE operacional, enmienda O-1:
#                                           vale el gate medido, no la metáfora de la cola)
#   AF-01 pre-encolado / GF-01 tape ........ construir_tape_step() + bucle de 10 líneas
#   AF-02 static view binding .............. LTUSAutopistaArena.__init__ (p.data atado 1 vez)
#   AF-04 cero .item/.cpu/.tolist in-step .. prohibidos en closures del tape (auditable)
#   AF-06 higiene driver ................... os.environ al importar (AF-06)
#   BF-01 ping-pong laminado ............... BUF_A/B (par/impar) + waits del tape
#   BF-02 cura E-5 phi (evac. rebanadas) ... _offload_grad_sliced() (SIN .float() en GPU, cura E-8)
#   BF-03 tronco residente ................. split residente(“.V4X.experts.” no contiene)/stream
#   BF-04 anillo fronteras pinned .......... pin_borders + ACTS PING-PONG (curas E-3 y E-11)
#   BF-05 sub-laminación ................... parámetro grad_accum_split del plan
#   DF-01 determinismo estructural s* ...... comentado en offload; fallback |Δloss|<=ε en gates
#   DF-02 RNG solo en ALLOC (dropout=0) .... init_router_seed param del plan (Bug-2)
#   EF-02 commit post-step oculto .......... ltus_commit_step() tras soltar FWD 0..fgl-1 (caller)
#   EF-03 métricas 0-D + lectura 8 B ....... vram_metrics/pin_metrics
#   EF-04 CE one-pass chunked real ......... _CEChunkFn (SIN placeholder, cura E-9)
#   E-12 BWD sin re-H2D de L-2/L-1 ......... construir_tape_step() omite su prefetch
#   P-1/E-11 acts ping-pong ................ acts_ab[2] — el D2H de frontera solapa con cómputo
#   Anexo 244-B.1 trainable_set/LoRA ....... apply_lora() + locality auto (gpu fp32 | cpu fp32)
#   Anexo 244-B.1 Fase-2 bwd_profile ....... parámetro bwd_profile={"psi11_wgrad_only","full_dgrad_no_wgrad"}
#   O-2 despacho congelado (pendiente Argon) hook opcional V4X_LTUS_ZEROSYNC, POR DEFECTO OFF:
#                                           exige ROUTE_CENSUS (EXP-H4) + cura E-05 antes de ON
#   E-05 (prerequisito ascendido) .......... documentado; AF-05 queda vetado hasta su cura
#   ROUTE_CENSUS (EXP-H4) .................. route_census() — JSON formato A-2 del apéndice 244-A
#
# ESTADO: SMOKE-capable. La firma de entrenamiento real exige: GATE-0 verde +
# ROUTE_CENSUS + EXP-H1..H3 medidos en Kaggle. La casa no firma papel; firma medición.
# ═════════════════════════════════════════════════════════════════════════════
import os as _os
# AF-06 / DF-03: higiene de driver antes de cualquier import de torch
_os.environ.setdefault("CUDA_LAUNCH_BLOCKING", "0")
_os.environ.setdefault("CUDA_MODULE_LOADING", "LAZY")
_os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
_os.environ.setdefault("PYTORCH_CUDA_ALLOC_CONF", "expandable_segments:True,max_split_size_mb:128")

import json, time, math, hashlib, threading, queue, re
from typing import Callable, Dict, Iterable, List, Optional, Sequence, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F

# ═══ §0 · DECRETO 244: TABLA CANÓNICA LITERAL (prohibido recitar de memoria) ═══
CANONICAL_MD5_244: Dict[str, str] = {
    "modeling_v4x.py":            "4192b002a5c7397abbb2a15ad8df0b28",
    "configuration_v4x.py":       "1c81ac67e0667a3f92386d71b92f7b76",
    "celda_KAGGLE_v3_entreno.py": "621611c1ecbaff122a43716eb2d2ca2b",
    "acel_BF16_TURING.py":        "62afdd4594c893a09a4f3bbfcdf0f26a",
    "celda_GATE0_IFA_BIZONAL.py": "fa3731efa01409cc681e28b890acfedb",  # CURA-13 (CAMBIOS 251): escolta permanente post-frontera + ce_chunk definido
}

def _md5_file(path: str) -> str:
    h = hashlib.md5()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()

def verificar_anti_casper_244(paths_map: Dict[str, str]) -> Dict[str, str]:
    """Gate 4. Aborta ANTES de reservar 1 byte si un fichero difiere 1 bit (acta 241)."""
    ok = {}
    for nombre, esperado in CANONICAL_MD5_244.items():
        ruta = paths_map.get(nombre)
        if not ruta or not _os.path.isfile(ruta):
            raise RuntimeError(f"[GATE-4 ANTI-CASPER] falta {nombre} en {paths_map}")
        real = _md5_file(ruta)
        if real != esperado:
            raise RuntimeError(
                f"[GATE-4 ANTI-CASPER 👻] {nombre}: md5={real} != canónico {esperado} — ABORTO"
            )
        ok[nombre] = real
    print(f"[LTUS · Gate-4 ✓] 5/5 canónicos: {list(ok)}", flush=True)
    return ok


# ═══ §1 · PARTITURA: COMPILADOR ESTÁTICO + SELLO SHA-256 (DF-04, A-1) ═══
LTUS_ISA_VERSION = "1.4-CASA-256"   # [LTUS] + perfiles + LAUS + §11 controlador + §12 CPU + §13 PEPS-D

# ═══ §1b · [LTUS, CAMBIOS 252] PERFILES DE DESTINO: el mismo software, tres máquinas ═══
# El usuario decretó que el motor pasa a llamarse LTUS (la S es por Software): una sola
# pieza de software que sirve al laboratorio de entrenamiento Y a la LEUS (banco local de
# calibración, ~0,7 tok/s GTX 1650). Un motor, tres perfiles; ningún perfil se escribe a
# mano en la partitura (A-3): se declara aquí y el compilador lo sella.
LTUS_TARGETS: Dict[str, Dict] = {
    # perfil              cap_mib/tarjeta  n_gpus  T_max  capa_bytes_techo  notas
    "LTUS-0":   {"cap_mib": 14500.0, "n_gpus": 1, "T_max": 8192,  "base_mib": 8842.0,
                 "hw": "1x T4 sm_75 (16 GiB)", "modo": "streaming_autopista"},
    "LTUS-1":   {"cap_mib": 14500.0, "n_gpus": 2, "T_max": 8192,  "base_mib": 8842.0,
                 "hw": "2x T4 bizonal (split 26/26)", "modo": "bizonal_escolta"},
    "LEUS":     {"cap_mib": 3800.0,  "n_gpus": 1, "T_max": 1024,  "base_mib": 0.0,
                 "hw": "1x GTX 1650 Mobile 4 GiB + Ryzen 5 5600H",
                 "modo": "papel_lento",
                 # [CURA-17, CAMBIOS 257] MEDIDO en la máquina del usuario (captura 01-nov):
                 "ram_mib": 15319.0,        # 14,96 GiB
                 "swap_mib": 0.0,           # "Swap: Disabled" — hasta que active zram/swapfile
                 "reserva_so_mib": 3584.0,  # SO + Hyprland + navegador (~3,5 GiB)
                 "hilos_cpu": 12,           # Ryzen 5 5600H: 6C/12T
                 "vram_escritorio_mib": 256.0,   # Hyprland/wlroots: muy por debajo de Windows
                 "max_capas_subtanda_phi": 4,    # 6 ya no cabe (11,3 GiB > 10,5 libres)
                 "nota": "sin swap el proceso MUERE por OOM de host; con zram cuenta como swap_mib"},
}
LTUS_TARGET_DEFECTO = "LTUS-1"

# ═══ §1c · [LAUS, CAMBIOS 253] EL PARAGUAS: LAUS = LTUS ∪ LEUS ═══
# Decreto del usuario (acta 253): **LAUS = Language Accelerator Unit Software**, y no es una
# cuarta unidad: es la FAMILIA ENTERA — nuestra LTUS (entrenamiento: autopista 1×T4 y bizonal
# 2×T4) MÁS nuestra LEUS (banco local de calibración/inferencia). Una sigla para hablar de
# "todo el software de aceleración", dos componentes para hablar de máquinas concretas.
#
# Consecuencia de diseño (A-3: nada de destinos inventados): LAUS **no compila**. Un plan se
# sella SIEMPRE contra un destino concreto (LTUS-0, LTUS-1 o LEUS). Si alguien pide
# target="LAUS" el compilador debe ABORTAR explicando cuáles son los concretos — un paraguas
# que se deja usar como destino es la vía más corta a un plan firmado con el perfil equivocado.
LAUS = {
    "sigla": "LAUS",
    "significado": "Language Accelerator Unit Software",
    "componentes": {
        "LTUS": {"rol": "acelerador de ENTRENAMIENTO",
                 "targets": ["LTUS-0", "LTUS-1"]},
        "LEUS": {"rol": "banco local de CALIBRACIÓN / inferencia (papel lento)",
                 "targets": ["LEUS"]},
    },
}
LAUS_TARGETS_CONCRETOS = ["LTUS-0", "LTUS-1", "LEUS"]
assert set(LAUS_TARGETS_CONCRETOS) == set(LTUS_TARGETS), "LAUS y LTUS_TARGETS divergen"


def laus_resumen() -> Dict:
    """Vista única de la familia: qué componente cubre qué máquina y con qué techo.
    Es lo que se pega en un informe; no sustituye a la partitura de un destino concreto."""
    rep = {"sigla": LAUS["sigla"], "significado": LAUS["significado"], "componentes": {}}
    for comp, info in LAUS["componentes"].items():
        filas = []
        for t in info["targets"]:
            p = LTUS_TARGETS[t]
            filas.append({"target": t, "hw": p["hw"], "modo": p["modo"],
                          "cap_total_mib": p["cap_mib"] * p["n_gpus"], "T_max": p["T_max"]})
        rep["componentes"][comp] = {"rol": info["rol"], "destinos": filas}
    return rep


def validar_plan_en_toda_la_familia(plan: Dict) -> Dict:
    """Un plan nace para un destino, pero el usuario quiere que el SOFTWARE sirva a las dos
    máquinas. Este chequeo dice, sin ambigüedad, en cuáles de los destinos concretos el plan
    es legal y en cuáles no — para no descubrir en la LEUS lo que ya sabíamos en la T4."""
    salida = {t: validar_plan_contra_target(plan, t)["legal"] for t in LAUS_TARGETS_CONCRETOS}
    rep = {"familia": "LAUS", "legal_en": [t for t, v in salida.items() if v],
           "ilegal_en": [t for t, v in salida.items() if not v],
           "detalle": salida}
    print(json.dumps(rep, ensure_ascii=False), flush=True)
    return rep




def perfil_de_destino(target: str) -> Dict:
    """Devuelve el perfil o aborta. Fail-fast: un perfil inventado es un Casper."""
    if target == "LAUS":
        raise KeyError(
            "[LAUS] LAUS es la FAMILIA (LTUS ∪ LEUS), no un destino: no se compila contra el "
            f"paraguas. Destinos concretos: {LAUS_TARGETS_CONCRETOS}")
    if target not in LTUS_TARGETS:
        raise KeyError(f"[LTUS] target desconocido {target!r}; legales: {sorted(LTUS_TARGETS)}")
    p = dict(LTUS_TARGETS[target])
    p["nombre"] = target
    p["cap_total_mib"] = p["cap_mib"] * p["n_gpus"]
    return p


def validar_plan_contra_target(plan: Dict, target: str = LTUS_TARGET_DEFECTO) -> Dict:
    """Sanity estático ANTES de reservar 1 byte (principio A-2: medir, no presumir).
    Comprueba (1) techo de secuencia, (2) que ninguna capa exceda la tarjeta,
    (3) que el residuo residente (base_mib) quepa. NO sustituye a los gates medidos."""
    perfil = perfil_de_destino(target)
    avisos = []
    T = plan["tanda"].get("T", 0)
    if T > perfil["T_max"]:
        avisos.append(f"T={T} > T_max={perfil['T_max']} del perfil {target} (micro-lote ilegal)")
    peor = max(plan.get("layer_bytes_streamed", [0]) or [0]) / 2**20
    if peor > perfil["cap_mib"]:
        avisos.append(f"capa mayor {peor:.0f} MiB > capacidad {perfil['cap_mib']:.0f} MiB")
    if perfil["base_mib"] and perfil["base_mib"] > perfil["cap_mib"]:
        avisos.append(f"base residente {perfil['base_mib']:.0f} MiB no cabe en {target}")
    rep = {"target": target, "hw": perfil["hw"], "modo": perfil["modo"],
           "legal": not avisos, "avisos": avisos, "cap_total_mib": perfil["cap_total_mib"]}
    if avisos:
        print(json.dumps(rep, ensure_ascii=False), flush=True)
    return rep


def sellar_partitura_sha256(plan: Dict) -> str:
    copia = {k: v for k, v in plan.items() if k != "plan_sha256"}
    raw = json.dumps(copia, sort_keys=True, separators=(",", ":")).encode("utf-8")
    plan["plan_sha256"] = hashlib.sha256(raw).hexdigest()
    return plan["plan_sha256"]

def compilar_plan_ltus0(tanda: Dict, n_layers: int, layer_bytes_streamed: List[int],
                       md5_manifest: Dict[str, str], out_json: str,
                       target: str = LTUS_TARGET_DEFECTO) -> Dict:
    """Emite la partitura auditable. bwd_profile por fase (Anexo 244-B.1 A-4):
       'psi11_wgrad_only' (Fase 1: expertos congelados NO viajan en BWD) o
       'full_dgrad_no_wgrad' (Fase 2 OMMB/encoders: congelados sí viajan en BWD).
       [LTUS 252] `target` es obligatorio-por-defecto: la partitura se sella con el
       perfil con el que fue validada (LTUS-0 | LTUS-1 | LEUS). Sin perfil no hay sello."""
    fgl = tanda["first_grad_layer"]
    profile = tanda.get("bwd_profile", "psi11_wgrad_only")
    sched = [{"seq": 0, "op": "VERIFY_MOUNT", "md5": md5_manifest},
             {"seq": 1, "op": "ALLOC_ARENA", "isa": LTUS_ISA_VERSION}]
    seq = 2
    for l in range(min(2, n_layers)):
        sched.append({"seq": seq, "op": "H2D_PREFETCH", "layer": l, "stream": "H2D",
                      "bytes": layer_bytes_streamed[l]}); seq += 1
    for l in range(n_layers):
        sched.append({"seq": seq, "op": "FWD_LAYER", "layer": l, "stream": "COMP",
                      "mode": "nograd_opt1" if l < fgl else "ckpt_border"}); seq += 1
        if l + 2 < n_layers:
            sched.append({"seq": seq, "op": "H2D_PREFETCH", "layer": l + 2,
                          "stream": "H2D", "bytes": layer_bytes_streamed[l + 2]}); seq += 1
    sched.append({"seq": seq, "op": "CE_LOSS_BWD", "stream": "COMP", "chunk": 1024}); seq += 1
    bwd_layers = list(range(n_layers - 1, fgl - 1, -1))
    for i, l in enumerate(bwd_layers):
        if i >= 2 or profile == "full_dgrad_no_wgrad":
            # E-12: en Fase 1 las 2 primeras capas BWD siguen residentes; en Fase 2 se re-stream todo
            sched.append({"seq": seq, "op": "H2D_PREFETCH_BWD", "layer": l, "stream": "H2D"}); seq += 1
        sched.append({"seq": seq, "op": "BWD_LAYER", "layer": l, "stream": "COMP",
                      "bwd_profile": profile}); seq += 1
        sched.append({"seq": seq, "op": "D2H_GRAD_SLICED", "layer": l, "stream": "D2H"}); seq += 1
    sched.append({"seq": seq, "op": "READ_METRICS_8B", "stream": "D2H"}); seq += 1
    _perfil = perfil_de_destino(target)
    _cpu = {"nucleos_disponibles": nucleos_disponibles(),
            "reparto": reparto_cpu(int(_os.environ.get("V4X_LTUS_CPU_CORES", "0") or 0)
                                   or nucleos_disponibles()),
            "origen": "explícito" if _os.environ.get("V4X_LTUS_CPU_CORES") else "adaptativo"}
    plan = {"cpu_config": _cpu, "ltus_isa_version": LTUS_ISA_VERSION, "target_hardware": f"{target} ({_perfil['hw']})",
            "target_profile": _perfil, "bwd_profile": profile,
            "tanda": tanda, "anti_casper_manifest": md5_manifest,
            "layer_bytes_streamed": list(layer_bytes_streamed),
            "n_layers": n_layers, "total_micro_ops": len(sched), "schedule": sched}
    _val = validar_plan_contra_target(plan, target)
    plan["target_check"] = _val
    sellar_partitura_sha256(plan)
    with open(out_json, "w", encoding="utf-8") as f:
        json.dump(plan, f, indent=1, ensure_ascii=False)
    print(f"[LTUS · plan ✓] {out_json} · sha256={plan['plan_sha256'][:16]}… · ops={len(sched)}", flush=True)
    return plan


# ═══ §2 · LoRA GENÉRICO (Anexo 244-B.1): adapters residentes, nunca en slab ═══
class LoRALinear(nn.Module):
    """y = base(x) + (alpha/r) * B(A(x)); base congelada. Master fp32 lo decide el optimizer.
    use_dora=True añade magnitud-dirección REAL (cura N-2: dora_m se usa y recibe gradiente)."""

    def __init__(self, base: nn.Linear, r: int, alpha: float, use_dora: bool = False):
        super().__init__()
        # [CURA-19, CAMBIOS 258] el assert anterior (`not base.bias or base.bias is nn.Parameter`)
        # estaba roto por dos motivos: (a) `not base.bias` sobre un tensor multi-elemento lanza
        # RuntimeError de ambigüedad; (b) `is nn.Parameter` compara una INSTANCIA con una CLASE
        # (siempre False). La intención real era "bias permitido, pero congelado": se hace, no se
        # declara. Cazado por Argon (acta 258, fila 6).
        if getattr(base, "bias", None) is not None:
            assert isinstance(base.bias, nn.Parameter), "bias no es un Parameter"
            base.bias.requires_grad_(False)
        self.base = base
        for p in self.base.parameters():
            p.requires_grad_(False)
        dev = base.weight.device
        self.r, self.use_dora = r, use_dora
        self.sc = alpha / r
        self.lora_A = nn.Parameter(torch.randn(r, base.in_features, device=dev, dtype=torch.float32) * (r ** -0.5))
        self.lora_B = nn.Parameter(torch.zeros(base.out_features, r, device=dev, dtype=torch.float32))
        if use_dora:
            with torch.no_grad():
                self.dora_m = nn.Parameter(base.weight.data.float().norm(p=2, dim=1))

    def forward(self, x):
        delta = (self.lora_B @ self.lora_A) * self.sc                        # [out,in] fp32
        if not self.use_dora:
            return self.base(x) + (x @ self.lora_A.t().to(x.dtype) @ self.lora_B.t().to(x.dtype)) * self.sc
        w_eff = (self.base.weight.data.float() + delta)                      # dirección+magnitud
        w_eff = F.normalize(w_eff, p=2, dim=1) * self.dora_m.unsqueeze(1)    # DoRA real
        return F.linear(x, w_eff.to(x.dtype))

def apply_lora(model: nn.Module, suffixes: Sequence[str], r: int = 16, alpha: float = 32.0,
               dora: bool = False) -> List[nn.Parameter]:
    """Envuelve nn.Linear cuyo nombre acaba en algún suffix. Devuelve params LoRA (trainable_set)."""
    lora_params = []
    for mod_name, module in list(model.named_modules()):
        for child_name, child in list(module.named_children()):
            full = f"{mod_name}.{child_name}"
            if isinstance(child, nn.Linear) and any(full.endswith(s) for s in suffixes):
                wrap = LoRALinear(child, r, alpha, use_dora=dora)
                setattr(module, child_name, wrap)
                lora_params += [wrap.lora_A, wrap.lora_B] + ([wrap.dora_m] if dora else [])
    print(f"[LTUS · LoRA] r={r} a={alpha} dora={dora} · caps={len(lora_params)}", flush=True)
    return lora_params


# ═══ §3 · CE ONE-PASS CHUNKED REAL (EF-04 · cura E-9): sin logits retenidos ═══
class _CEChunkFn(torch.autograd.Function):
    """CE token-level en chunks sobre lm_head FIJADA (tanda .shared re-derivaría grad_W).
    GEMM en fp16 (HMMA), reducciones en fp32. Flag V4X_LTUS_CE_FP32GEMM=1 para fp32 puro."""

    @staticmethod
    def forward(ctx, h, labels, w_vocab, chunk: int, ignore_index: int = -100):
        """[CURA-18, CAMBIOS 258] SHIFT CAUSAL OBLIGATORIO.
        Sin `h[:-1]` vs `labels[1:]` el modelo aprende la FUNCIÓN IDENTIDAD (h_t -> token_t,
        que ya está en h_t) y la loss cae a ~0 en dos pasos sin aprender nada. Es la
        "CAZA ARGON #2 (CAMBIOS 81)" que ya se corrigió en `ce_chunk` de la celda v3 y que
        la versión anterior de este fichero había reintroducido. El gradiente se rellena con
        un cero en la última posición para devolver la forma original [T, H]."""
        fp32_gemm = _os.environ.get("V4X_LTUS_CE_FP32GEMM", "0") == "1"
        h = h[:-1]                      # predicción en t  ->  token en t+1
        labels = labels[1:]
        T, H = h.shape
        V = w_vocab.shape[0]
        loss_sum = h.new_zeros((), dtype=torch.float32, device=h.device)
        n_sup = h.new_zeros((), dtype=torch.float32, device=h.device)
        for t0 in range(0, T, chunk):
            hc = h[t0:t0 + chunk]
            lc = labels[t0:t0 + chunk]
            if fp32_gemm:
                logits = (hc.float() @ w_vocab.float().t())
                lse = torch.logsumexp(logits, dim=-1)
                rows = labels_mask = lc != ignore_index
                target = logits.gather(1, lc.clamp(min=0).unsqueeze(1)).squeeze(1)
                loss_sum += (lse - target)[rows].sum()
            else:
                logits16 = hc @ w_vocab.t()                          # HMMA fp16
                lse = torch.logsumexp(logits16.float(), dim=-1)      # reducción fp32
                rows = lc != ignore_index
                tgt = logits16.gather(1, lc.clamp(min=0).unsqueeze(1)).squeeze(1).float()
                loss_sum += (lse - tgt)[rows].sum()
            n_sup += rows.sum().float()
        ctx.save_for_backward(h, labels, w_vocab)
        ctx.chunk, ctx.ignore_index = chunk, ignore_index
        ctx.fp32_gemm = fp32_gemm
        # guardar recuento para el backward (normalización idéntica fwd/bwd)
        ctx.registered_n = int(n_sup.item()) if False else n_sup     # 0-D GPU, sin sync
        return loss_sum / n_sup.clamp(min=1.0), n_sup

    @staticmethod
    def backward(ctx, g_loss, _g_nsup):
        h, labels, w_vocab = ctx.saved_tensors      # ya vienen desplazados del forward
        T, H = h.shape
        chunk = ctx.chunk
        n_sup = ctx.registered_n
        grad_h = torch.zeros_like(h)
        norm = (g_loss / n_sup.clamp(min=1.0))
        for t0 in range(0, T, chunk):
            hc = h[t0:t0 + chunk]
            logits16 = hc @ w_vocab.t()
            p = torch.softmax(logits16.float(), dim=-1)
            lc = labels[t0:t0 + chunk]
            rows = lc != ctx.ignore_index
            if rows.any():
                idx = lc[rows]
                p[rows] -= F.one_hot(idx, p.shape[-1]).float()
                g_rows = (p[rows].to(h.dtype) @ w_vocab)             # HMMA fp16
                grad_h[t0:t0 + chunk][rows] = g_rows
        grad_h *= norm.to(h.dtype)
        # [CURA-18] deshacer el shift: la posición T-1 no predice nada -> gradiente 0
        grad_h = F.pad(grad_h, (0, 0, 0, 1))
        return grad_h, None, None, None, None

def ce_loss_chunked(grad_src_h: torch.Tensor, labels: torch.Tensor, w_vocab: torch.Tensor,
                    chunk: int = 1024) -> Tuple[torch.Tensor, torch.Tensor]:
    """Entrada: h de la capa superior [T,H] y labels [T] EN EL MISMO ÍNDICE (el shift causal
    h[:-1] vs labels[1:] se aplica DENTRO, CURA-18). El caller NO debe desplazar nada."""
    return _CEChunkFn.apply(grad_src_h, labels, w_vocab, chunk, -100)


# ═══ §4 · ARENA AUTOPISTA: vistas estáticas, tronco residente, acts ping-pong ═══
_EXPERT_MARK = ".V4X.experts."

class LTUSAutopistaArena:
    """Construye sobre el modelo YA cargado por la celda GATE (CURA-7). Requisito:
    los params del trainable_set deben llegar con requires_grad=True o pasarse por
    marcar_trainable() antes de construir."""

    def __init__(self, model: nn.Module, fgl: int, n_micros: int, T: int, H: int = 2688,
                 dev: str = "cuda:0", grad_slice_mib: int = 64):
        self.dev = torch.device(dev)
        self.model = model
        self.layers: nn.ModuleList = model.backbone.layers
        self.n_layers = len(self.layers)
        self.fgl = fgl
        self.K = n_micros
        self.T, self.H = T, H
        self.grad_slice_elems = (grad_slice_mib * 1024 * 1024) // 2   # elementos fp16

        self.s_h2d, self.s_comp, self.s_d2h = (torch.cuda.Stream(device=self.dev) for _ in range(3))

        self.stream_index: List[List[Tuple[str, int, int]]] = []  # por capa: (nombre, off, numel)
        self.pin_slabs: List[Optional[torch.Tensor]] = []
        self.resident: Dict[str, torch.Tensor] = {}               # nombre completo → tensor fp16 GPU
        self.pin_grads: Dict[str, List[torch.Tensor]] = {}        # nombre param → rebanadas fp16 pinned
        self.trainable_flat_names: List[str] = []

        layer_stream_numels = []
        for l_idx, blk in enumerate(self.layers):
            entries, off = [], 0
            for pname, p in blk.named_parameters():
                fullname = f"backbone.layers.{l_idx}.{pname}"
                n = p.numel()
                if _EXPERT_MARK in fullname:
                    entries.append((fullname, pname, p, off, n)); off += n
                else:
                    # BF-03: tronco residente 1 vez, jamás vuelve a viajar
                    with torch.no_grad():
                        resid = torch.empty_like(p, dtype=torch.float16, device=self.dev)
                        resid.copy_(p.data)
                    p.data = resid
                    p.requires_grad_(p.requires_grad)  # preserva flag del caller
                    self.resident[fullname] = resid
                if p.requires_grad:
                    self.trainable_flat_names.append(f"{l_idx}::{fullname}")
            if off:
                slab = torch.empty(off, dtype=torch.float16, pin_memory=True)
                fill = 0
                for fullname, pname, p, o, n in entries:
                    with torch.no_grad():
                        slab[o:o + n].copy_(p.data.detach().view(-1).to(torch.float16).cpu())
                    fill = o + n
                self.pin_slabs.append(slab)
                layer_stream_numels.append(off)
            else:
                self.pin_slabs.append(None)
                layer_stream_numels.append(0)
            # registrar book-keeping de vistas (frames de rebind tras arena)
            self.stream_index.append([(e[0], e[3], e[4]) for e in entries])
            for fullname, pname, p, o, n in entries:
                self._pending_bind = getattr(self, "_pending_bind", {})
                self._pending_bind[fullname] = (p, l_idx, o, n, p.shape)

        self.layer_stream_bytes = [n * 2 for n in layer_stream_numels]
        max_stream = max(layer_stream_numels) if layer_stream_numels else 1
        self.vram_buf_ab = [torch.empty(max(max_stream, 1), dtype=torch.float16, device=self.dev),
                            torch.empty(max(max_stream, 1), dtype=torch.float16, device=self.dev)]
        # AF-02: vinculación PERMANENTE p.data ↔ vista de BUF_A/B (jamás se muta in-step)
        for fullname, (p, l_idx, o, n, shp) in self._pending_bind.items():
            p.data = self.vram_buf_ab[l_idx % 2][o:o + n].view(shp)

        # masters fp32 y estados (localidad auto: gpu si cabe holgado, cpu si no)
        self.masters_cpu: Dict[str, torch.Tensor] = {}
        self.opt_m: Dict[str, torch.Tensor] = {}
        self.opt_v: Dict[str, torch.Tensor] = {}
        self._total_train_elems = 0
        for fullname in [x.split("::", 1)[1] for x in self.trainable_flat_names]:
            p = self._param_by_fullname(fullname)
            self._total_train_elems += p.numel()
        self.opt_locality = "gpu" if self._total_train_elems * 12 <= (2 << 30) else "cpu"
        for fullname in [x.split("::", 1)[1] for x in self.trainable_flat_names]:
            p = self._param_by_fullname(fullname)
            host_dev = "cpu" if self.opt_locality == "cpu" else self.dev
            w = p.detach().data.float().cpu() if host_dev == "cpu" else p.detach().data.float()
            if host_dev == "cpu" and w.abs().max().item() > 65504.0:
                raise RuntimeError(f"[LTUS] master {fullname} fuera de rango fp16 (sombra imposible)")
            self.masters_cpu[fullname] = w
            self.opt_m[fullname] = torch.zeros_like(w)
            self.opt_v[fullname] = torch.zeros_like(w)
            # rebanadas pinned fp16 para gradiente (cura E-8: NADA de .float() en GPU)
            slices = []
            for o in range(0, p.numel(), self.grad_slice_elems):
                slices.append(torch.empty(min(self.grad_slice_elems, p.numel() - o),
                                          dtype=torch.float16, pin_memory=True))
            self.pin_grads[fullname] = slices
        self.opt_state = {"t": 0}

        # BF-04 + cura E-3/E-11: fronteras pinned + acts ping-pong GPU (2 bancos alternos)
        self.pin_borders = {l: [torch.empty((T, H), dtype=torch.float16, pin_memory=True)
                                for _ in range(n_micros)] for l in range(self.fgl, self.n_layers)}
        self.acts_ab = [[torch.empty((T, H), dtype=torch.float16, device=self.dev) for _ in range(n_micros)]
                        for _ in range(2)]
        self.recomp_in = [torch.empty((T, H), dtype=torch.float16, device=self.dev) for _ in range(n_micros)]

        # EF-03: métricas 0-D (1 lectura de 8 B al cerrar el step)
        self.vram_metrics = torch.zeros(2, dtype=torch.float32, device=self.dev)
        self.pin_metrics = torch.zeros(2, dtype=torch.float32, pin_memory=True)

    def _param_by_fullname(self, fullname: str) -> nn.Parameter:
        node = self.model
        parts = fullname.split(".")
        for s in parts[:-1]:
            node = getattr(node, s) if not s.isdigit() else node[int(s)]
        return getattr(node, parts[-1])

    def _vdev_for(self, l_idx: int) -> int:
        return l_idx % 2


# ═══ §5 · TAPE (GF-01): partitura → cola triple cerrada (cura E-10: run-ahead) ═══
def _chunked_norm_sq_(acc_scalar: torch.Tensor, g_flat: torch.Tensor, chunk_elems: int) -> None:
    for o in range(0, g_flat.numel(), chunk_elems):
        s = g_flat[o:o + chunk_elems]
        acc_scalar.add_(s.float().pow(2).sum())

def construir_tape_step(arena: LTUSAutopistaArena, labels_gpu: List[torch.Tensor],
                        bwd_profile: str = "psi11_wgrad_only",
                        lookahead: Optional[int] = None):
    """[ISA 1.4-CASA-256] CURA-14 + CURA-15 aplicadas.

    CURA-14 (crash real, cazado por Argon/255): `_border(l)`, `_fwd(l)`, `_bwd(i,l)` y
    `_offload(l)` EJECUTABAN su cuerpo durante la construcción del tape y devolvían None;
    el ejecutor hacía `None()` en la micro-op 5. Ahora las cuatro son FÁBRICAS que
    devuelven una clausura `_op()` sin argumentos (mismo patrón que `h2d_op`).

    CURA-15 (crash real): el bloque `NemotronHBlock.forward` exige 3D (`bsz, seq, hidden`)
    y `position_ids`; en FWD se pasaban acts 2D sin `.unsqueeze(0)` y sin `position_ids`
    (que sólo se resuelve en el backbone, nunca en atención ⇒ AttributeError en la
    primera capa de atención). Ahora: 3D + `position_ids` explícitos, calculados una vez.

    [§11 conectado] `lookahead` (None ⇒ 2, o lo que diga `ControladorLTUS`) fija cuántas
    capas por delante se prefetchean; antes la perilla del controlador no tenía consumidor.
    """
    L, K, fgl = arena.n_layers, arena.K, arena.fgl
    la = 2 if lookahead is None else max(1, min(int(lookahead), 8))
    ev = lambda: torch.cuda.Event(enable_timing=False)
    evt = lambda: torch.cuda.Event(enable_timing=True)
    ev_step_start, ev_step_end = evt(), evt()
    ev_h2d = {i: evt() for i in range(L)}
    ev_h2d0 = {i: evt() for i in range(L)}
    ev_comp0 = {l: evt() for l in range(L)}
    ev_comp = {l: evt() for l in range(L)}
    ev_border = {l: ev() for l in range(fgl, L)}
    ev_ce = ev()
    tape = []

    # [CURA-15] position_ids/cache_position una sola vez, no por capa ni por micro-lote
    pid = getattr(arena, "position_ids", None)
    if pid is None:
        pid = torch.arange(arena.T, device=arena.dev, dtype=torch.long).unsqueeze(0)
        arena.position_ids = pid
    cpos = getattr(arena, "cache_position", None)
    if cpos is None:
        cpos = torch.arange(arena.T, device=arena.dev, dtype=torch.long)
        arena.cache_position = cpos

    tape.append((arena.s_comp, [], lambda: arena.vram_metrics.zero_(), [ev_step_start]))

    # ---- fábricas de micro-ops (CURA-14): devuelven callables, no ejecutan ----
    def h2d_op(l: int):
        n = len_stream_elems(arena, l)
        if n == 0:
            return lambda: None
        buf = arena.vram_buf_ab[l % 2]
        slab = arena.pin_slabs[l]
        return lambda: buf[:n].copy_(slab, non_blocking=True)

    def _make_border(lcur: int):
        def _op_border():
            banco = lcur % 2
            for m in range(K):
                arena.pin_borders[lcur][m].copy_(arena.acts_ab[banco][m], non_blocking=True)
        return _op_border

    def _make_fwd(lcur: int):
        def _op_fwd():
            ev_comp0[lcur].record(arena.s_comp)
            blk = arena.layers[lcur]
            banco_in, banco_out = lcur % 2, (lcur + 1) % 2
            with torch.no_grad():
                for m in range(K):
                    out3 = blk(arena.acts_ab[banco_in][m].unsqueeze(0),       # CURA-15
                               cache_params=None, cache_position=cpos,
                               attention_mask=None, position_ids=pid)
                    arena.acts_ab[banco_out][m].copy_(out3.view(arena.T, arena.H).half())
        return _op_fwd

    def _make_bwd(icur: int, lcur: int):
        def _op_bwd():
            blk = arena.layers[lcur]
            for fullname in trainable_names_of_layer(arena, lcur):
                p_ = arena._param_by_fullname(fullname)
                if p_.grad is not None:
                    p_.grad.zero_()
            for m in range(K):
                arena.recomp_in[m].copy_(arena.pin_borders[lcur][m], non_blocking=True)
                inp = arena.recomp_in[m].detach().requires_grad_(True)
                out = blk(inp.unsqueeze(0), cache_params=None, cache_position=cpos,
                          attention_mask=None, position_ids=pid).view(arena.T, arena.H)
                out.backward(grads_flow[m])
                grads_flow[m] = inp.grad.detach()
            for fullname in trainable_names_of_layer(arena, lcur):
                p_ = arena._param_by_fullname(fullname)
                if p_.grad is not None:
                    _chunked_norm_sq_(arena.vram_metrics[1], p_.grad.detach().view(-1),
                                      arena.grad_slice_elems)
        return _op_bwd

    def _make_offload(lcur: int):
        def _op_offload():
            for fullname in trainable_names_of_layer(arena, lcur):
                p_ = arena._param_by_fullname(fullname)
                slices = arena.pin_grads[fullname]
                g = p_.grad
                if g is None:
                    continue
                gf = g.detach().view(-1)
                o = 0
                for sl in slices:
                    n = sl.numel()
                    sl.copy_(gf[o:o + n], non_blocking=True)
                    o += n
        return _op_offload

    # ---- arranque del pipeline H2D (lookahead capas) ----
    n_pref = min(la, L)
    for l in range(n_pref):
        tape.append((arena.s_h2d, [], (lambda ll=l: ev_h2d0[ll].record(arena.s_h2d)), []))
        tape.append((arena.s_h2d, [], h2d_op(l), [ev_h2d[l]]))

    # ---- FWD ----
    for l in range(L):
        if l >= fgl:
            wait_prev = [ev_comp[l - 1]] if l > 0 else [ev_step_start]
            tape.append((arena.s_d2h, wait_prev, _make_border(l), [ev_border[l]]))

        waits = [ev_h2d[l]]
        if l >= (fgl + 1) and (l - 1) in ev_border:
            waits.append(ev_border[l - 1])
        tape.append((arena.s_comp, waits, _make_fwd(l), [ev_comp[l]]))

        if l + n_pref < L:
            ln = l + n_pref
            tape.append((arena.s_h2d, [ev_comp[l]], (lambda ll=ln: ev_h2d0[ll].record(arena.s_h2d)), []))
            tape.append((arena.s_h2d, [], h2d_op(ln), [ev_h2d[ln]]))

    # ---- CE real chunked (EF-04) ----
    banco_top = L % 2
    grad_top = [torch.empty_like(x) for x in arena.acts_ab[banco_top]]

    def _ce():
        blk_norm = arena.model.backbone.norm_f
        w_vocab = arena.model.lm_head.weight
        for m in range(K):
            h = blk_norm(arena.acts_ab[banco_top][m].unsqueeze(0)).squeeze(0)
            h_leaf = h.detach().requires_grad_(True)
            loss, _n = ce_loss_chunked(h_leaf, labels_gpu[m], w_vocab, chunk=1024)
            loss.backward()
            arena.vram_metrics[0].add_(loss.detach() / K)
            grad_top[m].copy_(h_leaf.grad)
    tape.append((arena.s_comp, [ev_comp[L - 1]], _ce, [ev_ce]))

    # ---- BWD ----
    bwd_layers = list(range(L - 1, fgl - 1, -1))
    ev_bwd_h2d = {i: ev() for i in range(len(bwd_layers))}
    ev_bwd = {i: evt() for i in range(len(bwd_layers))}
    grads_flow = grad_top
    for i, l in enumerate(bwd_layers):
        skip_prefetch = (bwd_profile == "psi11_wgrad_only" and i < 2)  # E-12
        if len_stream_elems(arena, l) > 0 and not skip_prefetch:
            tape.append((arena.s_h2d, [ev_ce if i == 0 else ev_bwd[i - 1]], h2d_op(l), [ev_bwd_h2d[i]]))

        waits_b = [ev_ce] if i == 0 else [ev_bwd[i - 1]]
        if (not skip_prefetch) and len_stream_elems(arena, l) > 0:
            waits_b.append(ev_bwd_h2d[i])
        if l in ev_border:
            waits_b.append(ev_border[l])
        tape.append((arena.s_comp, waits_b, _make_bwd(i, l), [ev_bwd[i]]))

        if trainable_names_of_layer(arena, l):
            tape.append((arena.s_d2h, [ev_bwd[i]], _make_offload(l), []))

    tape.append((arena.s_d2h, [ev_bwd[len(bwd_layers) - 1]],
                 lambda: arena.pin_metrics.copy_(arena.vram_metrics, non_blocking=True), [ev_step_end]))
    eventos = {"start": ev_step_start, "end": ev_step_end, "h2d": ev_h2d, "h2d0": ev_h2d0,
               "comp0": ev_comp0, "comp": ev_comp, "n_layers": L, "lookahead": la}
    return tape, eventos


def len_stream_elems(arena: LTUSAutopistaArena, l: int) -> int:
    return sum(n for _, _, n in arena.stream_index[l])

def trainable_names_of_layer(arena: LTUSAutopistaArena, l: int) -> List[str]:
    pref = f"backbone.layers.{l}."
    return [n.split("::", 1)[1] for n in arena.trainable_flat_names if n.split("::", 1)[1].startswith(pref)]


# ═══ §6 · EJECUTOR (10 líneas host-free) + GATE 5 + OPTIMIZER POST-STEP (EF-02) ═══
def ejecutar_partitura_autopista(arena: LTUSAutopistaArena, tape: list, eventos: dict) -> Dict:
    torch.cuda.synchronize(arena.dev)
    t0 = time.perf_counter()
    for stream, waits, fn, recs in tape:                 # ← las 10 líneas sagradas
        with torch.cuda.stream(stream):
            for w in waits:
                stream.wait_event(w)
            fn()
            for r in recs:
                r.record(stream)
    t_enqueue = (time.perf_counter() - t0) * 1e3
    eventos["end"].synchronize()
    wall = (time.perf_counter() - t0) * 1e3

    L = eventos["n_layers"]
    comp = eventos["comp"]
    ms_h2d = sum(eventos["h2d0"][l].elapsed_time(eventos["h2d"][l]) for l in range(L)
                 if l in eventos["h2d"])
    stall = max(0.0, eventos["h2d0"][0].elapsed_time(eventos["h2d"][0])) if 0 in eventos["h2d"] else 0.0
    for l in range(1, L):
        if l in eventos["h2d"]:
            stall += max(0.0, comp[l - 1].elapsed_time(eventos["h2d"][l]))
    span = eventos["start"].elapsed_time(eventos["end"])
    busy = max(0.0, span - stall)
    busy_pct = round(100.0 * busy / max(wall, 1e-6), 2)
    overlap = round(100.0 * (1.0 - min(stall / max(ms_h2d, 1e-6), 1.0)), 2) if ms_h2d > 0 else 100.0
    vram_peak = round(torch.cuda.max_memory_allocated(arena.dev) / (1024 ** 2), 1)
    rep = {"L_T_U::_0_REPORT_JSON": {
        "loss": None, "grad_norm_l2": None,
        "wall_ms": round(wall, 1), "enqueue_ms": round(t_enqueue, 1),
        "GPU_busy_ms": round(busy, 1), "GPU_busy_pct": busy_pct,
        "overlap_pct": overlap, "vram_peak_mib": vram_peak,
        "gate1_overlap70": overlap >= 70.0, "gate2_vram14500": vram_peak <= 14500.0,
        "gate5_gpu_busy90": busy_pct >= 90.0}}
    print(json.dumps(rep), flush=True)
    return rep


def ltus_commit_step(arena: LTUSAutopistaArena, lr: float = 1e-5, wd: float = 0.1,
                    b1: float = 0.9, b2: float = 0.95, eps: float = 1e-8,
                    clip: float = 1.0) -> Dict:
    """EF-02: corre TRAS el fin del step, oculto bajo el FWD 0..fgl-1 del step siguiente
    (el caller lo invoca a continuación de soltar el tape de FWD del step t+1).
    Lee pin_metrics (ya volcados), decide descarte, aplica clip global y AdamW."""
    loss = float(arena.pin_metrics[0].item())                      # fin de step: sync permitida
    norm_sq = float(arena.pin_metrics[1].item())
    if math.isnan(loss) or math.isinf(loss) or math.isnan(norm_sq) or math.isinf(norm_sq):
        print(f"[LTUS · commit DESCARTADO] loss={loss} norm²={norm_sq}", flush=True)
        return {"commited": False, "loss": loss}
    coef = min(1.0, clip / (math.sqrt(norm_sq) + 1e-6))
    t = arena.opt_state["t"] = arena.opt_state["t"] + 1
    dev_cpu = arena.opt_locality == "cpu"
    for name, w in arena.masters_cpu.items():
        slices = arena.pin_grads[name]
        if dev_cpu:
            parts = [sl.float() for sl in slices]
            g = torch.cat(parts) * coef
        else:  # locality gpu: el grad sigue en GPU (LoRA-residente) — leerlo directo
            p = arena._param_by_fullname(name)
            g = p.grad.detach().float().view(-1) * coef
        m, v = arena.opt_m[name], arena.opt_v[name]
        w.mul_(1.0 - lr * wd)
        m.lerp_(g, 1.0 - b1)
        v.mul_(b2).addcmul_(g, g, value=1.0 - b2)
        denom = (v.sqrt() / math.sqrt(1.0 - b2 ** t)).add_(eps)
        w.addcdiv_(m, denom, value=-lr / (1.0 - b1 ** t))
        # refrescar sombra fp16 en su hábitat
        p = arena._param_by_fullname(name)
        with torch.no_grad():
            sombra = w.to(torch.float16)
            if name in arena.resident:
                arena.resident[name].copy_(sombra.to(arena.dev) if dev_cpu else sombra)
            else:
                l_idx = int(name.split(".")[2])
                entries = [(o, n) for full, o, n in arena.stream_index[l_idx] if full == name]
                if entries:
                    o, n = entries[0]
                    arena.pin_slabs[l_idx][o:o + n].copy_(sombra.view(-1).cpu() if dev_cpu else sombra.view(-1))
    return {"commited": True, "loss": round(loss, 6), "grad_norm": round(math.sqrt(norm_sq), 6),
            "clip_coef": round(coef, 6), "step": t, "opt_locality": arena.opt_locality}


# ═══ §7 · PUMP DE DATOS (FF-01) y ROUTE_CENSUS (EXP-H4, formato A-2) ═══
class DataPump:
    """Hilo productor: tokeniza/pack el siguiente step mientras la GPU mastica el actual.
    Gate: t_data_wait_ms < 1 ms desde el step 2 (FF-01)."""

    def __init__(self, producer_fn: Callable[[], Tuple[torch.Tensor, torch.Tensor]]):
        self.producer_fn = producer_fn
        self.q: queue.Queue = queue.Queue(maxsize=2)
        self._stop = threading.Event()
        self.th = threading.Thread(target=self._loop, daemon=True)

    def _loop(self):
        while not self._stop.is_set():
            item = self.producer_fn()
            self.q.put(item)

    def start(self):
        self.th.start()
        return self

    def get(self) -> Tuple[torch.Tensor, torch.Tensor]:
        t0 = time.perf_counter()
        out = self.q.get()
        self.last_wait_ms = (time.perf_counter() - t0) * 1e3
        return out

    def stop(self):
        self._stop.set()


def route_census(model: nn.Module, packs: List[torch.Tensor], top_k: int = 6,
                 max_layers_report: int = 64) -> Dict:
    """EXP-H4. Hooks sobre los routers (nombre termina en '.mixer.gate'); cuenta por capa el
    nº de expertos distintos activados. Formato exacto del Apéndice 244-A A-2. SOLO no_grad."""
    capturas: Dict[str, List[torch.Tensor]] = {}
    hooks = []
    for name, mod in model.named_modules():
        if name.endswith("mixer.gate") or name.endswith("mixer.v4x_router"):
            def mk(nm):
                return lambda m, i, o: capturas.setdefault(nm, []).append(
                    o.detach() if torch.is_tensor(o) else o[0].detach())
            hooks.append(mod.register_forward_hook(mk(name)))
    with torch.no_grad():
        for x in packs:
            model.backbone(model.embeddings(x)) if hasattr(model.backbone, "embeddings") else model(x)
    for h in hooks:
        h.remove()
    por_capa = {}
    for name, outs in capturas.items():
        l_idx = name.split(".")[2] if ".layers." in name else name
        distintos = []
        for o in outs:
            t = o.view(-1, o.shape[-1]).float() if o.dim() >= 2 else o.float()
            if t.shape[-1] == top_k:                      # ya son índices [*,K]
                idx = t.to(torch.int64).view(-1)
            else:                                          # logits/probs [*,E]
                idx = t.topk(top_k, dim=-1).indices.view(-1)
            distintos.append(int(idx.unique().numel()))
        if distintos:
            ds = sorted(distintos)
            por_capa[str(l_idx)] = {"distintos_max": max(ds),
                                    "distintos_p95": ds[int(0.95 * (len(ds) - 1))],
                                    "n_microbatches": len(ds)}
    rep = {"route_census": {"top_k": top_k, "por_cap_moe": por_capa,
                            "fit_640mib_lamina": all(v["distintos_max"] <= 26 for v in
                                                   por_capa.values() if por_capa)}}
    print(json.dumps(rep, ensure_ascii=False), flush=True)
    return rep


# ═══ §8 · FASE 2: FUENTE DE TORRES (N-1) + PRESUPUESTO DE RESIDENCIA (N-4) ═══
import re
import collections

def tower_source_probe(index_json_path: str) -> Dict:
    """N-1. Censo del index del checkpoint: ¿qué familias de torres existen?
    Decide el loader de Fase 2: (a) pesos desde el propio ckpt si hay claves de
    torre; (b) desde HF originales si no. Ejecutable dentro de la AUTOPSIA."""
    with open(index_json_path, "r", encoding="utf-8") as f:
        wm = json.load(f)["weight_map"]
    fam, slots = collections.Counter(), set()
    for k in wm:
        m = re.match(r"backbone\.layers\.(\d+)\.V4X\.experts\.(\d+)\.", k)
        if m:
            slots.add(int(m.group(2)))
            fam["<<expert_slots>>"] += 1
        else:
            fam[k.split(".")[0]] += 1
    towers = {n: c for n, c in fam.items() if n.startswith("V4X_")}
    rep = {"families": dict(fam), "towers_in_ckpt": towers,
           "expert_slots": {"count": len(slots),
                            "range": [min(slots), max(slots)] if slots else None},
           "loader_decision": ("ckpt" if towers else "hf_originales") if fam else "autopsia_no_ejecutada"}
    print(json.dumps(rep, ensure_ascii=False), flush=True)
    return rep


def tower_budget_report(measured_mib: Optional[Dict[str, float]] = None,
                        base_mib: float = 8842.0, cap_mib: float = 14500.0,
                        kv_tbptt_mib: float = 7680.0) -> Dict:
    """N-4. Presupuesto de residencia de torres en LTUS-0. measured_mib=None usa
    el censo-PAPEL de Argon (Tabla 2, pendiente de EXP-L2 — etiquetado como tal).
    kv_tbptt_mib: cache KV entre ventanas OOMB-500K (GQA real ≈ 7,5 GiB para 500K);
    si la ventana TBPTT lo mantiene en VRAM, se RESTA del margen; si vive en RAM
    con H2D/D2H inter-ventana (~1,8 s ocultables), pasar kv_tbptt_mib=0."""
    papel = {"V4X_Transcription_enc": 1214.9, "V4X_Music": 601.7,
             "V4X_Audio": 1236.0, "V4X_Vision+adapter": 1168.4, "DS_adapter": 80.1}
    t = measured_mib or papel
    etiqueta = "MEDIDO(EXP-L2)" if measured_mib else "PREVISTO-PAPEL(P)"
    margen = cap_mib - base_mib
    combos = [c for c in range(1, len(t) + 1)]
    import itertools
    legales = []
    for k in combos:
        for combo in itertools.combinations(t.items(), k):
            usado = sum(v for _, v in combo)
            legales.append((usado, [n for n, _ in combo], usado <= margen))
    legales_ok = sorted([x for x in legales if x[2]], key=lambda x: -x[0])
    rep = {"etiqueta": etiqueta, "base_mib": base_mib, "cap_mib": cap_mib,
           "margen_torres_mib": round(margen, 1),
           "combo_maximo": {"mib": legales_ok[0][0], "torres": legales_ok[0][1]} if legales_ok else None,
           "kv_tbptt_en_vram_mib": kv_tbptt_mib,
           "aviso": "con KV TBPTT residente, restar kv_tbptt_mib del margen" if kv_tbptt_mib > 0 else "KV TBPTT en RAM (inter-ventana)"}
    print(json.dumps(rep, ensure_ascii=False), flush=True)
    return rep



# ═══ §11 · [LTUS ADAPTATIVA AGRESIVA · CAMBIOS 254] CONTROLADOR EN CPU ═══
# Decreto del usuario (acta 254): para Kaggle la LTUS tiene que ser ADAPTATIVA AGRESIVA,
# y el argumento es de asignación de recursos: **la CPU sólo está para servir al
# entrenamiento**, luego la inteligencia de control vive ENTERA en el host y puede ser
# todo lo lista que queramos (cuesta <1% de CPU) sin robar un microsegundo de GPU.
#
# MARCO LÓGICO (el usuario viene de sacar un 10 en puertas lógicas — se nota):
#   · Una partitura FIJA es una MÁQUINA DE ESTADOS SIN REALIMENTACIÓN.
#   · La versión adaptativa mete realimentación, y con realimentación hay tres peligros
#     clásicos de circuito que se evitan con tres primitivas de toda la vida:
#       1) HISTÉRESIS  → para que el estado no vibre en el umbral (schmitt trigger).
#       2) DWELL       → tiempo mínimo de asentamiento antes de volver a tocar la misma perilla.
#       3) RESERVA     → margen duro de VRAM que ninguna acción puede invadir (el "rail").
#   · Y una regla de agresividad: los cambios son MULTIPLICATIVOS (×1,5 / ×0,63), un solo
#     mando por paso, y con prioridad fija. Agresiva ≠ caótica.
#
# LO QUE NUNCA HACE (vetos, cruzados contra los decretos vigentes):
#   · NO sincroniza dentro del step (AF-04 intacto): lee contadores síncronos sólo en
#     FRONTERAS de paso (y `mem_get_info` cada `cada_n_pasos`), nunca en el tape.
#   · NO cambia el plan a mitad de step: las acciones se aplican en la frontera, y cada
#     régimen nuevo se SELLA (plan_sha256 nuevo) → linaje auditable (DF-04).
#   · NO cambia la matemática a escondidas: cambiar K/lookahead/ce_chunk altera el ORDEN
#     de reducciones en coma flotante; por eso cada régimen es un plan sellado y la
#     paridad bit-a-bit (GATE-3) sólo se predica DENTRO del mismo régimen.
#   · NO explora a ciegas: primero memoriza regímenes medidos y SALTA al mejor que quepa
#     (explotación agresiva); sólo si no hay ninguno mejor, sondea multiplicativamente.
ESTADOS_LTUS = ("CRUISE", "STARVED", "CHOKED", "PANIC")


class ControladorLTUS:
    """Controlador adaptativo agresivo, en CPU, sin GPU-sync dentro del step.

    Entradas por frontera de paso (todas ya medidas, ninguna provoca sync nueva):
      peak_mib   VRAM de pico del paso en la GPU más cargada (max de las dos en bizonal)
      free_mib   VRAM libre AHORA en la GPU más cargada (del electrocardiograma)
      tok_s      tokens/s del paso (reloj de host, coste 0 GPU)
      busy_pct   % de tiempo de GPU ocupada en el paso (eventos CUDA, ya existentes)
      data_wait_ms  espera del pump de datos (FF-01, ya medida)
      frag_mib   reserved - allocated (fragmentación)
      oom        True si el paso anterior abortó por OOM
    Salida: dict-acción (o None si no hay nada que hacer). NUNCA aplica nada por sí mismo:
    el ejecutor aplica en la frontera y sella el régimen nuevo.
    """

    def __init__(self, cap_mib: float, margen_mib: float = 512.0, dwell: int = 3,
                 K0: int = 1, lookahead0: int = 2, ce_chunk0: int = 1024,
                 cada_n_pasos: int = 5):
        self.cap_mib = float(cap_mib)
        self.reserva_mib = float(margen_mib)       # rail infranqueable
        self.dwell = int(dwell)
        self.cada_n_pasos = int(cada_n_pasos)
        self.estado = "CRUISE"
        self.K = int(K0)
        self.lookahead = int(lookahead0)
        self.ce_chunk = int(ce_chunk0)
        self._ultimo_cambio = -10**9              # paso del último cambio POR PERILLA
        self._cambios = {"K": -10**9, "lookahead": -10**9, "ce_chunk": -10**9, "regimen": -10**9}
        self.regimenes: Dict[tuple, Dict] = {}    # memoria de regímenes medidos
        self.mejor_tok = 0.0                      # mejor tok/s visto (hill-climb con memoria)
        self._sondas_sin_mejora = 0               # [bug cazado en banco] meseta detectada
        self._probe_pendiente = False             # la acción anterior fue una sonda de K
        self._marginal_mib_por_K = None           # MiB medidos por unidad de K (estimador)
        self._peak_prev = None                    # para medir el marginal
        self._K_prev = None
        self._panic_seguidos = 0                  # escalera de PANIC
        self.halt = False                         # True = el controlador declara INVIABLE
        self.historial: List[Dict] = []           # traza auditable
        self.acciones = 0

    # ---------------- clasificación con HISTÉRESIS ----------------
    def clasifica(self, paso: int, peak_mib: float, free_mib: float, busy_pct: float,
                  data_wait_ms: float, frag_mib: float, oom: bool) -> str:
        techo = self.cap_mib - self.reserva_mib
        if oom or free_mib < 256.0:
            return "PANIC"
        if peak_mib > techo or frag_mib > 1024.0:
            return "CHOKED"
        # histéresis: para ENTRAR en STARVED hace falta busy<88; para SALIR, busy>92
        if self.estado == "STARVED":
            return "STARVED" if busy_pct < 92.0 else "CRUISE"
        if busy_pct < 88.0 or data_wait_ms > 1.0:
            return "STARVED"
        return "CRUISE"

    # ---------------- decisión ----------------
    def observa(self, paso: int, peak_mib: float, free_mib: float, tok_s: float = 0.0,
                busy_pct: float = 100.0, data_wait_ms: float = 0.0,
                frag_mib: float = 0.0, oom: bool = False) -> Optional[Dict]:
        if self.halt:
            return None                       # ya declaró inviabilidad: silencio hasta intervención
        nuevo = self.clasifica(paso, peak_mib, free_mib, busy_pct, data_wait_ms, frag_mib, oom)
        if nuevo != "PANIC":
            self._panic_seguidos = 0
        cambio_estado = (nuevo != self.estado)
        self.estado = nuevo

        # ── estimador de COSTE MARGINAL: en vez de adivinar (+25% ciego), medir ──
        if (self._peak_prev is not None and self._K_prev is not None
                and self.K != self._K_prev):
            dK = self.K - self._K_prev
            if dK > 0:
                medido = (peak_mib - self._peak_prev) / dK
                if medido > 0:
                    self._marginal_mib_por_K = (medido if self._marginal_mib_por_K is None
                                                else 0.5 * self._marginal_mib_por_K + 0.5 * medido)
        self._peak_prev, self._K_prev = peak_mib, self.K

        # ── aprendizaje de MESETA (agresiva pero no masoquista) ──
        if tok_s > self.mejor_tok * 1.02:
            self.mejor_tok = tok_s
            self._sondas_sin_mejora = 0
        elif self._probe_pendiente:
            self._sondas_sin_mejora += 1       # la sonda no mejoró: candidata a meseta
        self._probe_pendiente = False

        # memoria de régimenes: se registra SIEMPRE lo medido (aunque no se actúe)
        sig = (self.K, self.lookahead, self.ce_chunk)
        if tok_s > 0:
            prev = self.regimenes.get(sig)
            if prev is None or tok_s > prev["tok_s"]:
                self.regimenes[sig] = {"K": self.K, "lookahead": self.lookahead,
                                       "ce_chunk": self.ce_chunk, "tok_s": tok_s,
                                       "peak_mib": peak_mib}

        accion = self._decide(paso, peak_mib, free_mib, tok_s)
        if accion:
            accion["paso"] = paso
            accion["estado"] = self.estado
            accion["cambio_estado"] = cambio_estado
            self.acciones += 1
            self.historial.append(accion)
        elif cambio_estado:
            self.historial.append({"paso": paso, "estado": self.estado, "accion": "ninguna",
                                   "motivo": "transición de estado sin acción (dentro de reserva)",
                                   "cambio_estado": True})
        return accion

    def _cabe(self, peak_pred: float) -> bool:
        return peak_pred <= (self.cap_mib - self.reserva_mib)

    def predice_peak(self, K_destino: int, peak_mib: float) -> float:
        """Predicción con coste marginal MEDIDO (o heurística etiquetada si aún no hay dato).
        Colchón de 64 MiB por ruido de allocator. Sin esto la agresividad es una apuesta."""
        if self._marginal_mib_por_K is not None:
            return peak_mib + self._marginal_mib_por_K * (K_destino - self.K) + 64.0
        return peak_mib + 0.25 * peak_mib        # PREVISTO-PAPEL(P): sin medidas aún

    def _permitido(self, perilla: str, paso: int) -> bool:
        return (paso - self._cambios[perilla]) >= self.dwell

    def _decide(self, paso: int, peak_mib: float, free_mib: float, tok_s: float) -> Optional[Dict]:
        techo = self.cap_mib - self.reserva_mib

        # ── PANIC: supervivencia. Se cede TODO, en un solo paso, sin esperar dwell ──
        if self.estado == "PANIC":
            self._sondas_sin_mejora = 0        # el paisaje ha cambiado: reabrir exploración
            self._panic_seguidos += 1
            # ESCALERA: si ya estamos en el mínimo y sigue el OOM, el régimen es INVIABLE.
            # No se repite el mismo grito: se declara y se para (fail-fast, no vibración).
            if self._panic_seguidos >= 2 and (self.K, self.lookahead, self.ce_chunk) == (1, 1, 128):
                self.halt = True
                return {"accion": "INVIABLE", "antes": (1, 1, 128), "despues": (1, 1, 128),
                        "motivo": "PANIC con todo al mínimo: el régimen no cabe en este destino. "
                                  "Acción humana: soltar torres residentes, cambiar target o "
                                  "reducir T; el controlador NO insiste (halt)."}
            antes = (self.K, self.lookahead, self.ce_chunk)
            self.K = 1
            self.lookahead = 1
            self.ce_chunk = max(128, self.ce_chunk // 2)
            self._cambios.update({k: paso for k in self._cambios})
            return {"accion": "PANIC_DRENAJE", "antes": antes,
                    "despues": (self.K, self.lookahead, self.ce_chunk),
                    "motivo": f"OOM/free={free_mib:.0f}MiB: K=1, lookahead=1, ce_chunk/2"}

        # ── CHOKED: recortar el mando que más pesa (K primero), multiplicativo ×0,63 ──
        if self.estado == "CHOKED":
            self._sondas_sin_mejora = 0        # el paisaje ha cambiado: reabrir exploración
            if self.K > 1 and self._permitido("K", paso):
                antes = self.K
                nuevo = max(1, int(self.K * 0.63))
                self.K, self._cambios["K"] = nuevo, paso
                return {"accion": "RECORTA_K", "perilla": "K", "antes": antes, "despues": nuevo,
                        "motivo": f"peak={peak_mib:.0f}>techo={techo:.0f} MiB (reserva {self.reserva_mib:.0f})"}
            if self.ce_chunk > 128 and self._permitido("ce_chunk", paso):
                antes = self.ce_chunk
                self.ce_chunk = max(128, self.ce_chunk // 2)
                self._cambios["ce_chunk"] = paso
                return {"accion": "RECORTA_CE_CHUNK", "perilla": "ce_chunk", "antes": antes,
                        "despues": self.ce_chunk, "motivo": f"peak={peak_mib:.0f}>techo={techo:.0f}"}
            if self.lookahead > 1 and self._permitido("lookahead", paso):
                antes = self.lookahead
                self.lookahead = max(1, self.lookahead // 2)
                self._cambios["lookahead"] = paso
                return {"accion": "RECORTA_LOOKAHEAD", "perilla": "lookahead", "antes": antes,
                        "despues": self.lookahead, "motivo": "libera slabs de prefetch"}
            return None

        # ── STARVED: la GPU espera. Se ataca el cuello con ×2 (agresivo) ──
        if self.estado == "STARVED":
            if self.lookahead < 8 and self._permitido("lookahead", paso):
                antes = self.lookahead
                self.lookahead = min(8, self.lookahead * 2)
                self._cambios["lookahead"] = paso
                return {"accion": "SUBE_LOOKAHEAD", "perilla": "lookahead", "antes": antes,
                        "despues": self.lookahead, "motivo": "GPU esperando: +prefetch"}
            if self._permitido("K", paso):
                K_next = max(self.K + 1, int(self.K * 1.5))       # +1 garantizado
                pred = self.predice_peak(K_next, peak_mib)
                if self._cabe(pred):
                    antes = self.K
                    self.K = K_next
                    self._cambios["K"] = paso
                    self._probe_pendiente = True
                    return {"accion": "SUBE_K", "perilla": "K", "antes": antes, "despues": self.K,
                            "motivo": f"más trabajo por paso si cabe (pred {pred:.0f} ≤ {techo:.0f})"}
            return None

        # ── CRUISE: EXPLOTACIÓN AGRESIVA — saltar al mejor régimen medido que quepa ──
        mejor = None
        for sig, r in self.regimenes.items():
            if sig == (self.K, self.lookahead, self.ce_chunk):
                continue
            if r["peak_mib"] <= techo and r["tok_s"] > tok_s * 1.05:
                if mejor is None or r["tok_s"] > mejor["tok_s"]:
                    mejor = r
        if mejor is not None and self._permitido("regimen", paso):
            antes = (self.K, self.lookahead, self.ce_chunk)
            self.K, self.lookahead, self.ce_chunk = mejor["K"], mejor["lookahead"], mejor["ce_chunk"]
            self._cambios["regimen"] = self._cambios["K"] = self._cambios["lookahead"] = paso
            return {"accion": "SALTO_A_REGIMEN", "antes": antes,
                    "despues": (self.K, self.lookahead, self.ce_chunk),
                    "motivo": f"mejor medido {mejor['tok_s']:.0f} tok/s (actual {tok_s:.0f}), "
                              f"peak {mejor['peak_mib']:.0f} ≤ {techo:.0f}"}
        # ── CRUISE sin régimen mejor: sonda multiplicativa (una perilla, con reserva) ──
        # techo de rendimiento aprendido: dos sondas sin mejorar ≥2% ⇒ se deja de sondear
        if self._sondas_sin_mejora >= 2:
            return None
        if self._permitido("K", paso):
            K_next = max(self.K + 1, int(self.K * 1.5))           # +1 garantizado
            pred = self.predice_peak(K_next, peak_mib)
            if self._cabe(pred):
                antes = self.K
                self.K = K_next
                self._cambios["K"] = paso
                self._probe_pendiente = True
                return {"accion": "SONDA_K", "perilla": "K", "antes": antes, "despues": self.K,
                        "motivo": f"sonda agresiva (pred {pred:.0f} ≤ {techo:.0f})"}
        return None

    # ---------------- linaje de planes (DF-04) ----------------
    def firma_regimen(self) -> Dict:
        return {"K": self.K, "lookahead": self.lookahead, "ce_chunk": self.ce_chunk,
                "estado": self.estado, "acciones": self.acciones}

    def linaje(self, plan_base: Dict) -> List[Dict]:
        """Devuelve un plan POR CADA régimen tocado, cada uno con su sha256 propio.
        Así una partitura nunca miente: el step N corrió bajo un plan concreto y sellado."""
        vistos, salida = set(), []
        for reg in [(1, 2, 1024)] + [(r["K"], r["lookahead"], r["ce_chunk"]) for r in self.regimenes.values()]:
            if reg in vistos:
                continue
            vistos.add(reg)
            p = {k: v for k, v in plan_base.items() if k != "plan_sha256"}
            p["regimen"] = {"K": reg[0], "lookahead": reg[1], "ce_chunk": reg[2]}
            p["plan_sha256"] = None
            sellar_partitura_sha256(p)
            salida.append(p)
        return salida



# ═══ §12 · [LTUS, CAMBIOS 255] GOBERNADOR DE CPU: ADAPTATIVO POR DEFECTO, FIJABLE A X NÚCLEOS ═══
# Decreto del usuario (acta 255): en Kaggle la CPU SÓLO sirve al entrenamiento, así que la
# LTUS debe repartir los núcleos ella sola (**adaptativo por defecto**) y, cuando el usuario
# quiera, quedarse clavada en **X núcleos** (`V4X_LTUS_CPU_CORES=X` o `configurar_cpu(X)`).
#
# HONESTIDAD TÉCNICA (esto no se puede prometer de más):
#   · Los hilos INTRA-OP de PyTorch (`torch.set_num_threads`) **sí** se pueden cambiar en
#     caliente, cuantas veces se quiera.
#   · Los pools de OpenMP/MKL (`OMP_NUM_THREADS`, `MKL_NUM_THREADS`) sólo se leen FIABLEMENTE
#     antes de importar torch. Por eso hay dos puertas: `env_cpu_preimport()` (antes del
#     import) y `configurar_cpu()` (en caliente, para intra-op + nuestros hilos).
#   · `os.cpu_count()` MIENTE dentro de contenedores (Kaggle): devuelve los del host, no la
#     cuota. Se lee la afinidad real (`sched_getaffinity`) y la cuota de cgroup v1/v2.
KAGGLE_VCPU_T4 = 4          # perfil de referencia: portátil Kaggle 2xT4 = 4 vCPU (PAPEL: verificar en máquina)


def nucleos_disponibles() -> int:
    """Núcleos REALMENTE usables: afinidad ∩ cuota de cgroup ∩ cpu_count. Sin mentiras de host."""
    cands = []
    try:
        n_af = len(_os.sched_getaffinity(0))
    except (AttributeError, OSError):
        n_af = None
    if n_af:
        cands.append(n_af)
    # cgroup v2: /sys/fs/cgroup/cpu.max -> "<quota> <period>" ('max' = ilimitado)
    for ruta, lector in (
        ("/sys/fs/cgroup/cpu.max", lambda t: (None if t.split()[0] == "max"
                                             else max(1, int(int(t.split()[0]) // int(t.split()[1]))))),
        ("/sys/fs/cgroup/cpu/cpu.cfs_quota_us", None),   # v1: se resuelve abajo
    ):
        try:
            if ruta.endswith("cpu.max"):
                with open(ruta, encoding="utf-8") as f:
                    q = lector(f.read())
                if q:
                    cands.append(q)
            else:
                with open(ruta, encoding="utf-8") as f:
                    quota = int(f.read().strip())
                with open("/sys/fs/cgroup/cpu/cpu.cfs_period_us", encoding="utf-8") as f:
                    period = int(f.read().strip())
                if quota > 0 and period > 0:
                    cands.append(max(1, quota // period))
        except (OSError, ValueError, IndexError):
            continue
    if _os.cpu_count():
        cands.append(int(_os.cpu_count()))
    return max(1, min(cands)) if cands else 1


def reparto_cpu(n_cores: int, pump: bool = True) -> Dict[str, int]:
    """Reparte X núcleos entre las piezas que de verdad compiten. Adaptativo, no mágico:
       - el hilo principal alimenta la GPU (nunca puede morir de hambre)  → 1
       - DataPump (FF-01)                                                    → 1 si pump
       - el resto, a intra-op de PyTorch (las GEMM de host y las norms)      → máx(1, X-2)
       Si X es pequeño, se degrada con criterio: primero se recorta intra-op."""
    n = max(1, int(n_cores))
    principal = 1
    datos = 1 if (pump and n >= 3) else 0
    intra = max(1, n - principal - datos)
    return {"total": n, "principal": principal, "datos": datos, "intra_op": intra}


def env_cpu_preimport(n_cores: Optional[int] = None, reserva: int = 0) -> Dict:
    """Puerta 1: ANTES de importar torch. Deja OMP/MKL coherentes para toda la vida del proceso.
    Debe llamarse al principio de la celda/motor, no después de `import torch`."""
    disp = nucleos_disponibles()
    n = disp - reserva if n_cores is None else int(n_cores)
    n = max(1, min(n, disp))
    rep = reparto_cpu(n)
    for var in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS",
                "VECLIB_MAXIMUM_THREADS", "OPENBLAS_NUM_THREADS"):
        _os.environ[var] = str(rep["intra_op"])
    rep.update({"disponibles": disp, "origen": "adaptativo" if n_cores is None else "explícito",
                "puerta": "preimport"})
    print(f"[LTUS · CPU] env fijado: {rep['intra_op']} hilos BLAS de {n} núcleos "
          f"({rep['origen']}; disponibles={disp})", flush=True)
    return rep


def configurar_cpu(n_cores: Optional[int] = None, reserva: int = 0, pump: bool = True,
                   verbose: bool = True, estricto: bool = True) -> Dict:
    """Puerta 2: en caliente. Aplica intra-op de PyTorch + nuestros hilos.
    n_cores=None ⇒ ADAPTATIVO: usa todos los disponibles menos `reserva`.
    n_cores=X    ⇒ FIJO en X. Si X > disponibles: aborta (sin recortes silenciosos, A-3)."""
    disp = nucleos_disponibles()
    if n_cores is None:
        n = max(1, disp - int(reserva))
        origen = "adaptativo"
    else:
        n = int(n_cores)
        if n < 1:
            raise ValueError(f"[LTUS · CPU] n_cores={n} ilegal: mínimo 1")
        if n > disp:
            if estricto:
                raise ValueError(
                    f"[LTUS · CPU] pediste {n} núcleos pero sólo hay {disp} usables "
                    f"(afinidad/cuota cgroup). No se recorta en silencio: baja el número, "
                    f"revisa la cuota del contenedor, o pide estricto=False para recortar "
                    f"avisando.")
            print(f"[LTUS · CPU] AVISO: pediste {n}, hay {disp} usables → se recorta a {disp} "
                  f"(estricto=False). El run NO es comparable con otro que sí tuviera {n}.", flush=True)
            n = disp
            origen = "explícito_recortado"
        else:
            origen = "explícito"
    rep = reparto_cpu(n, pump=pump)
    aplicado = {"intra_op": False}
    if "torch" in globals() and hasattr(torch, "set_num_threads"):
        try:
            torch.set_num_threads(rep["intra_op"])
            if hasattr(torch, "set_num_interleave_threads"):
                torch.set_num_interleave_threads(1)
            aplicado["intra_op"] = True
        except Exception as e:                      # nunca tumbar el entrenamiento por esto
            aplicado["error"] = f"{e.__class__.__name__}: {e}"
    rep.update({"disponibles": disp, "origen": origen, "aplicado": aplicado,
                "puerta": "caliente"})
    if aplicado["intra_op"]:
        rep["torch_num_threads"] = torch.get_num_threads()
    if verbose:
        print(f"[LTUS · CPU] {n}/{disp} núcleos ({origen}) → principal={rep['principal']} "
              f"datos={rep['datos']} intra_op={rep['intra_op']}"
              f"{' (torch aplicado)' if aplicado['intra_op'] else ''}", flush=True)
        if origen == "adaptativo":
            print("[LTUS · CPU] aviso: modo adaptativo = puede variar entre máquinas y entre "
                  "corridas. Para un run reproducible en Kaggle, fija V4X_LTUS_CPU_CORES=X.", flush=True)
    return rep


def configurar_cpu_desde_entorno() -> Dict:
    """Atajo para la celda: obedece V4X_LTUS_CPU_CORES si está definido; si no, adaptativo."""
    crudo = _os.environ.get("V4X_LTUS_CPU_CORES", "").strip()
    reserva = int(_os.environ.get("V4X_LTUS_CPU_RESERVA", "0") or 0)
    estricto = _os.environ.get("V4X_LTUS_CPU_ESTRICTO", "1") != "0"
    return configurar_cpu(None if crudo == "" else int(crudo), reserva=reserva, estricto=estricto)


# ═══ §13 · [PEPS-D · CAMBIOS 256] CARRUSEL DETERMINISTA DE ESPECIALISTAS ═══
# Decreto del usuario (acta 256): en SFT **no hay router**. La tanda entrena UN especialista
# s con ancla forzada (`_forced_slot = s`), y el router está congelado por el Decreto 57 para
# evitar colapso secuencial. Por tanto el orden de carga NO se predice: se **impone**
# (1, 2, 3, … 177). Una lista no falla: tasa de acierto 100 % por construcción, cero `miss`,
# cero lectura de basura. La precarga deja de ser especulación y pasa a ser PARTITURA.
#
# G1 (guardia de Argon, verificada): la unidad NO es "las 23 capas MoE". Cada familia vive en
#    su rango real — Nemotron sólo en capas MoE; Qwen en 18..47; Phi en 18..39 — y el censo de
#    capas/claves se toma DEL INDEX, no de una tabla escrita a mano (A-3).
# G2 (verificada): 144,5 M params es UNA CAPA de Phi (3 matrices H×17920×H). El slot completo
#    son sus 22 capas ⇒ ~3,18 B params. Por eso Phi se parte en sub-tandas.
# G3 (verificada): con `scoring="softmax"` (default de config) y `_forced_slot=s` (+1e4), los
#    otros 5 expertos del top-k reciben peso 0.0 exacto ⇒ se pueden cortocircuitar... SALVO en
#    capas donde `s` no existe (tránsito) y salvo Phi fuera de `<|V4X_think|>` (E-05). El plan
#    por eso declara las capas de cada etapa y la cohorte base que debe seguir residente.

FAMILIA_NEMOTRON, FAMILIA_QWEN, FAMILIA_PHI = "nemotron", "qwen", "phi"

CFG_TAMANOS_DEFECTO = {"H": 2688, "I_nemotron": 1856, "I_qwen": 768, "I_phi": 17920,
                       "n_layers": 52, "capas_qwen": list(range(18, 48)),
                       "capas_phi": list(range(18, 40)), "slot_phi": 177,
                       "slot_base_nuevos": 129}

_RE_EXPERT_KEY = re.compile(r"^backbone\.layers\.(\d+)\.V4X\.experts\.(\d+)\.([A-Za-z_]+)\.weight$")


def familia_de_slot(slot: int, cfg: Optional[Dict] = None) -> str:
    c = dict(CFG_TAMANOS_DEFECTO, **(cfg or {}))
    if slot == c["slot_phi"]:
        return FAMILIA_PHI
    if slot >= c["slot_base_nuevos"]:
        return FAMILIA_QWEN
    return FAMILIA_NEMOTRON


def censo_especialistas(index_json_path: str) -> Dict[int, Dict]:
    """Censo REAL desde el index del checkpoint: para cada slot, qué capas lo contienen y
    cuántas matrices tiene en cada una (Nemotron=2: up+down; Qwen/Phi=3: gate+up+down;
    Phi parcial=1: sólo down). Nada de tablas a mano (A-3)."""
    with open(index_json_path, "r", encoding="utf-8") as f:
        wm = json.load(f)["weight_map"]
    censo: Dict[int, Dict] = {}
    for k in wm:
        m = _RE_EXPERT_KEY.match(k)
        if not m:
            continue
        capa, slot, proj = int(m.group(1)), int(m.group(2)), m.group(3)
        d = censo.setdefault(slot, {"capas": {}, "claves": 0})
        d["capas"].setdefault(capa, set()).add(proj)
        d["claves"] += 1
    for slot, d in censo.items():
        d["capas"] = {c: sorted(p) for c, p in sorted(d["capas"].items())}
    return censo


def _intermedio_de_slot(slot: int, cfg: Dict) -> int:
    fam = familia_de_slot(slot, cfg)
    return cfg["I_phi"] if fam == FAMILIA_PHI else (cfg["I_qwen"] if fam == FAMILIA_QWEN
                                                    else cfg["I_nemotron"])


def tamano_slot(censo_slot: Dict, slot: int, cfg: Optional[Dict] = None) -> Dict:
    """Params y MiB REALES de un slot, contando las matrices que de verdad existen en el index.
    Estado del optimizador fp32 = 12 B/param (master 4 + m 4 + v 4) — anexo 244-B.1 A-1."""
    c = dict(CFG_TAMANOS_DEFECTO, **(cfg or {}))
    I = _intermedio_de_slot(slot, c)
    params = 0
    for capa, projs in censo_slot["capas"].items():
        params += len(projs) * c["H"] * I          # cada matriz es H×I o I×H
    return {"slot": slot, "familia": familia_de_slot(slot, c), "capas": sorted(censo_slot["capas"]),
            "n_capas": len(censo_slot["capas"]), "params": params,
            "fp16_mib": params * 2 / 2**20, "estado_fp32_mib": params * 12 / 2**20}


def carrusel_plan(index_json_path: str, cfg: Optional[Dict] = None,
                  orden: Optional[Sequence[int]] = None,
                  max_capas_por_etapa: Optional[int] = None,
                  out_json: Optional[str] = None) -> Dict:
    """Construye la LISTA sellada del carrusel. `orden` = secuencia de slots; None ⇒ 1..177.
    Si un especialista supera `max_capas_por_etapa` (caso Phi), se parte en sub-tandas
    conservando el orden de capas (177/sub_0..2). El plan se sella con sha256 (DF-04)."""
    c = dict(CFG_TAMANOS_DEFECTO, **(cfg or {}))
    censo = censo_especialistas(index_json_path)
    orden = list(orden) if orden is not None else sorted(censo)
    etapas, faltan = [], []
    for s in orden:
        if s not in censo:
            faltan.append(s)                      # no se inventa: se declara
            continue
        t = tamano_slot(censo[s], s, c)
        capas = t["capas"]
        if max_capas_por_etapa and len(capas) > max_capas_por_etapa:
            trozos = [capas[i:i + max_capas_por_etapa] for i in range(0, len(capas), max_capas_por_etapa)]
            for j, tr in enumerate(trozos):
                frac = len(tr) / len(capas)
                etapas.append({"slot": s, "sub": j, "nombre": f"{s}/sub_{j}", "familia": t["familia"],
                               "capas": tr, "n_capas": len(tr),
                               "fp16_mib": t["fp16_mib"] * frac,
                               "estado_fp32_mib": t["estado_fp32_mib"] * frac})
        else:
            etapas.append({"slot": s, "sub": None, "nombre": str(s), "familia": t["familia"],
                           "capas": capas, "n_capas": t["n_capas"],
                           "fp16_mib": t["fp16_mib"], "estado_fp32_mib": t["estado_fp32_mib"]})
    plan = {"ltus_isa_version": LTUS_ISA_VERSION, "tipo": "carrusel_pepsd",
            "orden": orden, "faltan_en_index": faltan,
            "n_etapas": len(etapas), "etapas": etapas,
            "resumen_mib": {"fp16_total": sum(e["fp16_mib"] for e in etapas),
                            "max_etapa_fp16": max((e["fp16_mib"] for e in etapas), default=0.0),
                            "max_etapa_estado_fp32": max((e["estado_fp32_mib"] for e in etapas), default=0.0)},
            "cfg": c}
    sellar_partitura_sha256(plan)
    if out_json:
        with open(out_json, "w", encoding="utf-8") as f:
            json.dump(plan, f, indent=1, ensure_ascii=False)
    return plan


def presupuesto_ram(etapa: Dict, target: str = LTUS_TARGET_DEFECTO,
                    swap_mib: Optional[float] = None, base_host_mib: float = 0.0,
                    margen_minimo_mib: float = 512.0) -> Dict:
    """[CURA-17] El presupuesto de anoche sólo miraba VRAM. En LEUS el que mata es el HOST:
    sin swap, pasarse de RAM no ralentiza, CORTA el proceso. Aquí se declara explícitamente
    cuánta RAM y cuánto swap hay, y se decide ANTES de cargar nada.
    `swap_mib=None` ⇒ usa el declarado en el perfil (0.0 en LEUS hasta que active zram)."""
    perfil = perfil_medido(target)          # [CURA-17b] manda la medición, no la constante
    ram = perfil.get("ram_mib")
    if ram is None or ram <= 0:
        return {"target": target, "aplica": False, "motivo": "host sin RAM medible"}
    sw = perfil.get("swap_mib", 0.0) if swap_mib is None else float(swap_mib)
    reserva = perfil.get("reserva_so_mib", 3072.0)
    aviso = None
    if reserva >= ram * 0.5:      # reserva absurda para la máquina: se recorta y se avisa
        nueva = ram * 0.25
        aviso = (f"reserva_so_mib={reserva:.0f} ≥ 50% de la RAM medida ({ram:.0f} MiB): "
                 f"se recorta a {nueva:.0f}. Perfil pensado para otra máquina.")
        reserva = nueva
    disp = ram - reserva + sw - base_host_mib
    nec = etapa["fp16_mib"] + etapa["estado_fp32_mib"]
    margen = disp - nec
    if margen >= margen_minimo_mib:
        pol = "cabe_en_ram"
    elif margen >= 0:
        pol = "al_limite"                # cabe pero sin colchón: un pico de SO lo tumba
    elif margen + sw >= 0 and sw > 0:
        pol = "cabe_sobre_swap"          # cabe, pero paginando: lento, no roto
    else:
        pol = "no_cabe"
    rep = {"target": target, "etapa": etapa.get("nombre"), "ram_mib": round(ram, 0),
           "swap_mib": round(sw, 0), "reserva_so_mib": round(reserva, 0),
           "disponible_mib": round(disp, 0), "necesita_mib": round(nec, 0),
           "margen_mib": round(margen, 0), "margen_minimo_mib": margen_minimo_mib,
           "politica": pol, "aviso": aviso,
           "capas_sugeridas": (etapa.get("n_capas") if pol == "cabe_en_ram" else
                               max(1, int(etapa.get("n_capas", 1) * disp / nec)) if nec else None)}
    if pol == "no_cabe":
        rep["accion"] = ("reducir capas por sub-tanda, activar swap/zram, o cambiar de perfil")
    return rep


def presupuesto_carrusel(plan: Dict, target: str = LTUS_TARGET_DEFECTO,
                         base_residente_mib: Optional[float] = None,
                         reserva_mib: float = 512.0) -> Dict:
    """¿Cabe el doble buffer en VRAM? Política por etapa:
       - 'doble_vram'      : S_actual + S_siguiente caben en VRAM (Qwen/Nemo en T4)
       - 'vram_mas_ram'    : sólo S_actual en VRAM; S_siguiente staged en RAM pinned (Phi, LEUS)
       - 'micro_rangos'    : ni S_actual cabe ⇒ partir más (LEUS con Phi)
    Contabilidad explícita: base residente (tronco+bancos) + etapa + siguiente + reserva."""
    perfil = perfil_de_destino(target)
    cap = perfil["cap_mib"]
    if base_residente_mib is None:                 # cada perfil declara su propia base
        base_residente_mib = perfil["base_mib"]
    margen = cap - base_residente_mib - reserva_mib
    filas, peor = [], None
    for e in plan["etapas"]:
        a, b = e["fp16_mib"], e["fp16_mib"]
        if a + b <= margen:
            pol = "doble_vram"
        elif a <= margen:
            pol = "vram_mas_ram"
        else:
            pol = "micro_rangos"
        fila = {"nombre": e["nombre"], "familia": e["familia"], "fp16_mib": round(a, 1),
                "politica": pol, "vram_pico_mib": round(min(a + (b if pol == "doble_vram" else 0), a), 1),
                "ram_staging_mib": round(0.0 if pol == "doble_vram" else b, 1),
                "ram_estado_fp32_mib": round(e["estado_fp32_mib"], 1),
                "cabe": pol != "micro_rangos"}
        filas.append(fila)
        if peor is None or a > peor["fp16_mib"]:
            peor = fila
    rep = {"target": target, "cap_mib": cap, "base_residente_mib": base_residente_mib,
           "reserva_mib": reserva_mib, "margen_etapa_mib": round(margen, 1),
           "etapa_mas_cara": peor["nombre"] if peor else None,
           "politicas": {p: sum(1 for f in filas if f["politica"] == p)
                         for p in ("doble_vram", "vram_mas_ram", "micro_rangos")},
           "todo_cabe": all(f["cabe"] for f in filas), "etapas": filas}
    # [CURA-17] segunda dimensión: ¿cabe en RAM/swap del host? Se informan SEPARADAS:
    # un "no cabe" de VRAM y uno de RAM se arreglan de forma distinta (sub-tanda vs target).
    ram_filas = [presupuesto_ram(e, target) for e in plan["etapas"]]
    rep["ram"] = {"swap_declarado_mib": ram_filas[0].get("swap_mib") if ram_filas else None,
                  "no_caben_en_ram": [r["etapa"] for r in ram_filas if r.get("politica") == "no_cabe"],
                  "al_limite": [r["etapa"] for r in ram_filas if r.get("politica") == "al_limite"],
                  "sobre_swap": [r["etapa"] for r in ram_filas if r.get("politica") == "cabe_sobre_swap"]}
    rep["todo_cabe_vram"] = all(f["cabe"] for f in filas)
    rep["todo_cabe_ram"] = not rep["ram"]["no_caben_en_ram"]
    rep["todo_cabe"] = rep["todo_cabe_vram"] and rep["todo_cabe_ram"]
    print(json.dumps({k: rep[k] for k in ("target", "margen_etapa_mib", "etapa_mas_cara",
                                          "politicas", "todo_cabe_vram", "todo_cabe_ram")},
                     ensure_ascii=False), flush=True)
    return rep


class CarruselPEPSD:
    """Máquina de estados del carrusel. No toca tensores: gobierna QUÉ etapa está en VRAM y
    CUÁL está staged. Invariantes verificadas en cada `swap()`:
       I1  la etapa activa nunca se descarga antes de que la siguiente esté lista
       I2  `siguiente` y `actual` son etapas distintas (o None)
       I3  el índice avanza exactamente 1 (no salta: no es una predicción)
       I4  `lookahead` (de §11) decide cuántas etapas se preparan por delante en RAM
    """

    def __init__(self, plan: Dict, target: str = LTUS_TARGET_DEFECTO, lookahead: int = 1):
        self.plan = plan
        self.target = target
        self.etapas = plan["etapas"]
        self.lookahead = max(1, int(lookahead))
        self.i = 0
        self.actual = None
        self.siguiente = None
        self.registro: List[Dict] = []
        self._cargar(0)

    def _etapa(self, k: int) -> Optional[Dict]:
        return self.etapas[k] if 0 <= k < len(self.etapas) else None

    def _cargar(self, k: int) -> None:
        self.actual = self._etapa(k)
        self.siguiente = self._etapa(k + 1)
        self.registro.append({"evento": "carga", "indice": k,
                              "actual": self.actual["nombre"] if self.actual else None,
                              "siguiente": self.siguiente["nombre"] if self.siguiente else None,
                              "prefetch_ram": [e["nombre"] for e in self._ventana(k)]})

    def _ventana(self, k: int) -> List[Dict]:
        return [e for e in (self._etapa(k + j) for j in range(2, 2 + self.lookahead)) if e]

    def swap(self) -> Dict:
        """Cierre de tanda: intercambia y lanza la precarga de la siguiente ventana."""
        if self.actual is None:
            raise RuntimeError("[PEPS-D] swap sin etapa activa")
        if self.siguiente is not None and self.siguiente is self.actual:
            raise RuntimeError("[PEPS-D] I2 violada: actual == siguiente")
        k_prev = self.i
        self.i += 1
        if self.i != k_prev + 1:
            raise RuntimeError("[PEPS-D] I3 violada: el índice no avanzó 1")
        self._cargar(self.i)
        reg = {"evento": "swap", "de": k_prev, "a": self.i,
               "actual": self.actual["nombre"] if self.actual else None,
               "siguiente": self.siguiente["nombre"] if self.siguiente else None}
        self.registro.append(reg)
        return reg

    def agotado(self) -> bool:
        return self.actual is None

    def estado(self) -> Dict:
        return {"target": self.target, "indice": self.i, "n_etapas": len(self.etapas),
                "actual": self.actual["nombre"] if self.actual else None,
                "siguiente": self.siguiente["nombre"] if self.siguiente else None,
                "lookahead_ram": self.lookahead, "agotado": self.agotado(),
                "eventos": len(self.registro)}


def exp_carrusel_1(t_carga_s: float, t_tanda_s: float,
                   umbral_gratis: float = 0.05, umbral_micro: float = 0.20) -> Dict:
    """EXP-CARRUSEL-1: ¿se traga el carrusel la tanda? Mide t_carga/t_tanda y decide."""
    frac = t_carga_s / t_tanda_s if t_tanda_s > 0 else float("inf")
    if frac <= umbral_gratis:
        veredicto, accion = "GRATIS", "carrusel directo: la carga se esconde bajo el cierre de tanda"
    elif frac <= umbral_micro:
        veredicto, accion = "SOLAPAR", "doble buffer obligatorio: S_siguiente en RAM mientras entrena S_actual"
    else:
        veredicto, accion = "MICRO_RANGOS", "partir la etapa: el especialista no cabe en una tanda"
    rep = {"t_carga_s": round(t_carga_s, 3), "t_tanda_s": round(t_tanda_s, 3),
           "fraccion": round(frac, 4), "veredicto": veredicto, "accion": accion}
    print(json.dumps(rep, ensure_ascii=False), flush=True)
    return rep


def verificar_tape_estructural(tape: list) -> Dict:
    """CURA-14 como gate permanente: TODA micro-op debe ser un callable sin argumentos.
    Se ejecuta sin GPU sobre el tape ya construido; si algo devolvió None en construcción,
    esto lo caza antes de Kaggle (el crash original fue `TypeError: 'NoneType' not callable`)."""
    import inspect
    malas = []
    for i, (stream, waits, fn, recs) in enumerate(tape):
        if not callable(fn):
            malas.append({"indice": i, "tipo": type(fn).__name__})
            continue
        try:
            # bind() sin argumentos: los defaults (p.ej. `lambda ll=l: ...`) NO cuentan como
            # obligatorios. Con co_argcount daban falso positivo (52 falsas alarmas medidas).
            inspect.signature(fn).bind()
        except TypeError as e:
            malas.append({"indice": i, "motivo": f"no invocable sin argumentos: {e}"})
    rep = {"n_micro_ops": len(tape), "no_invocables": len(malas), "detalle": malas[:10]}
    if malas:
        raise RuntimeError(f"[CURA-14 GATE] tape roto: {rep}")
    return rep


def arnes_pepsd_en_seco(plan: Dict, target: str = LTUS_TARGET_DEFECTO,
                        lookahead: int = 2, etapas_a_recorrer: int = 3) -> Dict:
    """Arnés en seco: recorre el carrusel sin GPU y verifica I1-I4 + que no se pierde ninguna
    etapa ni se repite. Sirve de test de humo del gobierno antes de tocar Kaggle."""
    ctl = CarruselPEPSD(plan, target=target, lookahead=lookahead)
    vistos = []
    for _ in range(min(etapas_a_recorrer, len(plan["etapas"]))):
        if ctl.actual is not None:
            vistos.append(ctl.actual["nombre"])
        ctl.swap()
    swaps = [r for r in ctl.registro if r["evento"] == "swap"]
    avance = all(swaps[j]["a"] == swaps[j - 1]["a"] + 1 for j in range(1, len(swaps)))
    rep = {"target": target, "lookahead": lookahead, "recorridas": vistos,
           "unicas": len(set(vistos)) == len(vistos), "avance_1x1": avance,
           "estado_final": ctl.estado()}
    print(json.dumps({k: rep[k] for k in ("target", "recorridas", "unicas", "avance_1x1")},
                     ensure_ascii=False), flush=True)
    assert rep["unicas"] and rep["avance_1x1"], "[PEPS-D] invariantes violadas"
    return rep


# ═══ §14 · [CURA-17b, CAMBIOS 257] SONDA DE HOST: medir, no suponer, y en cualquier SO ═══
# El perfil LEUS se escribió con números de UNA máquina concreta (Arch, sin swap). El usuario
# tiene dual boot y en Windows obtiene MÁS RAM física útil + paginación de fábrica: el perfil
# no puede llevar constantes de un SO. Todo lo que dependa del host se MIDE en tiempo de
# ejecución (Linux y Windows, sin dependencias externas), y el perfil sólo declara reservas.
def _ram_linux() -> Dict:
    d = {}
    try:
        with open("/proc/meminfo", encoding="utf-8") as f:
            for ln in f:
                k, _, v = ln.partition(":")
                d[k.strip()] = int(v.split()[0]) / 1024.0        # kB -> MiB
    except OSError:
        return {}
    total = d.get("MemTotal", 0.0)
    disp = d.get("MemAvailable", d.get("MemFree", 0.0))
    swap_total = d.get("SwapTotal", 0.0)
    swap_free = d.get("SwapFree", 0.0)
    return {"ram_total_mib": total, "ram_disponible_mib": disp,
            "swap_total_mib": swap_total, "swap_libre_mib": swap_free,
            "swap_tipo": "zram/swapfile" if swap_total > 0 else "NINGUNO"}


def _ram_windows() -> Dict:
    try:
        import ctypes
        class MEMORYSTATUSEX(ctypes.Structure):
            _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                        ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                        ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                        ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                        ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]
        st = MEMORYSTATUSEX()
        st.dwLength = ctypes.sizeof(MEMORYSTATUSEX)
        if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(st)):
            return {}
        mib = 1024.0 * 1024.0
        total = st.ullTotalPhys / mib
        # el pagefile incluye la RAM física: el desbordamiento puro es la diferencia
        pagefile = st.ullTotalPageFile / mib
        return {"ram_total_mib": total, "ram_disponible_mib": st.ullAvailPhys / mib,
                "swap_total_mib": max(0.0, pagefile - total),
                "swap_libre_mib": max(0.0, (st.ullAvailPageFile - st.ullAvailPhys) / mib),
                "swap_tipo": "paginacion_windows"}
    except Exception:
        return {}


def sonda_host() -> Dict:
    """Lo que de verdad hay en la máquina, sin creerse al perfil. Windows y Linux.
    `ram_util_mib` = RAM disponible + desbordamiento (swap/paginación) menos reserva de SO."""
    import platform
    so = platform.system()
    d = _ram_windows() if so == "Windows" else _ram_linux()
    if not d:
        d = {"ram_total_mib": 0.0, "ram_disponible_mib": 0.0, "swap_total_mib": 0.0,
             "swap_libre_mib": 0.0, "swap_tipo": "desconocido"}
    try:
        hilos = len(_os.sched_getaffinity(0))
    except (AttributeError, OSError):
        hilos = _os.cpu_count() or 1
    d.update({"so": so, "hilos": hilos,
              "desbordamiento": d["swap_total_mib"] > 0,
              "nota": ("sin swap/paginación: pasarse de RAM MATA el proceso"
                       if d["swap_total_mib"] <= 0 else
                       "hay desbordamiento: pasarse de RAM pagina (lento, no letal)")})
    return d


def perfil_medido(target: str = LTUS_TARGET_DEFECTO) -> Dict:
    """Perfil declarado + medición real del host. La medida MANDA sobre la constante."""
    p = perfil_de_destino(target)
    h = sonda_host()
    p["host_medido"] = h
    if h["ram_total_mib"] > 0:
        p["ram_mib"] = h["ram_total_mib"]                 # la constante del perfil se sustituye
    if h["swap_total_mib"] > 0:
        p["swap_mib"] = h["swap_total_mib"]               # zram, swapfile o paginación de Windows
    if h["hilos"]:
        p["hilos_cpu"] = h["hilos"]
    return p


# ═══ §9 · SMOKE PLUMBING (documental; Kaggle ejecuta) ═══
SMOKE_DOC = """\
Secuencia smoke LTUS-0 en Kaggle (tras GATE-0 verde):
  1) verificar_anti_casper_244(paths_map)
  2) plan = compilar_plan_ltus0(tanda, n_layers=52, layer_bytes_streamed=[...], manifest, out)
  3) marcar trainable_set (requires_grad=True en params objetivo o apply_lora(...))
  4) arena = LTUSAutopistaArena(model, fgl=..., n_micros=8, T=8192)
  5) tape, ev = construir_tape_step(arena, labels_gpu, bwd_profile=tanda['bwd_profile'])
  6) rep = ejecutar_partitura_autopista(arena, tape, ev)   # gates 1/2/5 aquí
  7) commit = ltus_commit_step(arena, lr=...)               # EF-02 post-step
  8) route_census(...) una vez por tanda (EXP-H4, bloquea dimensionado de láminas)
PENDIENTES EXPLÍCITOS (no olvidar): O-2 (despacho congelado zero-sync, OFF por defecto,
requiere ROUTE_CENSUS + cura E-05), megablocks/punica post-O-2 (exploratorio),
AF-03 CUDA Graphs opcional solo si EXP-H1 no llega a 93%.
"""
# ═══ §10 · [LTUS, CAMBIOS 252] INFORME DE ESTADO PARA ARGON (autogenerado) ═══
_LEDGER_CURAS = [
    ("CURA-1",  "228", "hook frontera P3 mueve TODOS los tensores de kwargs", "SUPERADA por CURA-13"),
    ("CURA-4",  "235", "sane_kernels_o_fuera: sondas de import + píldora de veneno", "VIVA"),
    ("CURA-5",  "235", "autolocalizador acel_BF16_TURING (no vive en rutas sembradas)", "VIVA"),
    ("CURA-7",  "244", "cargador bizonal: whitelist backbone./lm_head., resto None", "VIVA"),
    ("CURA-8",  "246", "E-02 por CENSO, no literal ==23 (A-3)", "VIVA"),
    ("CURA-8b", "246", "anti-zombi: rompe sys.last_traceback + gc + empty_cache", "VIVA"),
    ("CURA-9",  "247", "adapter V4X ausente del ckpt nace determinista (SEED+424247, bf16, dev0)", "VIVA"),
    ("CURA-10", "248", "fail-fast de kernel sucio: mide VRAM al entrar (<12 GiB ⇒ aborta)", "VIVA"),
    ("CURA-11", "249", "shim de símbolos privados de modeling (_flag_hyp3, _v4x_*)", "VIVA"),
    ("CURA-12", "250", "smoke seq 256 (paridad, no longitud) + electrocardiograma por GPU", "VIVA"),
    ("CURA-13", "251", "escolta permanente post-frontera + ce_chunk definido (fantasma)", "VIVA"),
]


def informe_para_argon() -> str:
    """Imprime el bloque de estado que se pega en el mega-prompt a Argon.
    Autogenerado desde la tabla canónica y el ledger: si el papel y el código
    divergen, gana el código (decreto A-1)."""
    L = []
    L.append("=== LTUS · ESTADO DEL SOFTWARE (autogenerado, acta 252) ===")
    L.append(f"isa_version = {LTUS_ISA_VERSION}")
    L.append("canónicos (md5 literal, prohibido recitar):")
    for k, v in CANONICAL_MD5_244.items():
        L.append(f"  {k:32s} {v}")
    L.append("LAUS = LTUS ∪ LEUS (Language Accelerator Unit Software) — la familia; "
             "no compila, sólo agrupa:")
    for _c, _i in LAUS["componentes"].items():
        L.append(f"  {_c:5s} {_i['rol']:58s} destinos={_i['targets']}")
    L.append("perfiles de destino:")
    for nombre, p in LTUS_TARGETS.items():
        L.append(f"  {nombre:7s} {p['hw']:42s} cap={p['cap_mib']:.0f}MiB x{p['n_gpus']} "
                 f"T_max={p['T_max']} modo={p['modo']}")
    L.append("ledger de curas (celda GATE-0):")
    for c, acta, que, estado in _LEDGER_CURAS:
        L.append(f"  {c:9s} acta {acta}  {que}  [{estado}]")
    L.append(f"CPU: adaptativo por defecto · fijable con V4X_LTUS_CPU_CORES=X "
             f"(disponibles aquí: {nucleos_disponibles()}, perfil Kaggle 2xT4={KAGGLE_VCPU_T4} vCPU)")
    L.append("superficie pública del motor:")
    for f in ("compilar_plan_ltus0(target=…) · validar_plan_contra_target · perfil_de_destino",
              "LTUSAutopistaArena · construir_tape_step · ejecutar_partitura_autopista · ltus_commit_step",
              "apply_lora(dora=) · ce_loss_chunked · DataPump · route_census",
              "tower_source_probe (N-1) · tower_budget_report (N-4)"):
        L.append(f"  {f}")
    L.append("pendientes que BLOQUEAN firma:")
    for p in ("O-2 despacho congelado zero-sync (OFF por defecto; exige ROUTE_CENSUS + E-05)",
              "E-05 is_f &= live (prerequisito de AF-05)",
              "N-3 flag _first_grad_layer fantasma en versión Argon",
              "N-5 toda cifra sin EXP-L2 va etiquetada PREVISTO-PAPEL(P)"):
        L.append(f"  {p}")
    return "\n".join(L)


if __name__ == "__main__":
    import sys as _sys
    if "--argon" in _sys.argv:
        print(informe_para_argon())
    elif "--sim-control" in _sys.argv:
        # ═══ banco en seco del controlador (sin GPU): 30 pasos de una T4 simulada ═══
        def _entorno(paso, K, lookahead, residente_mib):
            peak = 8600 + 180 * K + residente_mib
            busy = min(99.0, 55.0 + 9.0 * lookahead + 6.0 * (K ** 0.5))
            data_wait = max(0.0, 2.5 - 0.8 * lookahead)
            tok_s = 210.0 * K / (1 + 0.06 * (K - 1)) * min(1.0, 0.75 + 0.10 * lookahead)
            return peak, busy, data_wait, tok_s

        ctl = ControladorLTUS(cap_mib=14500.0, margen_mib=512.0, dwell=3)
        residente, oom = 0.0, False
        print(f"{'paso':>4} {'estado':>8} {'K':>3} {'look':>4} {'peak':>6} {'tok/s':>7}  acción")
        for paso in range(1, 31):
            peak, busy, dw, tok = _entorno(paso, ctl.K, ctl.lookahead, residente)
            if peak > 13988.0:                    # el rail decide: OOM real
                oom, tok = True, 0.0
            a = ctl.observa(paso, peak, free_mib=14500.0 - peak, tok_s=tok,
                            busy_pct=busy, data_wait_ms=dw, oom=oom)
            oom = False
            print(f"{paso:>4} {ctl.estado:>8} {ctl.K:>3} {ctl.lookahead:>4} {peak:>6.0f} {tok:>7.1f}  "
                  f"{a['accion'] if a else '—'} {('· ' + a['motivo']) if a else ''}")
            if paso == 12:
                residente = 900.0                 # entra una torre residente: debe reaccionar
                print("      [evento] torre residente +900 MiB")
        print(f"\n[régimen final] {ctl.firma_regimen()} · acciones={ctl.acciones} · "
              f"regímenes medidos={len(ctl.regimenes)}")
        base = {"ltus_isa_version": LTUS_ISA_VERSION, "tanda": {"T": 8192}, "schedule": []}
        print(f"[linaje] {len(ctl.linaje(base))} planes sellados, uno por régimen")
    else:
        print(SMOKE_DOC)
