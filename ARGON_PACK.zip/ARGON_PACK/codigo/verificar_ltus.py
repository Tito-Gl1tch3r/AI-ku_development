#!/usr/bin/env python3
# ═════════════════════════════════════════════════════════════════════════════
# verificar_ltus.py — ARNÉS AUTÓNOMO DEL MOTOR (CAMBIOS 257)
#
# Corre SIN PyTorch, SIN GPU y SIN Kaggle: sólo Python 3 de serie.
#   python3 verificar_ltus.py            # todas las pruebas
#   python3 verificar_ltus.py --rapido   # sin las de carrusel largo
#
# Para qué sirve: valida la LÓGICA del motor (curas del tape, censo, presupuesto,
# carrusel, gates) en cualquier máquina. Lo que NO prueba: nada que necesite CUDA
# real (tok/s, VRAM, transferencias) — eso sigue necesitando Kaggle o LEUS con GPU.
#
# Si torch está instalado, usa el de verdad; si no, inyecta un doble mínimo que
# reproduce la interfaz que el motor consume. Cero red, cero descargas.
# ═════════════════════════════════════════════════════════════════════════════
import sys, os, json, hashlib, tempfile, importlib

AQUI = os.path.dirname(os.path.abspath(__file__))
if AQUI not in sys.path:
    sys.path.insert(0, AQUI)

VERDE, ROJO, AMAR, GRIS, FIN = "\033[32m", "\033[31m", "\033[33m", "\033[90m", "\033[0m"
if not sys.stdout.isatty() or os.environ.get("NO_COLOR"):
    VERDE = ROJO = AMAR = GRIS = FIN = ""

_resultados = []


def check(nombre, fn, critico=True):
    """Ejecuta una prueba; registra PASS/FAIL y sigue (no aborta la batería)."""
    try:
        detalle = fn()
        _resultados.append((nombre, True, critico, detalle))
        print(f"  {VERDE}✓{FIN} {nombre}" + (f" {GRIS}· {detalle}{FIN}" if detalle else ""))
    except Exception as e:
        _resultados.append((nombre, False, critico, f"{e.__class__.__name__}: {e}"))
        marca = f"{ROJO}✗{FIN}" if critico else f"{AMAR}!{FIN}"
        print(f"  {marca} {nombre} {GRIS}· {e.__class__.__name__}: {e}{FIN}")


# ─────────────────────────────────────────────────────────────────────────────
# 1 · DOBLE DE TORCH (sólo si no hay torch de verdad)
# ─────────────────────────────────────────────────────────────────────────────
def _instalar_doble_torch():
    import types

    class T:
        def __init__(self, shape=(1,), req=False):
            self.shape, self.requires_grad, self.grad = shape, req, None

        def __getattr__(self, n):
            return lambda *a, **k: T()

        def __getitem__(self, k):
            return T()

        def unsqueeze(self, *a): return T()
        def squeeze(self, *a): return T()
        def view(self, *a): return T()
        def half(self): return T()
        def float(self): return T()
        def detach(self): return T()
        def numel(self): return 8
        def copy_(self, o, **k): return self
        def zero_(self): return self
        def add_(self, o, **k): return self
        def requires_grad_(self, b=True): self.requires_grad = b; return self
        def backward(self, g=None): pass

    class Evt:
        def __init__(self, *a, **k): pass
        def record(self, *a, **k): return self
        def synchronize(self): pass

    class Ctx:
        def __enter__(self): return self
        def __exit__(self, *a): return False

    class Stream:
        def __init__(self, *a, **k): pass
        def wait_event(self, *a): pass

    torch = types.ModuleType("torch")
    torch.Tensor = T
    torch.empty_like = lambda x, **k: T()
    torch.arange = lambda *a, **k: T()
    torch.no_grad = lambda: Ctx()
    torch.autocast = lambda *a, **k: Ctx()
    torch.float16, torch.float32, torch.long = "fp16", "fp32", "long"

    cuda = types.ModuleType("torch.cuda")
    cuda.Event, cuda.Stream = Evt, Stream
    cuda.stream = lambda s: Ctx()
    cuda.synchronize = lambda *a, **k: None
    cuda.memory_allocated = lambda *a: 0
    cuda.memory_reserved = lambda *a: 0
    cuda.mem_get_info = lambda *a: (1 << 30, 1 << 30)
    cuda.is_available = lambda: False
    cuda.device_count = lambda: 1
    torch.cuda = cuda

    nn = types.ModuleType("torch.nn")

    class Module:
        def __init__(self, *a, **k): pass
        def __getattr__(self, n): return T()

    nn.Module, nn.Parameter, nn.ModuleList = Module, (lambda *a, **k: T(req=True)), list
    nn.Linear = type("Linear", (Module,), {})
    torch.nn = nn

    fn = types.ModuleType("torch.nn.functional")
    fn.cross_entropy = lambda *a, **k: (T(), 0)
    torch.nn.functional = fn

    ag = types.ModuleType("torch.autograd")

    class Function:
        @staticmethod
        def apply(*a, **k): return (T(), 8)

    ag.Function = Function
    torch.autograd = ag

    ut = types.ModuleType("torch.utils")
    ckp = types.ModuleType("torch.utils.checkpoint")
    ckp.checkpoint = lambda f, *a, **k: f(*a)
    ut.checkpoint = ckp
    torch.utils = ut

    for n, m in (("torch", torch), ("torch.cuda", cuda), ("torch.nn", nn),
                 ("torch.nn.functional", fn), ("torch.autograd", ag),
                 ("torch.utils", ut), ("torch.utils.checkpoint", ckp)):
        sys.modules[n] = m


def cargar_motor():
    try:
        import torch  # noqa: F401
        real = True
    except ImportError:
        _instalar_doble_torch()
        real = False
    import ltus0_autopista as L
    return L, real


# ─────────────────────────────────────────────────────────────────────────────
# 2 · INDEX SINTÉTICO con la geometría real del modelo (52 capas, 23 MoE)
# ─────────────────────────────────────────────────────────────────────────────
def index_sintetico(ruta):
    moe = sorted(list(range(0, 11)) + list(range(40, 52)))          # 23 capas MoE
    wm = {}
    for l in range(52):
        wm[f"backbone.layers.{l}.mixer.gate.weight"] = "shard.safetensors"
    for l in moe:
        for s in range(1, 129):
            for p in ("up_proj", "down_proj"):                      # NemotronHMLP: 2 matrices
                wm[f"backbone.layers.{l}.V4X.experts.{s}.{p}.weight"] = "shard.safetensors"
    for l in range(18, 48):                                         # Qwen: 30 capas
        for s in range(129, 177):
            for p in ("gate_proj", "up_proj", "down_proj"):         # V4XNewExpert: 3 matrices
                wm[f"backbone.layers.{l}.V4X.experts.{s}.{p}.weight"] = "shard.safetensors"
    for l in range(18, 40):                                         # Phi: 22 capas
        for p in ("gate_proj", "up_proj", "down_proj"):
            wm[f"backbone.layers.{l}.V4X.experts.177.{p}.weight"] = "shard.safetensors"
    with open(ruta, "w", encoding="utf-8") as f:
        json.dump({"weight_map": wm}, f)
    return ruta


class ArenaFalsa:
    """Geometría suficiente para construir el tape sin GPU."""

    def __init__(self, T_, L_):
        import types
        st = types.SimpleNamespace
        self.n_layers, self.K, self.fgl, self.T, self.H = L_, 2, 2, T_, 2688
        self.dev, self.grad_slice_elems = "cuda:0", 1024
        def _stream():
            return st(wait_event=lambda *a: None, __enter__=lambda s: s,
                      __exit__=lambda *a: False)
        self.s_comp, self.s_h2d, self.s_d2h = _stream(), _stream(), _stream()   # distintos de verdad
        self.layers = [lambda x, **k: __import__("torch").Tensor() for _ in range(L_)]
        self.acts_ab = [[__import__("torch").Tensor() for _ in range(2)] for _ in range(2)]
        self.pin_borders = [[__import__("torch").Tensor() for _ in range(2)] for _ in range(L_)]
        self.pin_slabs = [__import__("torch").Tensor() for _ in range(L_)]
        self.vram_buf_ab = [__import__("torch").Tensor(), __import__("torch").Tensor()]
        self.recomp_in = [__import__("torch").Tensor() for _ in range(2)]
        self.vram_metrics = self.pin_metrics = __import__("torch").Tensor()
        self.stream_index = [[("w", 0, 8)] for _ in range(L_)]
        self.pin_grads, self.trainable_flat_names = {}, ["backbone.layers.5.x::backbone.layers.5.x"]
        self.model = st(**{})
        self.model.backbone = st(norm_f=lambda x: __import__("torch").Tensor())
        self.model.lm_head = st(weight=__import__("torch").Tensor())

    def _param_by_fullname(self, n):
        return __import__("torch").Tensor(req=True)


# ─────────────────────────────────────────────────────────────────────────────
# 3 · BATERÍA
# ─────────────────────────────────────────────────────────────────────────────
def main():
    rapido = "--rapido" in sys.argv
    print(f"\n{'═'*72}\n  VERIFICACIÓN AUTÓNOMA DEL MOTOR LTUS (sin GPU)\n{'═'*72}")

    L, torch_real = cargar_motor()
    print(f"\n{GRIS}torch: {'REAL' if torch_real else 'doble en seco (sin PyTorch instalado)'}{FIN}")
    print(f"{GRIS}ISA: {L.LTUS_ISA_VERSION} · fichero: ltus0_autopista.py{FIN}")

    # ── A · integridad y familia ──
    print(f"\n{AMAR}A · Integridad y familia{FIN}")

    def a1():
        assert L.LTUS_ISA_VERSION.startswith("1.4-CASA"), L.LTUS_ISA_VERSION
        r = L.LAUS_TARGETS_CONCRETOS
        assert set(r) == set(L.LTUS_TARGETS), f"familia y destinos divergen: {r}"
        return f"LAUS = LTUS ∪ LEUS · destinos {r}"
    check("LAUS es familia y no destino; coerción de tabla", a1)

    def a2():
        try:
            L.perfil_de_destino("LAUS")
        except KeyError as e:
            return "el paraguas aborta con error pedagógico"
        raise AssertionError("¡LAUS compiló como destino!")
    check("pedir target='LAUS' aborta", a2)

    def a3():
        h = L.sonda_host()
        p = L.perfil_medido("LEUS")
        assert p["ram_mib"] == h["ram_total_mib"] or h["ram_total_mib"] == 0
        return (f"{h['so']} · RAM {h['ram_total_mib']:.0f} MiB · "
                f"desbordamiento {h['swap_total_mib']:.0f} MiB · {h['hilos']} hilos")
    check("sonda de host multiplataforma", a3, critico=False)

    # ── B · CURA-14/15: el tape ──
    print(f"\n{AMAR}B · Tape (CURA-14 y CURA-15){FIN}")

    def b1():
        arena = ArenaFalsa(64, 52)
        tape, ev = L.construir_tape_step(arena, [None, None])
        r = L.verificar_tape_estructural(tape)
        return f"{r['n_micro_ops']} micro-ops, {r['no_invocables']} no invocables"
    check("toda micro-op del tape es invocable (era el crash None())", b1)

    def b2():
        arena = ArenaFalsa(64, 52)
        _, ev2 = L.construir_tape_step(arena, [None], lookahead=5)
        assert ev2["lookahead"] == 5
        return "la perilla de §11 tiene consumidor (lookahead=5)"
    check("lookahead conectado al tape", b2)

    def b3():
        arena = ArenaFalsa(64, 52)
        tape, _ = L.construir_tape_step(arena, [None])
        n_h2d = sum(1 for s, _, _, _ in tape if s is arena.s_h2d)
        assert n_h2d > 0
        return f"{n_h2d} micro-ops en el stream H2D"
    check("pipeline H2D poblado", b3)

    # ── C · censo y tamaños reales ──
    print(f"\n{AMAR}C · Censo y tamaños por familia{FIN}")
    tmp = tempfile.mkdtemp(prefix="ltus_")
    idx = index_sintetico(os.path.join(tmp, "index.json"))
    censo = L.censo_especialistas(idx)

    def c1():
        assert len(censo) == 177, f"slots censados: {len(censo)}"
        t1 = L.tamano_slot(censo[1], 1)
        t129 = L.tamano_slot(censo[129], 129)
        t177 = L.tamano_slot(censo[177], 177)
        assert (t1["n_capas"], t129["n_capas"], t177["n_capas"]) == (23, 30, 22)
        assert abs(t1["fp16_mib"] - 437.7) < 1 and abs(t129["fp16_mib"] - 354.4) < 1
        assert abs(t177["fp16_mib"] - 6063.8) < 2
        return (f"177 slots · Nemo 23c/{t1['fp16_mib']:.0f}MiB · Qwen 30c/{t129['fp16_mib']:.0f}MiB"
                f" · Phi 22c/{t177['fp16_mib']:.0f}MiB")
    check("censo del index y tamaños (Nemo 2 matrices, Qwen/Phi 3)", c1)

    # ── D · carrusel §13 ──
    print(f"\n{AMAR}D · Carrusel determinista §13{FIN}")

    def d1():
        p = L.carrusel_plan(idx, max_capas_por_etapa=4)
        assert p["n_etapas"] > 177
        assert p["faltan_en_index"] == []
        return f"{p['n_etapas']} etapas con sub-tandas ≤4 capas · sha {p['plan_sha256'][:12]}"
    check("plan sellado con sub-tandas", d1)

    plan4 = L.carrusel_plan(idx, max_capas_por_etapa=4)

    def d2():
        r = L.arnes_pepsd_en_seco(plan4, target="LTUS-1", lookahead=2,
                                  etapas_a_recorrer=4 if rapido else 6)
        assert r["unicas"] and r["avance_1x1"]
        return f"avance 1×1 verificado · {r['recorridas']}"
    check("invariantes del carrusel (I1-I4)", d2)

    def d3():
        salida = []
        for tg in L.LAUS_TARGETS_CONCRETOS:
            r = L.presupuesto_carrusel(plan4, target=tg)
            salida.append(f"{tg} vram={'OK' if r['todo_cabe_vram'] else 'NO'}"
                          f"/ram={'OK' if r['todo_cabe_ram'] else 'NO'}")
        h = L.sonda_host()
        return (" · ".join(salida) +
                f"  {GRIS}(RAM medida en ESTE host: {h['ram_total_mib']:.0f} MiB)")
    check("presupuesto por destino", d3, critico=False)

    # ── E · gate de RAM (§14) ──
    print(f"\n{AMAR}E · Gate de RAM por host{FIN}")

    def e1():
        t177 = L.tamano_slot(censo[177], 177)
        escenarios = {
            "Arch sin swap (14,96 GiB)": dict(ram_total_mib=15319.0, swap_total_mib=0.0),
            "Arch + zram 4 GiB": dict(ram_total_mib=15319.0, swap_total_mib=4096.0),
            "Windows 16 GiB + paginación": dict(ram_total_mib=16384.0, swap_total_mib=16384.0),
        }
        lineas, resumen = [], {}
        for nombre, h in escenarios.items():
            L.sonda_host = lambda h=h: {"ram_total_mib": h["ram_total_mib"],
                                        "ram_disponible_mib": h["ram_total_mib"] * 0.6,
                                        "swap_total_mib": h["swap_total_mib"],
                                        "swap_libre_mib": h["swap_total_mib"],
                                        "swap_tipo": "simulado", "so": nombre,
                                        "hilos": 12,
                                        "desbordamiento": h["swap_total_mib"] > 0}
            pols = []
            for n in (4, 6, 8):
                e = {"nombre": f"{n}c", "n_capas": n,
                     "fp16_mib": t177["fp16_mib"] * n / 22,
                     "estado_fp32_mib": t177["estado_fp32_mib"] * n / 22}
                pols.append(L.presupuesto_ram(e, "LEUS")["politica"])
            resumen[nombre] = pols
            lineas.append(f"{nombre}: 4→{pols[0]} 6→{pols[1]} 8→{pols[2]}")
        assert resumen["Arch sin swap (14,96 GiB)"][2] == "no_cabe", resumen
        assert resumen["Windows 16 GiB + paginación"][2] == "cabe_en_ram", resumen
        return " | ".join(lineas)
    check("misma etapa: Arch sin swap vs Windows con paginación", e1)

    # ── F · experimento ──
    print(f"\n{AMAR}F · Decisión medida{FIN}")

    def f1():
        return " · ".join(L.exp_carrusel_1(c, t)["veredicto"]
                          for c, t in ((0.4, 20.0), (2.0, 20.0), (9.0, 20.0)))
    check("EXP-CARRUSEL-1 clasifica (gratis/solapar/micro-rangos)", f1)

    # ── G · anti-regresión: el shift causal (CURA-18) ──
    print(f"\n{AMAR}G · Anti-regresión del CE (CURA-18){FIN}")

    def g1():
        import inspect
        src = inspect.getsource(L._CEChunkFn.forward)
        assert "h = h[:-1]" in src and "labels = labels[1:]" in src, \
            "sin shift causal: el modelo aprendería la identidad"
        bwd = inspect.getsource(L._CEChunkFn.backward)
        assert "F.pad(grad_h" in bwd, "el backward no restituye la forma [T,H]"
        return "h[:-1] vs labels[1:] en forward y pad en backward"
    check("el CE del motor desplaza la predicción (entrena t -> t+1)", g1)

    def g2():
        ruta = os.path.join(AQUI, "celda_GATE0_IFA_BIZONAL.py")
        if not os.path.isfile(ruta):
            return "celda no presente en este árbol (se omite)"
        src = open(ruta, encoding="utf-8").read()
        assert "h[..., :-1, :]" in src and "y[..., 1:]" in src, \
            "ce_chunk de la celda sin shift causal"
        return "ce_chunk de la celda GATE-0 también desplaza"
    check("la celda GATE-0 usa el mismo shift", g2, critico=False)

    # ── resumen ──
    ok = sum(1 for _, v, _, _ in _resultados if v)
    crit_fail = [n for n, v, c, _ in _resultados if not v and c]
    print(f"\n{'═'*72}")
    print(f"  {ok}/{len(_resultados)} pruebas OK")
    if crit_fail:
        print(f"  {ROJO}FALLOS CRÍTICOS:{FIN} {', '.join(crit_fail)}")
    else:
        print(f"  {VERDE}sin fallos críticos{FIN}")
    print(f"{GRIS}  Lo que esto NO prueba: tok/s, VRAM real, PCIe ni transferencias.")
    print(f"  Eso exige GPU (Kaggle o LEUS) y PyTorch real.{FIN}")
    print(f"{'═'*72}\n")
    return 1 if crit_fail else 0


if __name__ == "__main__":
    sys.exit(main())
