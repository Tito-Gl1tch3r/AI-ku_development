# MINI-CELDA AUDIT-MANIF v8 — 177 NEMO-UNIFORM + APOYO-39 + GUARDIA-MIKU · CPU
# Qué es: el v7 PERFeccionado (CAMBIOS 175):
#   (i)   FIX cyber élite (guardia nq==0 lo colababa) — slots qwen-cyber existen
#         de nuevo (152..158).
#   (ii)  FIX routing prog "reverse_engineering/understand/train/..." los
#         tragaba "understand" (iteraba subs en orden literal): ahora matchea
#         el segmento MÁS PROFUNDO del path (min) — reverse/game/media/ops
#         ya van a SU sub, no a comprension/understand por accidente.
#   (iii) NEW NEMO-UNIFORM (por defecto): los 128 nemo se REPARTEN TODO el
#         corpus por familia (proporcional a su masa) — no quedan "expertos
#         que no aparecen". Mode "chunks" = el clásico ≤55M/slot (queda si hay
#         más corpus que slots).
#   (iv)  NEW APOYO-39 (por defecto): slot 39 dedidado a "experto de expertos":
#         muestra estratificada de TODAS las familias (cuota proporcional a su
#         masa ~55M) + TUTORÍA COMPLETA de brainstorm (le hereda de phi, no
#         los duplicamos, ambos la ven, hermandad simulateudes) + MIKU.
#         Si el usuario decide leer el corpus ENTERO en él (MANIF_39_STATE=full)
#         la celda escribe el coste en horas ANTES de aceptarlo.
#   (v)   GUARDIA-MIKU: el fichero que el usuario pegó pesa 2,4 KB. Si en disco
#         está el grande (516.905 tok, probablemente el JSON.inflado) y MANIF_
#         MIKU_MAX (def 50.000) lo supera → paredu en su tanda SOLO (no en
#         todas) y advierte; MANIF_MIKU_MAX=0 desactiva la guardia.
# ─────────────────────────────────────────────────────────────────────────────
import os, re, sys, json, glob, collections

ROOT = os.environ.get("MANIF_ROOT", "/kaggle/input/datasets/gl1tch3r/ai-ku-dataset")
OUT  = os.environ.get("MANIF_OUT",  os.path.join(os.path.expanduser("~"),
                                   "manifiesto_ESPECIALISTAS_v8.json"))  # %USERPROFILE%
DRY  = os.environ.get("MANIF_DRY",  "0") == "1"
SAMPLE_MCHARS = float(os.environ.get("MANIF_SAMPLE_MCHARS", "2"))
TARGET_NEMO = int(os.environ.get("MANIF_TARGET_NEMO", "55000000"))
NEMO_MODE = os.environ.get("MANIF_NEMO_MODE", "uniform")   # uniform | chunks
APOYO_39 = os.environ.get("MANIF_39_STATE", "mix")         # mix | full | off
TARGET_39   = int(os.environ.get("MANIF_TARGET_39", "20000000"))
APOYO_SIN_ORO = os.environ.get("MANIF_39_SIN_ORO", "1") == "1"  # oro ya ×3 élite
PHI_MODO = os.environ.get("MANIF_PHI_MODO", "169")  # "169"=c/cyber | "mes1"=solo razonar (CAMBIOS 186)
QWEN_PUENTE = float(os.environ.get("MANIF_QWEN_PUENTE", "0.15"))  # llave-4, 0.15=puente
GIGANTES_QWEN = {"context", "conversation", "lenguaje", "long_context", "audit", "cyber_cyber_gen"}
MIKU_MAX   = int(os.environ.get("MANIF_MIKU_MAX", "50000"))  # 0 = sin guardia
MIKU = os.path.join("00 - Miku", "Miku.json")
OVERRIDES_PATH = os.environ.get("MANIF_OV", "slot_overrides.json")

print(f"[v8r3] ROOT={os.path.abspath(ROOT)}")
print(f"[v8r3] OUT ={os.path.abspath(OUT)}  modo={NEMO_MODE} apoyo39={APOYO_39} target_nemo={TARGET_NEMO:,}")
if not os.path.isdir(ROOT):
    print(f"[v8r3] !! MANIF_ROOT NO EXISTE: {ROOT}  (¿te faltaron los $env: de PowerShell?)")

try: sys.stdout.reconfigure(encoding="utf-8")
except Exception: pass

EXCL_DIR = {"docs","quality","schemas","scripts","build","validation","eval","research"}
EXCL_NOM = re.compile(r"(?i)(license|readme|requirements|changelog|citation|"
                      r"contribu|dataset_card|schema|shards\.json|stats|"
                      r"validation_report|answer_key|benchmark|audit_results|"
                      r"sha256|build_stats)")

FIRMAS_GLOBAL = {
    "conversacion":  ["hola", "entendido", "de acuerdo", "gracias"],
    "mates":         ["integral", "derivada", "algebra", "ecuacion", "ecuación",
                      "teorema", "matrix"],
    "ciencia":       ["hipotesis", "hipótesis", "experimento", "molecula", "molécula",
                      "cientifico", "investigacion"],
    "fisica":        ["newton", "energia", "energía", "termodinamica", "cuantica",
                      "cuántica", "relatividad", "ondas"],
    "quimica":       ["quimica", "química", "reaccion", "reacción", "catalizador",
                      "atomo", "oxido"],
    "biologia":      ["celula", "célula", "genetica", "evolucion", "proteina", "adn"],
    "programacion":  ["def ", "import ", "print(", "class ", "function", "=>{",
                      "const ", "return", "#include"],
    "agentico":      ["tool_call", "<|tool|>", "action:", "observation:", "plan:"],
    "tool_call":     ["tool_calls", "\"arguments\":", "function_call", "tool_call_id"],
    "multiapi":      ["openai", "anthropic", "claude", "gpt-", "completions.create",
                      "api_key"],
    "computer_use":  ["click(", "screenshot", "pyautogui", "ui-action", "coordenadas",
                   "keydown", "double_click", "moveto", "typewrite", "osworld", "gui-agent"],
    "lenguaje":      ["language", "idioma", "translation", "traduccion",
                      "francais", "italiano", "deutsch", "portugues", "日本語"],
    "events":        ["actualidad", "noticias", "news", "2026"],
    "research":      ["paper", "arxiv", "doi", "referencias", "citado en"],
    "razonar":       ["<|V4X_think|>", "paso 1:", "razonemos", "porque", "entonces"],
    "auditoria":     ["auditar", "revisar", "validar", "verificar", "hallazgo"],
    "frontier":      ["frontera", "vanguardia", "fable", "frontier"],
    "brainstorm":    ["brainstorm", "lluvia de ideas", "idear", "alternativas"],
    "osint":         ["osint", "recon", "footprint", "shodan", "censys"],
    "opsec":         ["opsec", "tradecraft", "atribucion"],
    "exploit":       ["exploit", "0day", "pwn", "rop chain", "shellcode",
                      "buffer overflow", "cwe-"],
    "bugbounty":     ["bug bounty", "bugbounty", "hackerone", "bugcrowd"],
    "adversarv":     ["adversary", "apt", "kill chain", "ttp", "att&ck", "backdoor"],
    "c2":            ["cobalt strike", "sliver", "beacon", "listener", "stager"],
    "ctf":           ["ctf", "capture the flag", "hackthebox", "tryhackme", "writeup"],
    "forense":       ["forense", "dfir", "yara", "memory analysis"],
    "oro":           ["fable", "cursor", "traza agéntica"],
}
CYBER_DEF = {"adversary-emulation":"adversarv", "adversary-simulation":"adversarv",
             "binary-exploitation":"exploit", "bugbounty":"bugbounty",
             "c2":"c2", "command-and-control":"c2", "ctf":"ctf"}

def excluye(rel):
    rel_n = rel.replace("\\", "/"); nom = os.path.basename(rel)
    if any(p in EXCL_DIR for p in rel_n.split("/")[:-1]): return True
    if EXCL_NOM.search(nom) or nom == "tree.txt": return True
    if "_quarantine" in rel_n: return True
    if "hard_holdout" in rel_n: return "holdout"
    if re.search(r"(?:^|/)test(?:/|$)|(?:-|_)(?:adversarial_)?test\.|(?:-|_)validation\.",
                 rel_n, re.I): return "holdout"   # <-- fuga GPT-hallada → a eval
    return os.path.splitext(nom)[1].lower() not in (".parquet", ".jsonl", ".json", ".gz")

def _chars_de_valor(v, depth=0):
    if v is None: return ""
    if isinstance(v, str): return v
    if depth > 3: return ""
    return json.dumps(v, ensure_ascii=False)

def muestrea_texto(path, max_chars):
    ext = os.path.splitext(path)[1].lower()
    if ext == ".parquet":
        try:
            import pyarrow.parquet as pq
        except ImportError:
            return "", max(1, os.path.getsize(path) // 3), None
        pf = pq.ParquetFile(path)
        nrows = pf.metadata.num_rows
        cols = list(range(len(pf.schema_arrow.names)))
        bufs, n, cap_len, chars_med = [], 0, 0, 0
        try:
            batches = pf.iter_batches(batch_size=128, columns=cols)
        except Exception:
            return "", max(1, os.path.getsize(path) // 3), None
        for batch in batches:
            for col in batch.columns:
                for v in col.to_pylist():
                    s = _chars_de_valor(v)
                    if not s: continue
                    chars_med += len(s)              # medir LONGITUD REAL
                    if cap_len < max_chars:          # clasificar con truncado ok
                        b = s[:2000]; cap_len += len(b); bufs.append(b)
            n += batch.num_rows
            if chars_med >= max_chars: break
        txt = " ".join(bufs)
        chars_est = int(chars_med / max(1, n) * nrows) if n else 0
        return txt[:max_chars], max(chars_est, os.path.getsize(path) // 3), nrows
    if ext in (".jsonl", ".json"):
        try:
            size = os.path.getsize(path)
            with open(path, "r", encoding="utf-8", errors="ignore") as fh:
                txt = fh.read(max_chars)
            leido = len(txt.encode("utf-8", errors="ignore"))
            completo = leido >= min(max_chars, size)
            full = size if completo else (size * max_chars // max(len(txt), 1))
            return txt, full, None
        except Exception:
            return "", os.path.getsize(path), None
    if ext == ".gz":
        return "", max(1, os.path.getsize(path) // 2), None
    return "", os.path.getsize(path), None

def tok_est(path):
    _, chars_est, _ = muestrea_texto(path, int(SAMPLE_MCHARS * 1e6))
    return max(1, chars_est // 4)

DISTINTAS = {"agentico", "tool_call", "multiapi", "computer_use", "osint", "opsec",
             "exploit", "bugbounty", "adversarv", "c2", "ctf", "forense", "brainstorm",
             "oro", "frontier", "biologia"}
def clasifica(txt_low):
    scores = {k: sum(txt_low.count(c) for c in cl) for k, cl in FIRMAS_GLOBAL.items()}
    return {k for k, v in scores.items() if v >= (1 if k in DISTINTAS else 2)}

FAM = [
 ("miku", ["00 - Miku"], ["conversacion"], dict(lr=1e-5, T=8192)),
 ("qwen_codigo", ["01 - Qwen"], ["programacion", "multiapi"], dict(lr=1e-5, T=8192)),
 ("context", ["02 - Context"], ["conversacion", "research"], dict(lr=1e-5, T=8192)),
 ("conversation", ["02 - Conversation"], ["conversacion"], dict(lr=1e-5, T=8192)),
 ("lenguaje", ["02 - Lenguaje"], ["lenguaje", "conversacion"], dict(lr=1e-5, T=8192)),
 ("long_context", ["02 - Long_Context"], ["conversacion", "research"], dict(lr=1e-5, T=8192)),
 ("deep_research", ["02.5 - Deep_Research"], ["research"], dict(lr=8e-6, T=8192)),
 ("events", ["02.5 - Events"], ["events"], dict(lr=1e-5, T=8192)),
 ("computer_use", ["02.5.5 - Computer_Use"], ["computer_use", "agentico", "multiapi"], dict(lr=1e-5, T=4096)),
 ("multiapi", ["02.5.5 - MultiAPI"], ["multiapi", "agentico"], dict(lr=1e-5, T=4096)),
 ("agentic", ["03 - Agentic"], ["agentico"], dict(lr=1e-5, T=4096)),
 ("tool_calling", ["03 - Tool_Calling"], ["tool_call", "agentico"], dict(lr=1e-5, T=4096)),
 ("oro_1", ["04 - Oro"], ["oro"], dict(lr=3e-6, T=8192)),
 ("prog_core", ["05 - Programming"], ["programacion", "agentico", "tool_call"], dict(lr=1e-5, T=4096)),
 ("maths", ["07 - Maths"], ["mates", "ciencia", "fisica", "quimica"], dict(lr=7e-6, T=8192)),
 ("audit", ["08 - Audit"], ["auditoria", "programacion"], dict(lr=1e-5, T=8192)),
 ("frontier", ["09 - Frontier-Intelligence"], ["frontier", "research"], dict(lr=5e-6, T=8192)),
 ("oro_2", ["10 - Oro"], ["oro"], dict(lr=3e-6, T=8192)),
 ("cyber", ["11 - Cibersecurity"], None, dict(lr=8e-6, T=4096)),
 ("brainstorm", ["12 - Brainstorming"], ["brainstorm", "razonar"], dict(lr=1e-5, T=8192)),
 ("cot", ["12 - COT"], ["razonar"], dict(lr=1e-5, T=8192)),
 ("oro_3", ["13 - Oro"], ["oro"], dict(lr=3e-6, T=8192)),
]
PROG_SUBS = ["understand", "write", "reverse_engineering", "game_engineering",
             "media", "agent_ops", "comprension"]
CYBER_SLOTS_ORD = ["osint", "opsec", "exploit", "bugbounty", "adversarv", "c2",
                   "ctf", "forense", "cyber_gen"]

# ─── 1) lectura única (familia → fams-ck unificado) ──────────────────────────
famck = []                     # (label, files, cats, receta)
phi_lineas = {"sub_0": [], "sub_1": [], "sub_2": []}
cyber_lineas_phi = []
eval_solo = []
_prog_pool = collections.defaultdict(list)
_cyber_pool = collections.defaultdict(list)
fam_meta = {}                 # label → receta

for fam, carpetas, sugeridas, receta in FAM:
    pool = []
    for carp in carpetas:
        cdir = os.path.join(ROOT, carp)
        if not os.path.isdir(cdir): continue
        for path in sorted(glob.glob(os.path.join(cdir, "**", "*"), recursive=True)):
            if not os.path.isfile(path): continue
            rel = os.path.relpath(path, ROOT).replace(os.sep, "/")
            ex = excluye(rel)
            if ex == "holdout":
                eval_solo.append({"fichero": rel, "tokens": tok_est(path)}); continue
            if ex: continue
            tok = tok_est(path)
            muestra, _, _ = muestrea_texto(path, int(SAMPLE_MCHARS * 1e6))
            cats = clasifica(muestra.lower())
            if fam == "miku": cats.add("miku")
            pool.append({"fichero": rel, "offset": 0, "tokens": tok,
                         "cats": sorted(cats),
                         "fam_tag": "miku" if fam == "miku" else (sugeridas[0] if sugeridas else fam)})
    fam_meta[fam] = receta
    if fam == "prog_core":
        for f in pool:
            low = f["fichero"].replace("\\", "/").lower()
            encontr = [(low.find("/" + nom + "/"), nom) for nom in PROG_SUBS[:-1]
                       if "/" + nom + "/" in low]
            piece = min(encontr)[1] if encontr else "comprension"
            _prog_pool[piece].append(f)
        famck.append(("__PROG__", [], set(), receta))
        continue
    if fam == "cyber":
        for f in pool:
            esp = None
            low = f["fichero"].lower()
            for nom, e in CYBER_DEF.items():
                if nom + "/" in low: esp = e; break
            if esp is None:
                dentro = set(f["cats"]) & set(CYBER_SLOTS_ORD)
                esp = (sorted(dentro)[0] if dentro else "cyber_gen")
            f["fam_tag"] = esp
            _cyber_pool[esp].append(f)
        cyber_lineas_phi.extend(pool)
        famck.append(("__CYBER__", [], set(), receta))
        continue
    if fam == "cot":
        mitad = max(1, len(pool) // 2)
        phi_lineas["sub_0"].extend(pool[:mitad]); phi_lineas["sub_1"].extend(pool[mitad:])
        continue
    if fam == "brainstorm":
        phi_lineas["sub_2"].extend(pool)
        continue
    famck.append((fam, pool, set().union(*(f["cats"] for f in pool)) if pool else set(),
                  receta))

# explotar staticmarkers en familias reales (prog por sub, cyber por especialidad)
famck2 = []
for lab, pool, cats, rec in famck:
    if lab == "__PROG__":
        for nom in PROG_SUBS:
            ps = _prog_pool.get(nom, [])
            if ps:
                famck2.append((f"prog_{nom}", ps,
                               set().union(*(f["cats"] for f in ps)),
                               fam_meta["prog_core"]))
    elif lab == "__CYBER__":
        for esp in CYBER_SLOTS_ORD:
            cs = _cyber_pool.get(esp, [])
            if cs:
                famck2.append((f"cyber_{esp}", cs,
                               set().union(*(f["cats"] for f in cs)) | {esp, "cyber"},
                               fam_meta["cyber"]))
    else:
        famck2.append((lab, pool, cats, rec))
famck = famck2

def mix_estratificado(cupo_total, desfase=0, excluir_fams=()):
    """Muestra proporcional de TODAS las familias hasta ~cupo_total tokens."""
    activas = [(lab, pool, c, r) for lab, pool, c, r in famck
               if pool and lab not in excluir_fams]
    tot_c = sum(f["tokens"] for _, pool, _, _ in activas for f in pool)
    out = []
    for lab, pool, cats, rec in activas:
        if not pool or tot_c == 0: continue
        t_fam = sum(f["tokens"] for f in pool)
        cuota = int(cupo_total * t_fam / tot_c)
        avg = max(1, t_fam // len(pool))
        n_sel = max(1, cuota // avg)
        stride = max(1, len(pool) // n_sel)
        camina, grupo = 0, []
        for i, f in enumerate(pool):
            if (i + desfase) % stride != 0: continue
            if camina + f["tokens"] <= cuota or not grupo:
                grupo.append(f); camina += f["tokens"]
            if camina >= cuota: break
        if not grupo:                                # atomicidad: 1 ficheoro mínimo
            peq = min(pool, key=lambda f: f["tokens"])
            grupo.append(peq)
            if peq["tokens"] > cuota:
                print(f"    [mix] ojo: {lab} min-fichero {peq['tokens']:,} > cuota {cuota:,} (fichero no divisible)")
        out.extend(grupo)
    return out

# (2.0) refuerzo computer_use (decreto "más agresivo el escaneo")
CU_REFUERZO = int(os.environ.get("MANIF_CU_REFUERZO", "20000000"))  # 0 = off
if CU_REFUERZO > 0:
    for i, (lab, pool, cats, rec) in enumerate(famck):
        if lab != "computer_use": continue
        ya = {f["fichero"] for f in pool}
        extra, acc = [], 0
        for lab2, pool2, _c, _r in famck:
            if lab2 == lab: continue
            for f in pool2:
                if f["fichero"] in ya: continue
                if "computer_use" not in f["cats"]: continue
                extra.append(f); acc += f["tokens"]; ya.add(f["fichero"])
                if acc >= CU_REFUERZO: break
            if acc >= CU_REFUERZO: break
        if extra:
            famck[i] = (lab, pool + extra, cats | {"computer_use"}, rec)
            print(f"[cu-refuerzo] +{acc:,} tok ({len(extra)} ficheros) cosechados de otros slots → N-computer_use")

# ─── 2) slots + manifiesto base ──────────────────────────────────────────────
manif = {"version": "v8r9-b+phi-modo-" + PHI_MODO, "raiz": ROOT,
         "tandas": {}, "cobertura": {}, "eval_solo": eval_solo,
         "categorias_por_slot": {}, "categorias_indice": {}, "dormant": []}
cat_por_slot = collections.defaultdict(set)
def anota(s, cats):
    if cats: cat_por_slot[str(s)] |= set(cats)

mp = os.path.join(ROOT, MIKU)
miku_real_tokens = tok_est(mp) if os.path.isfile(mp) else 0
miku_lines = [{"fichero": MIKU.replace(os.sep, "/"), "offset": 0,
               "tokens": miku_real_tokens, "cats": ["miku", "conversacion"],
               "fam_tag": "miku"}] if os.path.isfile(mp) else []
miku_guard = bool(MIKU_MAX) and miku_real_tokens > MIKU_MAX and len(miku_lines) == 1
def mete_miku(lins):
    if not miku_lines: return lins
    if miku_guard:                      # guardia: MIKU inflado → NO ir en todas
        return lins
    return lins + miku_lines

if miku_guard:
    print(f"[GUARDIA-MIKU] {MIKU} = {miku_real_tokens:,} tok > MANIF_MIKU_MAX={MIKU_MAX:,} "
          f"→ va SOLO en su tanda persona (no en todas). Decreto retenido, posible overwrite.")

# 2.1) slot 39 generalista ("experto de expertos")
apoyo39_lines = []
if APOYO_39 != "off":
    tot_c = sum(f["tokens"] for _, pool, _, _ in famck for f in pool)
    cupo_obj = tot_c if APOYO_39 == "full" else TARGET_39
    excl = ("oro_1", "oro_2", "oro_3") if (APOYO_39 == "mix" and APOYO_SIN_ORO) else ()
    apoyo39_lines.extend(mix_estratificado(cupo_obj, excluir_fams=excl))
    apoyo39_lines.extend(phi_lineas["sub_2"])          # brainstorm al completo
    if APOYO_39 == "mix":
        def _trim_a_target(lines, target):
            def total(lns): return sum(l["tokens"] for l in lns)
            from collections import defaultdict as dd
            while True:
                exceso = total(lines) - target
                if exceso <= 0: break
                # familias con >1 fichero
                por_fam = dd(list)
                for i, l in enumerate(lines):
                    por_fam[l.get("fam_tag", "?")].append(i)
                # la que más contribuye al exceso = la que suma más por encima de su cuota
                mejor = None; mejor_ahorro = 0
                for fam, idxs in por_fam.items():
                    if len(idxs) <= 1: continue          # atomicidad: nunca 0
                    gordo = max(idxs, key=lambda i: lines[i]["tokens"])
                    ahorro = min(lines[gordo]["tokens"], exceso)
                    if ahorro > mejor_ahorro:
                        mejor, mejor_ahorro = gordo, ahorro
                if mejor is None:
                    if len(lines) <= 1: break
                    mejor = max(range(len(lines)), key=lambda i: lines[i]["tokens"])
                lines.pop(mejor)
            return lines
        apoyo39_lines[:] = _trim_a_target(apoyo39_lines, TARGET_39)
        print(f"[apoyo-39] modo MIX: {sum(l['tokens'] for l in apoyo39_lines):,} tok tras trim a target {TARGET_39:,}")
    else:
        tok_f = sum(l['tokens'] for l in apoyo39_lines)
        horas = tok_f / 48.7 / 3600.0
        print(f"[apoyo-39] modo FULL (usuario si lo fuerza): {tok_f:,} tok = ~{horas:,.0f} h @48,7t/s "
              f"(solo 39 · el resto del mes estaría parado)")

# 2.2) asignación nemo (uniform | chunks) con 39 reservada
def _chunks_balanced(files, n):
    tot = sum(f["tokens"] for f in files) or 1
    target = tot / n
    chunks, buf, acc = [], [], 0
    for f in files:
        if acc >= target and len(chunks) < n - 1:
            chunks.append(buf); buf, acc = [], 0
        buf.append(f); acc += f["tokens"]
    if buf: chunks.append(buf)
    while len(chunks) < n: chunks.append([])
    return chunks[:n]

def _chunks_55M(files, target):
    chunks, buf, acc = [], [], 0
    for f in files:
        buf.append(f); acc += f["tokens"]
        if acc >= target: chunks.append(buf); buf, acc = [], 0
    if buf: chunks.append(buf)
    return chunks

nemo_pool_pieces = []        # (label, chunk, cats, receta)
if NEMO_MODE == "uniform":
    family_list = [(lab, pool, cats, rec) for lab, pool, cats, rec in famck if pool]
    total_all = sum(f["tokens"] for _, pool, _, _ in family_list for f in pool)
    budget = 128 - (1 if APOYO_39 != "off" else 0)
    left = len(family_list)
    for i, (lab, pool, cats, rec) in enumerate(family_list):
        t_fam = sum(f["tokens"] for f in pool)
        max_n = budget - (left - 1)
        n = max(1, min(max_n, len(pool), round(budget * t_fam / max(1, total_all))))
        budget -= n; total_all -= t_fam; left -= 1
        for chunk in _chunks_balanced(pool, n):
            nemo_pool_pieces.append((lab, chunk, cats, rec))
else:
    for lab, pool, cats, rec in famck:
        for chunk in _chunks_55M(pool, TARGET_NEMO):
            nemo_pool_pieces.append((lab, chunk, cats, rec))

# asignar con salto del 39
slot_ptr = 0
def proximo_slot():
    global slot_ptr
    slot_ptr += 1
    if APOYO_39 != "off" and slot_ptr == 39:
        slot_ptr += 1          # el 39 queda para el apoyo
    return slot_ptr

# primero el apoyo (para que salga quizá por pantalla) - aunque el nombre lo decide el slot
if APOYO_39 != "off":
    lins_39 = mete_miku(apoyo39_lines)
    manif["tandas"]["39"] = {"lineas": lins_39, "nemo": True,
                             "target_tokens": TARGET_39,
                             "tokens_obj": sum(l["tokens"] for l in lins_39),
                             "lr": 8e-6, "T": 8192,
                             "familia": "apoyo_generalista",
                             "nota": "slot 39 = experto de expertos (mix+brainstorm+miku)"}
    manif["cobertura"]["39"] = {"tokens_obj": lins_39 and manif["tandas"]["39"]["tokens_obj"]}
    anota(39, {"apoyo", "razonar", "brainstorm", "miku"} |
          set().union(*(f["cats"] for f in apoyo39_lines)) |
          {f.get("fam_tag") for f in apoyo39_lines})

for lab, chunk, cats, rec in nemo_pool_pieces:
    if not chunk: continue
    cats = set().union(*(f["cats"] for f in chunk)) | {f.get("fam_tag") for f in chunk}
    s = proximo_slot()
    if s > 128: break
    lins_n = mete_miku(chunk)
    manif["tandas"][str(s)] = {"lineas": lins_n,
                               "tokens_obj": sum(l["tokens"] for l in lins_n),
                               **rec, "familia": lab, "nemo": True}
    manif["cobertura"][str(s)] = {"tokens_obj": manif["tandas"][str(s)]["tokens_obj"]}
    anota(s, cats)

# 2.3) qwen élite (igual que v7 pero sin guardia, cyber con slots)
slots_q_list = list(range(129, 177)); sidx = 0
fam_q = [("miku", 1), ("qwen_codigo", 1), ("context", 1), ("conversation", 1),
         ("lenguaje", 1), ("long_context", 1), ("deep_research", 1), ("events", 1),
         ("computer_use", 1), ("multiapi", 1), ("agentic", 1), ("tool_calling", 1),
         ("oro_1", 1), ("prog_understand", 1), ("prog_write", 1),
         ("prog_reverse_engineering", 1), ("prog_game_engineering", 1),
         ("prog_media", 1), ("prog_agent_ops", 1), ("prog_comprension", 1),
         ("maths", 1), ("audit", 1), ("frontier", 1), ("oro_2", 1),
         ("cyber_osint", 1), ("cyber_opsec", 1), ("cyber_exploit", 1),
         ("cyber_bugbounty", 1), ("cyber_adversarv", 1), ("cyber_c2", 1),
         ("cyber_ctf", 1), ("cyber_forense", 1), ("cyber_cyber_gen", 1),
         ("oro_3", 1)]
pool_by_lab = {lab: pool for lab, pool, _c, _r in famck}
for fam, nq in fam_q:
    if nq == 0: continue
    lins = pool_by_lab.get(fam, [])
    if not lins: continue
    if NEMO_MODE == "uniform" and fam in GIGANTES_QWEN and 0.0 < QWEN_PUENTE < 1.0:
        tot_fam = sum(f["tokens"] for f in lins)
        cupo_puente = max(1000000, int(tot_fam * QWEN_PUENTE))
        stride_p = max(1, int(round(1.0 / QWEN_PUENTE)))
        acc_p, lins_p = 0, []
        for idx_f, f in enumerate(lins):
            if idx_f % stride_p != 0: continue
            if lins_p and acc_p + f["tokens"] > cupo_puente: continue  # tope estricto
            lins_p.append(f); acc_p += f["tokens"]
        if not lins_p: lins_p = [min(lins, key=lambda x: x["tokens"])]
        lins = lins_p
        print(f"  [puente] {fam}: élite {tot_fam:,} → {acc_p:,} tok (K={QWEN_PUENTE})")
    stradem = fam.startswith("prog_") or fam.startswith("cyber_")
    s = slots_q_list[sidx]; sidx += 1
    lins_q = mete_miku(lins)
    manif["tandas"][str(s)] = {"lineas": lins_q,
                               "tokens_obj": sum(l["tokens"] for l in lins_q),
                               "lr": fam_meta["cyber"]['lr'] if fam.startswith("cyber_")
                                     else fam_meta["prog_core"]['lr'] if fam.startswith("prog_")
                                     else fam_meta.get(fam, dict(lr=1e-5, T=8192))["lr"],
                               "T": fam_meta["cyber"]['T'] if fam.startswith("cyber_")
                                    else fam_meta["prog_core"]['T'] if fam.startswith("prog_")
                                    else fam_meta.get(fam, dict(lr=1e-5, T=8192))["T"],
                               "familia": fam}
    manif["cobertura"][str(s)] = {"tokens_obj": manif["tandas"][str(s)]["tokens_obj"]}
    anota(s, (set().union(*(f["cats"] for f in lins)) |
              {f.get("fam_tag") for f in lins}) if lins else {fam})

# 2.3b) REFUERZO qwen dormants (162..176): mini-mix generalista para que los
#       177 expertos salgan TODOS con programa (decreto "entrenar a los 177").
QWEN_FILL_TOK = int(os.environ.get("MANIF_QWEN_FILL_TOK", "0"))  # 0 = off (mes 1: anillo-1)
if QWEN_FILL_TOK > 0 and sidx < len(slots_q_list):
    libres = slots_q_list[sidx:]
    for j, s in enumerate(libres):
        lins = mix_estratificado(QWEN_FILL_TOK, desfase=j)
        if not lins: break
        manif["tandas"][str(s)] = {"lineas": mete_miku(lins),
                                   "tokens_obj": sum(l["tokens"] for l in lins),
                                   "lr": 5e-6, "T": 8192,
                                   "familia": "refuerzo_generalista",
                                   "nota": "qwen dormant → mini-mix del corpus"}
        manif["cobertura"][str(s)] = {"tokens_obj": sum(l["tokens"] for l in lins)}
        anota(s, set().union(*(f["cats"] for f in lins)) |
              {f.get("fam_tag") for f in lins} | {"refuerzo"})
    print(f"[qwen-fill] {len(libres)} slots elite sobrantes → refuerzo ~{QWEN_FILL_TOK:,} tok c/u "
          f"(+{len(libres)*QWEN_FILL_TOK:,} tok-repaso = ~{len(libres)*QWEN_FILL_TOK/48.7/3600:,.0f} h @48,7t/s)")
    sidx = len(slots_q_list)

# 2.4) phi 177 — DECRETO 169 (cyber completa); CAMBIOS 186: modo mes1 aplaza cyber→mes-2
n_rt = len(cyber_lineas_phi); tercio = max(1, n_rt // 3)
if PHI_MODO != "mes1":
    phi_lineas["sub_0"].extend(cyber_lineas_phi[:tercio])
    phi_lineas["sub_1"].extend(cyber_lineas_phi[tercio:2 * tercio])
    phi_lineas["sub_2"].extend(cyber_lineas_phi[2 * tercio:])
else:
    print(f"[phi mes1] cyber aplazada a mes-2 (CAMBIOS 186): -{sum(l['tokens'] for l in cyber_lineas_phi):,} tok en phi")
for sub, lins in phi_lineas.items():
    key = f"177/{sub}"
    lins_phi = mete_miku(lins)
    manif["tandas"][key] = {"lineas": lins_phi,
                            "tokens_obj": sum(l["tokens"] for l in lins_phi),
                            "lr": 1e-5, "T": 8192, "familia": "reasoning",
                            "nota": "phi=razonar+brainstorm+CYBER-GEN"}
    manif["cobertura"][key] = {"tokens_obj": manif["tandas"][key]["tokens_obj"]}
    anota(177, {"razonar", "brainstorm"} | set(CYBER_SLOTS_ORD))

# 2.5) overrides
if os.path.exists(OVERRIDES_PATH):
    ov = json.load(open(OVERRIDES_PATH))
    print(f"[v8·override] {len(ov)} ajustes manuales")
    for slot_str, accion in ov.items():
        t = manif["tandas"].setdefault(slot_str, {"lineas": [], "tokens_obj": 0})
        if accion.get("drop") == "__all__":
            t["lineas"] = miku_lines.copy()
        elif accion.get("drop"):
            drop = set(accion["drop"])
            t["lineas"] = [l for l in t["lineas"] if l["fichero"] not in drop]
        for p in accion.get("add", []):
            t["lineas"].append({"fichero": p, "offset": 0,
                                "tokens": tok_est(os.path.join(ROOT, p))})
        t["tokens_obj"] = sum(l["tokens"] for l in t["lineas"])
        manif["cobertura"][slot_str] = {"tokens_obj": t["tokens_obj"]}

# 2.6) tabla + indice + guardar
manif["dormant"] = sorted(set(range(1, 129)) - {int(k) for k in manif["tandas"] if k.isdigit() and int(k) <= 128} |
                          set(s for s in range(129, 177)
                              if s not in {int(k) for k in manif["tandas"] if k.isdigit() and 129 <= int(k) <= 176}))
manif["categorias_por_slot"] = {k: sorted(v) for k, v in sorted(cat_por_slot.items(), key=lambda kv: (len(kv[0]), int(kv[0]))) }
manif["categorias_indice"] = {c: sorted([s for s, cc in manif["categorias_por_slot"].items() if c in cc],
                                        key=lambda x: int(x))
                              for c in sorted({c for v in cat_por_slot.values() for c in v})}

total = sum(v["tokens_obj"] for v in manif["cobertura"].values())
seen = {}
for t in manif["tandas"].values():
    for l in t["lineas"]: seen.setdefault(l["fichero"], l["tokens"])
total_unico = sum(seen.values())

print(f"\n=== v8 modo={NEMO_MODE} apoyo_39={APOYO_39} · {len(manif['tandas'])} tandas ===")
print(f"  tandas:= {len(manif['tandas'])} | tokens tanda (doble-x intencionado): {total:,}")
print(f"  CORPUS ÚNICO: {total_unico:,} (lo honesto)")
print(f"  dormant: {len(manif['dormant'])}")

print("\n== tandas nemo (slot · tokens · familia) ==")
nemo_items = [(k, v) for k, v in manif["tandas"].items() if k.isdigit() and int(k) <= 128]
for clave, v in sorted(nemo_items, key=lambda kv: int(kv[0])):
    print(f"  N {clave:<4} {v['tokens_obj']:>13,d}  {v['familia']}")

print("\n== qwen élite ==")
qwen_items = [(k, v) for k, v in manif["tandas"].items() if k.isdigit() and 128 < int(k) < 177]
for clave, v in sorted(qwen_items, key=lambda kv: int(kv[0])):
    print(f"  Q {clave:<4} {v['tokens_obj']:>13,d}  {v['familia']}")

print("\n== phi ==")
for clave, v in sorted((k, v) for k, v in manif["tandas"].items() if "/" in k):
    print(f"  φ {clave:<8} {v['tokens_obj']:>13,d}  {v.get('nota','')}")

slots_con_programa = {int(k) for k in manif["tandas"] if k.isdigit()}
print(f"\n== CHEQUEO 177 == expertos con programa: {len(slots_con_programa)}/177 "
      f"(nemo {sum(1 for s in slots_con_programa if s<=128)}/128, "
      f"qwen {sum(1 for s in slots_con_programa if 129<=s<=176)}/48, "
      f"phi {'OK' if all(f'177/sub_{i}' in manif['tandas'] for i in range(3)) else 'FALTA'})")

def _json_safe(o):
    if isinstance(o, dict): return {k: _json_safe(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)): return [_json_safe(v) for v in o]
    if isinstance(o, (set, frozenset)): return sorted(_json_safe(v) for v in o)
    return o

print("\n== CATEGORÍAS POR SLOT (diagnóstico multi-etiqueta) ==")
cps = manif["categorias_por_slot"]
todos_cats = {c for v in cps.values() for c in v}
uni = [k for k, v in cps.items() if len(v) <= 1]
print(f"categorías distintas halladas: {len(todos_cats)} | slots con ≤1 categoría: {len(uni)}")
for k in sorted(cps, key=lambda x: (len(x), int(x)))[:45]:
    print(f"  {k:>3}: {len(cps[k])} → {', '.join(cps[k])}")
if len(cps) > 45: print(f"  ... ({len(cps)-45} slots más, completo en el JSON)")

if not DRY:
    destino = os.path.abspath(OUT)
    try:
        os.makedirs(os.path.dirname(destino), exist_ok=True)
        with open(destino, "w", encoding="utf-8") as fh:
            json.dump(_json_safe(manif), fh, ensure_ascii=False, indent=1)
    except Exception as exc:
        print(f"!! escribiendo en {destino}: {exc!r} — reintentando en la carpeta del usuario")
        destino = os.path.join(os.path.expanduser("~"), os.path.basename(OUT))
        with open(destino, "w", encoding="utf-8") as fh:
            json.dump(_json_safe(manif), fh, ensure_ascii=False, indent=1)
    print(f"\n✓ escrito: {destino}  ({os.path.getsize(destino):,} bytes)")
else:
    print("DRY → nada escrito")
