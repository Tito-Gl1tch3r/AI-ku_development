# ============================================================================
# CELDA P0 — PRUEBA DE LA MINA conv1d + equivalencia enable_gqa (Kaggle, GPU)
# ----------------------------------------------------------------------------
# Corre ESTO PRIMERO, antes de tocar inferencia o SFT con la copia AI-ku_New.
# 1) Demuestra si la llamada original a causal_conv1d_fn era una mina activa.
# 2) Demuestra que el fix reproduce la referencia torch exactamente.
# 3) Demuestra que enable_gqa == repeat_kv (FIX-02) en tu versión de torch.
# Nada de esto toca pesos: solo tensores de juguete.
# ============================================================================
import torch
import torch.nn.functional as Fn

assert torch.cuda.is_available(), "Necesitas GPU (Kaggle T4 x2 vale)"
torch.manual_seed(0)

B, L, D, K = 2, 64, 96, 4
x = torch.randn(B, L, D, device="cuda", dtype=torch.bfloat16)
w = torch.randn(D, 1, K, device="cuda", dtype=torch.bfloat16)
bias = torch.randn(D, device="cuda", dtype=torch.bfloat16)
act = torch.nn.SiLU()

# ----- Referencia (torch): conv1d causal (pad izquierdo) + UNA SiLU ----------
ref = Fn.conv1d(Fn.pad(x.transpose(1, 2), (K - 1, 0)), w, bias).transpose(1, 2)
ref = act(ref)
print(f"ref: shape={tuple(ref.shape)} dtype={ref.dtype}")

try:
    from causal_conv1d import causal_conv1d_fn
except Exception as e:
    print("causal_conv1d NO instalado -> el path de kernels nunca pudo ejecutarse aqui;", e)
    causal_conv1d_fn = None

if causal_conv1d_fn is not None:
    print(f"causal_conv1d OK. torch={torch.__version__}")

    # --- 1) La llamada ORIGINAL sospechosa (layout [B,L,D] + doble SiLU) -----
    print("\n[P0] Llamada ORIGINAL (sospechosa):")
    try:
        vieja = act(
            causal_conv1d_fn(
                x=x,  # [B, L, D] SIN transponer (asi estaba en modeling_v4x.py)
                weight=w.squeeze(1),
                bias=bias,
                activation="silu",  # + SiLU dentro = doble
            )
        )
        d = (vieja.float() - ref.float()).abs().max().item()
        escala = ref.float().abs().max().item()
        print(f"  no lanza error. max|vieja-ref| = {d:.4f}  (escala ref ~ {escala:.2f})")
        print("  VEREDICTO:", "MINA CONFIRMADA (corrompia en silencio)" if d > 0.1 * escala else "coincidia (improbable)")
    except Exception as e:
        print(f"  ERROR en runtime: {type(e).__name__}: {str(e)[:400]}")
        print("  VEREDICTO: la llamada original reventaba si se ejecutaba -> el path de kernels estaba roto")

    # --- 2) La llamada NUEVA (FIX-05: transpose + SiLU unica) -----------------
    print("\n[FIX-05] Llamada corregida:")
    nueva = act(causal_conv1d_fn(x=x.transpose(1, 2), weight=w.squeeze(1), bias=bias).transpose(1, 2))
    dn = (nueva.float() - ref.float()).abs().max().item()
    print(f"  max|nueva-ref| = {dn:.6f}  -> debe ser ~0 (tolerancia bf16: < 0.05)")

# ----- 3) Equivalencia enable_gqa vs repeat_kv (FIX-02) -----------------------
print("\n[FIX-02] enable_gqa vs repeat_kv:")
qh, kv, hd, T = 32, 2, 128, 128
grp = qh // kv
q = torch.randn(1, qh, T, hd, device="cuda", dtype=torch.bfloat16)
k = torch.randn(1, kv, T, hd, device="cuda", dtype=torch.bfloat16)
v = torch.randn(1, kv, T, hd, device="cuda", dtype=torch.bfloat16)

def repeat_kv(t, n):
    b, h, s, d = t.shape
    return t[:, :, None, :, :].expand(b, h, n, s, d).reshape(b, h * n, s, d)

a = Fn.scaled_dot_product_attention(q, repeat_kv(k, grp), repeat_kv(v, grp), is_causal=True)
v_torch = tuple(int(p) for p in torch.__version__.split("+")[0].split(".")[:2])
print(f"  torch version: {torch.__version__}")
if v_torch >= (2, 5):
    b_ = Fn.scaled_dot_product_attention(q, k, v, is_causal=True, enable_gqa=True)
    dg = (a.float() - b_.float()).abs().max().item()
    print(f"  max|repeat-gqa| = {dg:.6f}  -> debe ser ~0")
    print("  VEREDICTO FIX-02:", "OK, camino sin copia validado" if dg < 0.02 else "REVISAR (diferencia alta)")
else:
    print("  torch < 2.5: _GQA_SDPA=False y el modelo cae al camino antiguo (todo sigue igual).")

print("\nP0 COMPLETO. Pega esta salida antes de integrar AI-ku_New.")
