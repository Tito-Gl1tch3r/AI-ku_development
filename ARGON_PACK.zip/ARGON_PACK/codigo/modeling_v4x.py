# coding=utf-8
# Copyright 2024 AI21 Labs Ltd. and the HuggingFace Inc. team. All rights reserved.
# Copyright (c) 2025, NVIDIA CORPORATION. All rights reserved.
# Copyright (c) 2026, AI-ku. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""AI-ku V4X (Thinker-Max 35B) — implementación completa del modelo.

Jerarquía EXACTA del checkpoint (`model.safetensors.index.json`):

  V4XForCausalLM
  ├── backbone.embeddings.weight                     [131072, 2688]
  ├── backbone.layers.{0..51}.norm.weight
  ├── backbone.layers.{L}.mixer.*                    (Mamba2 | Attention | MoE)
  │     └── MoE: .experts.{0..127} · .gate · .shared_experts
  │               .new_experts.{0..48} (Qwen silu + Phi silu)   [capas 17..47]
  │               .v4x_router.weight                             [capas 17..51]
  ├── backbone.norm_f.weight
  ├── lm_head.weight
  ├── V4X_Transcription.model.{encoder,decoder}.*    Whisper large-v3 (sin k_bias/proj_out)
  ├── V4X_Music.*                                    MERT-v1-330M
  ├── V4X_Audio.audio_tower.*                        Qwen3-Omni audio tower (proj1/proj2)
  ├── V4X_Vision.visual.*                            Qwen3-VL vision tower (imagen Y vídeo, +deepstack)
  └── V4X_Vision.adapter.net.{0,3,4}.*               proyección visión(4096)->V4X(2688)

Slots lógicos del router V4X (fila -> experto):
    0..127  base Nemotron (solo capas MoE)   128  shared (añadido aparte, nunca enrutado)
    129..176 new_experts.0..47 (Qwen3-Coder)  177  new_experts.48 (Phi-4)

Modos de routing (`V4XConfig.v4x_routing_mode`):
  - "off"      (defecto): forward base Nemotron puro. Todos los pesos V4X cargados
              pero sin participar -> logits base coherentes (fase 0: test "hola").
  - "parallel" : forward base + rama ADITIVA de new_experts enrutada por v4x_router
              (semántica del modeling_v4x original: Block añade la rama sobre el
              hidden normalizado, para TODAS las capas con new_experts).
  - "unified"  : en capas MoE el v4x_router SUSTITUYE al gate Nemotron
              (base+qwen+phi; shared aparte). En capas NO-MoE equivale a parallel.

Scoring del router V4X (`v4x_router_scoring`): "softmax" (defecto, como el
modeling original: softmax sobre los top-k logits) o "sigmoid" (estilo Nemotron:
sigmoid + renormalización + routed_scaling_factor).

Categorías (ver AUDIT_REPORT.md):
  (1) pesos en checkpoint: TODO lo anterior (este archivo).
  (2) tokenizer/preprocesado: tokenizer.json (NO tocar), extractores de features
      (Whisper/Qwen2VL) — fuera del forward neuronal.
  (3) runtime: parsers de reasoning/tool-calling — fuera del modeling.

Fuentes verificadas línea a línea:
  - Mamba2 SSD (naive + kernels): modeling_v4x original del usuario.
  - Atención backbone + RoPE/YaRN: modeling_v4x original + transformers.modeling_rope_utils.
  - MoE/gate: modeling_nemotron_h (NVIDIA).
  - Whisper: transformers.modeling_whisper (sin k_proj.bias, sin proj_out).
  - MERT: modeling_MERT (attention_relax, weight_norm pos_conv, LN estable).
  - Qwen3-Omni audio / Qwen3-VL vision: transformers v4.57 models/qwen3_omni_moe y
    models/qwen3_vl_moe (ventanas de conv, cu_seqlens, fast_pos_embed_interpolate,
    deepstack merger). La torre de visión V4X_Vision procesa imagen y vídeo.
"""

import math
import warnings
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple, Union

import torch
import torch.utils.checkpoint
from torch import nn
from torch.nn import CrossEntropyLoss, functional as F

from transformers.activations import ACT2FN
from transformers.generation import GenerationMixin
from transformers.modeling_utils import PreTrainedModel
from transformers.utils import ModelOutput, logging
from transformers.utils.import_utils import (
    is_causal_conv1d_available,
    is_flash_attn_2_available,
    is_mamba_2_ssm_available,
)

from .configuration_v4x import V4XConfig, V4X_NUM_QWEN_EXPERTS

# Alias: el código Nemotron-H usa NemotronHConfig; aquí es V4XConfig.
NemotronHConfig = V4XConfig

logger = logging.get_logger(__name__)

# ── slots lógicos V4X ────────────────────────────────────────────────────────
V4X_SLOT_SHARED = 128            # shared expert (capas MoE)
V4X_NEW_EXPERT_SLOT_BASE = 129   # primer new_expert (Qwen) en el espacio lógico
V4X_PHI_SLOT = 177               # experto Phi-4 en el espacio lógico

# ── Flags CAMBIOS 104 (CONTRATO AUTO-EJECUCIÓN; todos OFF por defecto) ─────────
# Se activan por entorno y SOLO para los gates del laboratorio. Si pasan su gate
# numérico quedan promovidos a canónico (acta 104); mientras tanto: inertes.
import os as _os_flags
_V4X_FLAG_OPT1 = _os_flags.environ.get("V4X_OPT1_NOGRAD_PREFIX", "0") == "1"
_V4X_FLAG_HYP1 = _os_flags.environ.get("V4X_HYP1_MOE_NOCKPT", "0") == "1"
_V4X_FLAG_HYP3 = _os_flags.environ.get("V4X_HYP3_EXPD2", "0") == "1"
_V4X_FLAG_HYP4 = _os_flags.environ.get("V4X_HYP4_LOOKAHEAD", "0") == "1"


# CAZA #29 (casa, 19-oct): los 4 flags se leían SOLO en import-time — un A/B que
# cambie os.environ en el mismo proceso los dejaba congelados. Lectura en
# caliente al estilo _flag_opt8(), con respaldo a la global (compat con quien
# escriba modeling_v4x._V4X_FLAG_X = True directamente).
def _flag_opt1() -> bool:
    return _V4X_FLAG_OPT1 or _os_flags.environ.get("V4X_OPT1_NOGRAD_PREFIX", "0") == "1"


def _flag_hyp1() -> bool:
    return _V4X_FLAG_HYP1 or _os_flags.environ.get("V4X_HYP1_MOE_NOCKPT", "0") == "1"


def _flag_hyp3() -> bool:
    return _V4X_FLAG_HYP3 or _os_flags.environ.get("V4X_HYP3_EXPD2", "0") == "1"


def _flag_hyp4() -> bool:
    return _V4X_FLAG_HYP4 or _os_flags.environ.get("V4X_HYP4_LOOKAHEAD", "0") == "1"


def _flag_opt8() -> bool:
    # OPT-8 se lee EN CALIENTE para poder alternar dentro del mismo proceso (A/B).
    return _os_flags.environ.get("V4X_OPT8_FP16", "0") == "1"


def _v4x_exp_trainable(mod: nn.Module) -> bool:
    # Convención de aislamiento 1-a-1 (57): todo el experto comparte el flag.
    try:
        return bool(next(mod.parameters()).requires_grad)
    except StopIteration:
        return False

# ── kernels opcionales (NO necesarios: fallback puro PyTorch exacto) ─────────
if is_mamba_2_ssm_available():
    from mamba_ssm.ops.triton.selective_state_update import selective_state_update
    from mamba_ssm.ops.triton.ssd_combined import mamba_chunk_scan_combined
else:
    selective_state_update, mamba_chunk_scan_combined = None, None

if is_causal_conv1d_available():
    from causal_conv1d import causal_conv1d_fn, causal_conv1d_update
else:
    causal_conv1d_fn, causal_conv1d_update = None, None

is_fast_path_available = all(
    (selective_state_update, mamba_chunk_scan_combined, causal_conv1d_fn, causal_conv1d_update)
)

if is_flash_attn_2_available():
    try:
        from transformers.modeling_flash_attention_utils import _flash_attention_forward
    except Exception:  # pragma: no cover
        _flash_attention_forward = None
else:
    _flash_attention_forward = None


def rmsnorm_fn(x, weight, bias=None, z=None, eps=1e-6, group_size=None, norm_before_gate=False):
    """RMSNorm agrupado con puerta — implementación local exacta (fallback sin mamba_ssm)."""
    original_shape = x.shape
    if group_size is not None:
        x = x.reshape(original_shape[:-1] + (original_shape[-1] // group_size, group_size))
        weight = weight.reshape(weight.shape[:-1] + (weight.shape[-1] // group_size, group_size))
        if z is not None:
            z = z.reshape(original_shape[:-1] + (original_shape[-1] // group_size, group_size))

    hidden_states = x * torch.rsqrt(x.pow(2).mean(-1, keepdim=True) + eps)
    hidden_states = hidden_states * weight
    if bias is not None:
        hidden_states = hidden_states + bias
    if z is not None:
        if norm_before_gate:
            hidden_states = hidden_states * F.silu(z)
        else:
            hidden_states = F.silu(z) * hidden_states
    if group_size is not None:
        hidden_states = hidden_states.reshape(original_shape)
    return hidden_states


# ═══════════════════════════════════════════════════════════════════════════
# SECCIÓN 1 — RoPE del backbone (default + YaRN 4x)
# ═══════════════════════════════════════════════════════════════════════════

def rotate_half(x):
    # FIX-01 (V4): sin torch.cat: 1 alloc en vez de neg+cat (mismos valores por construccion)
    out = torch.empty_like(x)
    half = x.shape[-1] // 2
    out[..., :half] = -x[..., half:]
    out[..., half:] = x[..., :half]
    return out


def apply_rotary_pos_emb(q, k, cos, sin, unsqueeze_dim=1):
    # FIX-01 (V4): fase sigue 100% en fp32 (exactitud intacta), addcmul = menos temporales
    orig_q_dtype, orig_k_dtype = q.dtype, k.dtype
    q32, k32 = q.float(), k.float()
    cos, sin = cos.unsqueeze(unsqueeze_dim).float(), sin.unsqueeze(unsqueeze_dim).float()
    q_embed = torch.addcmul(q32 * cos, rotate_half(q32), sin)
    k_embed = torch.addcmul(k32 * cos, rotate_half(k32), sin)
    return q_embed.to(orig_q_dtype), k_embed.to(orig_k_dtype)


class V4XRotaryEmbedding(nn.Module):
    """RoPE del backbone con YaRN — matemática idéntica a LlamaRotaryEmbedding.

    Usa `ROPE_INIT_FUNCTIONS` oficial de transformers si está disponible y cae a
    una copia local exacta en caso contrario.
    """

    def __init__(self, config: V4XConfig, device=None):
        super().__init__()
        self.config = config
        self.rope_type = "default"
        rope_scaling = getattr(config, "rope_scaling", None)
        if isinstance(rope_scaling, dict) and len(rope_scaling) > 0:
            self.rope_type = rope_scaling.get("rope_type", rope_scaling.get("type", "default"))

        inv_freq, self.attention_scaling = self._compute_inv_freq(config, device)
        self.register_buffer("inv_freq", inv_freq, persistent=False)

    @staticmethod
    def _compute_inv_freq(config, device):
        # 1) ruta oficial (transformers >= 4.53, incluida la 5.x)
        try:
            from transformers.modeling_rope_utils import ROPE_INIT_FUNCTIONS

            rope_scaling = getattr(config, "rope_scaling", None)
            rtype = "default"
            if isinstance(rope_scaling, dict) and len(rope_scaling) > 0:
                rtype = rope_scaling.get("rope_type", rope_scaling.get("type", "default"))
            fn = ROPE_INIT_FUNCTIONS.get(rtype if rtype in ROPE_INIT_FUNCTIONS else "default")
            if fn is not None:
                return fn(config, device)
        except Exception:
            pass

        # 2) fallback local (idéntico a transformers.modeling_rope_utils)
        base = config.rope_theta
        partial_rotary_factor = getattr(config, "partial_rotary_factor", 1.0) or 1.0
        head_dim = getattr(config, "head_dim", None) or config.hidden_size // config.num_attention_heads
        dim = int(head_dim * partial_rotary_factor)

        rope_scaling = getattr(config, "rope_scaling", None)
        if isinstance(rope_scaling, dict) and rope_scaling.get("rope_type", rope_scaling.get("type")) == "yarn":
            factor = rope_scaling["factor"]
            attention_factor = rope_scaling.get("attention_factor")
            if attention_factor is None:
                attention_factor = 0.1 * math.log(factor) + 1.0
            beta_fast = rope_scaling.get("beta_fast") or 32
            beta_slow = rope_scaling.get("beta_slow") or 1
            old_ctx = rope_scaling.get("original_max_position_embeddings") or config.max_position_embeddings

            def find_correction_dim(num_rotations):
                return (dim * math.log(old_ctx / (num_rotations * 2 * math.pi))) / (2 * math.log(base))

            low = max(math.floor(find_correction_dim(beta_fast)), 0)
            high = min(math.ceil(find_correction_dim(beta_slow)), dim - 1)
            if low == high:
                high += 1

            pos_freqs = base ** (torch.arange(0, dim, 2, dtype=torch.float32, device=device) / dim)
            inv_freq_extrapolation = 1.0 / pos_freqs
            inv_freq_interpolation = 1.0 / (factor * pos_freqs)
            linear = (torch.arange(dim // 2, dtype=torch.float32, device=device) - low) / (high - low)
            ramp = torch.clamp(linear, 0, 1)
            inv_freq = inv_freq_interpolation * ramp + inv_freq_extrapolation * (1 - ramp)
            return inv_freq, attention_factor

        inv_freq = 1.0 / (base ** (torch.arange(0, dim, 2, dtype=torch.float32, device=device) / dim))
        return inv_freq, 1.0

    @torch.no_grad()
    def forward(self, x, position_ids):
        inv_freq_expanded = self.inv_freq[None, :, None].float().expand(position_ids.shape[0], -1, 1).to(x.device)
        position_ids_expanded = position_ids[:, None, :].float()

        device_type = x.device.type if isinstance(x.device.type, str) and x.device.type != "mps" else "cpu"
        with torch.autocast(device_type=device_type, enabled=False):
            freqs = (inv_freq_expanded.float() @ position_ids_expanded.float()).transpose(1, 2)
            emb = torch.cat((freqs, freqs), dim=-1)
            cos = emb.cos() * self.attention_scaling
            sin = emb.sin() * self.attention_scaling
        return cos.to(dtype=x.dtype), sin.to(dtype=x.dtype)


# ═══════════════════════════════════════════════════════════════════════════
# SECCIÓN 2 — Normas, MLP, expertos V4X y routers
# ═══════════════════════════════════════════════════════════════════════════

class NemotronHRMSNorm(nn.Module):
    """RMSNorm del backbone (fp32 interno, como el modeling original)."""

    def __init__(self, hidden_size, eps=1e-6):
        super().__init__()
        self.variance_epsilon = eps
        self.weight = nn.Parameter(torch.ones(hidden_size))

    def forward(self, hidden_states):
        input_dtype = hidden_states.dtype
        hidden_states = hidden_states.to(torch.float32)
        variance = hidden_states.pow(2).mean(-1, keepdim=True)
        hidden_states = hidden_states * torch.rsqrt(variance + self.variance_epsilon)
        return (self.weight.to(torch.float32) * hidden_states).to(input_dtype)


class MambaRMSNormGated(nn.Module):
    """RMSNorm agrupado con puerta (mamba2): `norm.weight` [d_inner]."""

    def __init__(self, hidden_size, group_size, eps=1e-5):
        super().__init__()
        self.variance_epsilon = eps
        self.group_size = group_size
        self.weight = nn.Parameter(torch.ones(hidden_size))

    def forward(self, hidden_states, gate=None):
        return rmsnorm_fn(
            hidden_states,
            self.weight,
            z=gate,
            eps=self.variance_epsilon,
            group_size=self.group_size,
            norm_before_gate=False,
        )


class NemotronHMLP(nn.Module):
    """MLP Nemotron: relu² (up_proj + down_proj, SIN gate_proj ni bias)."""

    def __init__(self, config, intermediate_size=None, layer_idx: Optional[int] = None):
        super().__init__()
        self.config = config
        self.intermediate_size = (
            config.intermediate_size if intermediate_size is None else intermediate_size
        )
        self.layer_idx = layer_idx
        self.up_proj = nn.Linear(config.hidden_size, self.intermediate_size, bias=config.mlp_bias)
        self.down_proj = nn.Linear(self.intermediate_size, config.hidden_size, bias=config.mlp_bias)
        self.act = ACT2FN[config.mlp_hidden_act]

    def forward(self, x):
        return self.down_proj(self.act(self.up_proj(x)))


class V4XNewExpert(nn.Module):
    """Experto externo colapsado (Qwen3-Coder o Phi-4): silu con gate/up/down, sin bias."""

    def __init__(self, hidden_size, intermediate_size):
        super().__init__()
        self.gate_proj = nn.Linear(hidden_size, intermediate_size, bias=False)
        self.up_proj = nn.Linear(hidden_size, intermediate_size, bias=False)
        self.down_proj = nn.Linear(intermediate_size, hidden_size, bias=False)

    def forward(self, x):
        return self.down_proj(F.silu(self.gate_proj(x)) * self.up_proj(x))


class V4XPartialPhiExpert(nn.Module):
    """Caso especial capa 17: el checkpoint SOLO contiene new_experts.48.down_proj.

    No es computable (faltan gate/up) ni enrutable (router de la capa 17 sin slot
    Phi). Se instancia por fidelidad del load (0 unexpected / 0 missing).
    """

    def __init__(self, hidden_size, intermediate_size):
        super().__init__()
        self.down_proj = nn.Linear(intermediate_size, hidden_size, bias=False)

    def forward(self, x):
        raise RuntimeError(
            "El experto Phi parcial de la capa 17 no es computable (solo down_proj en el "
            "checkpoint) ni enrutable (router sin slot Phi). Peso cargado por fidelidad."
        )


class V4XPhiPartialExperts(nn.Module):
    """Contenedor para la capa 17: el experto parcial vive en el índice 48 para
    reproducir la clave exacta `new_experts.48.down_proj.weight`."""

    def __init__(self, hidden_size, intermediate_size):
        super().__init__()
        self.add_module("48", V4XPartialPhiExpert(hidden_size, intermediate_size))

    def __len__(self):
        return 49  # indices 0..48, solo 48 tiene peso real

    def __getitem__(self, idx):
        if idx == 48:
            return self._modules["48"]
        raise IndexError(f"V4XPhiPartialExperts only has index 48, got {idx}")

    def __iter__(self):
        # Para AirLLM que itera
        return iter([self._modules["48"]])


class V4XExpertsStore(nn.Module):
    """Almacén de expertos del checkpoint: `backbone.layers.L.V4X.experts.{idx}`.

    ModuleList de tamaño `n_routed_experts + 1` (índices 0..177). Las ranuras sin
    experto se dejan a None (ModuleList no las registra -> el load es
    0-unexpected/0-missing). El índice 0 queda vacío (el checkpoint no tiene
    experto en la ranura 0).

    Contenido por capa (verificado contra el índice del checkpoint):
      - 1..128       : Nemotron relu2 (solo bloques tipo "moe")
      - 129..176     : Qwen silu, en las capas v4x_qwen_expert_layers (18..47)
      - 177          : Phi silu, en las capas v4x_phi_expert_layers (18..39);
                       down_proj parcial en v4x_phi_partial_layers (capa 17)
    """

    def __init__(self, config: V4XConfig, layer_idx: Optional[int], block_type: Optional[str] = None):
        super().__init__()
        store = [None] * (config.n_routed_experts + 1)

        if block_type == "moe":
            for e in range(config.base_num_experts):
                store[e + 1] = NemotronHMLP(
                    config, intermediate_size=config.moe_intermediate_size, layer_idx=layer_idx
                )

        if layer_idx in config.v4x_qwen_expert_layers:
            n_qwen = getattr(config, "v4x_num_qwen_experts", V4X_NUM_QWEN_EXPERTS)
            for k in range(n_qwen):
                store[V4X_NEW_EXPERT_SLOT_BASE + k] = V4XNewExpert(
                    config.hidden_size, config.v4x_qwen_expert_intermediate_size
                )

        if layer_idx in config.v4x_phi_expert_layers:
            store[V4X_PHI_SLOT] = V4XNewExpert(config.hidden_size, config.v4x_phi_expert_intermediate_size)
        elif layer_idx in config.v4x_phi_partial_layers:
            store[V4X_PHI_SLOT] = V4XPartialPhiExpert(config.hidden_size, config.v4x_phi_expert_intermediate_size)

        self.experts = nn.ModuleList(store)


# ---------------------------------------------------------------------------
# FIX-06 (CAMBIOS 70/73): máscara de elegibilidad Phi-177 por spans de
# razonamiento. IDs verificados contra tokenizer.json (73): start=10, end=11,
# think=12, thought=13. Bordes probados por shift causal: phi VIVO en el token
# 12 (predice el 1er pensamiento), MUERTO en 13/11 (predice el 1er token
# visible), y el 10 (inicio de documento) MATA cualquier span abierto —
# cierre del defecto "bleed entre documentos del pack" cazado en CAMBIOS 69.
# ---------------------------------------------------------------------------
_V4X_ID_START = 10   # <|V4X_start|>
_V4X_ID_END = 11     # <|V4X_end|>
_V4X_ID_THINK = 12   # <|V4X_think|>
_V4X_ID_THOUGHT = 13  # <V4X_thought|>


def _v4x_build_phi_span_mask(
    input_ids: torch.Tensor,
    prev_in_think: Optional[torch.Tensor] = None,
) -> "Tuple[torch.Tensor, torch.Tensor]":
    """Devuelve (mask bool [B,T], next_state bool [B,1]).

    FIX-06a (CAMBIOS 75): estado persistente para decode autoregresivo [B,1].
    BUG REAL cazado por ARGON: sin estado, generate() apagaba Phi-177 tras el
    propio token 12. Regla: los tokens anteriores a la PRIMERA marca (10/11/12/13)
    del bloque heredan `prev_in_think` (válido también para prefill chunked).
    El token 10 mata spans abiertos entre documentos (cerrado en 74).
    """
    opens = (input_ids == _V4X_ID_THINK)
    closes = (input_ids == _V4X_ID_THOUGHT) | (input_ids == _V4X_ID_END) | (input_ids == _V4X_ID_START)
    pos = torch.arange(1, input_ids.shape[-1] + 1, device=input_ids.device, dtype=torch.int32)
    last_open = torch.cummax(opens.to(torch.int32) * pos, dim=-1).values
    last_close = torch.cummax(closes.to(torch.int32) * pos, dim=-1).values
    span = last_open > last_close
    if prev_in_think is not None:
        prev = prev_in_think.to(device=input_ids.device).view(-1, 1).bool()
        has_mark = (opens | closes).cumsum(dim=-1) > 0
        span = torch.where(has_mark, span, prev)
    return span, span[:, -1:].contiguous()


class V4XRouter(nn.Module):
    """Router unificado V4X — `v4x_router.weight` parámetro directo [dim, hidden].

    Scoring "softmax" (defecto, semántica del modeling original):
        logits = x @ W^T ; top-k ; softmax sobre los logits seleccionados.
    Scoring "sigmoid" (estilo Nemotron):
        sigmoid(logits) ; top-k ; renormalización ; × routed_scaling_factor.
    Sin e_score_correction_bias (el checkpoint no lo tiene para v4x_router).
    """

    def __init__(
        self,
        hidden_size,
        num_experts,
        top_k,
        scoring="softmax",
        norm_topk_prob=True,
        routed_scaling_factor=1.0,
    ):
        super().__init__()
        self.num_experts = num_experts
        self.top_k = min(top_k, num_experts)
        self.scoring = scoring
        self.norm_topk_prob = norm_topk_prob
        self.routed_scaling_factor = routed_scaling_factor
        self.weight = nn.Parameter(torch.empty(num_experts, hidden_size, dtype=torch.float32))
        nn.init.normal_(self.weight, std=0.02)

    def forward(self, hidden_states, valid_rows: Optional[torch.Tensor] = None):
        """hidden_states: [tokens, hidden] en fp32.

        `valid_rows`: filas (slots lógicos) cuyo experto existe físicamente en la
        capa; se enmascaran las demás y se hace top-k solo sobre las válidas.
        Devuelve (topk_indices [tokens, k] en slots LÓGICOS, topk_weights fp32).
        """
        logits = F.linear(hidden_states, self.weight.float())  # [tokens, num_experts]
        row_offset = None
        if valid_rows is not None:
            # CAZA #25 (ARGON/96, latente): row_offset SIEMPRE que haya valid_rows.
            # El < estricto lo dejaba en None en las capas con dim=177 (9 MoE en
            # 18..39, donde valid_rows tiene justo 177 filas): FIX-06 no mataba a
            # Phi (177>177 Falso), #15a no anclaba y los indices salian como filas
            # fisicas 0..176 -> fila 128 (Qwen#1) cain al vacio del slot shared,
            # Qwen desplazados +1, y la fila 176 (Phi-177) despachada como Qwen#48:
            # Phi-177 recibia 0 tokens y 0 gradiente en TODAS las capas MoE.
            row_offset = valid_rows
            if valid_rows.numel() < self.num_experts:
                logits = logits[:, valid_rows]

        # FIX-06/FIX-06a (CAMBIOS 70/73/75): fuera de spans think, Phi-177 a
        # -inf ANTES del topk. Variante sin .nonzero()/.item() (0 syncs CPU-GPU,
        # cazada por ARGON): -inf por broadcast donde exista la columna de phi,
        # sin asumir su posición en valid_rows.
        span_mask = getattr(self, "_phi_span_mask", None)
        if span_mask is not None and span_mask.numel() == logits.shape[0]:
            live = span_mask.to(device=logits.device).view(-1, 1)
            if row_offset is not None:
                is_phi_col = (row_offset == V4X_PHI_SLOT).view(1, -1)
            else:
                is_phi_col = None
                if self.num_experts > V4X_PHI_SLOT:
                    col = torch.zeros(1, logits.shape[-1], dtype=torch.bool, device=logits.device)
                    col[0, V4X_PHI_SLOT] = True
                    is_phi_col = col
            if is_phi_col is not None:
                kill = (~live) & is_phi_col
                logits = torch.where(kill, torch.full_like(logits, float("-inf")), logits)

        # #15a (CAMBIOS 94): ANCLA del slot activo en su tanda — mecanismo con
        # flag OFF por defecto (V4X_ANCLA_SLOT) hasta decreto del usuario (CAMBIOS
        # 92 pendiente firma). Solo en routing completo (sin row_offset).
        forced = getattr(self, "_forced_slot", None)
        if forced is not None:
            # CAZA #25 (ARGON/96): el ancla tambien respeta row_offset (sin el mapa
            # nunca se activaba para Phi-177 en NINGUNA capa). 0 syncs: torch.where.
            if row_offset is not None:
                is_f = (row_offset == forced).view(1, -1)
            else:
                is_f = (torch.arange(logits.shape[-1], device=logits.device) == forced).view(1, -1)
            logits = torch.where(is_f, torch.full_like(logits, 1.0e4), logits)

        k = min(self.top_k, logits.shape[-1])
        if self.scoring == "sigmoid":
            scores = torch.sigmoid(logits)
            topk_weights, topk_local = torch.topk(scores, k=k, dim=-1, sorted=False)
            if self.norm_topk_prob:
                topk_weights = topk_weights / (topk_weights.sum(dim=-1, keepdim=True) + 1e-20)
            topk_weights = topk_weights * self.routed_scaling_factor
        else:  # "softmax"
            topk_logits, topk_local = torch.topk(logits, k=k, dim=-1, sorted=False)
            topk_weights = F.softmax(topk_logits, dim=-1, dtype=torch.float32)
            topk_weights = topk_weights * self.routed_scaling_factor  # CAZA #18 (CAMBIOS 92): faltaba x2.5 -> rama MoE al 40%

        if row_offset is not None:
            topk_indices = row_offset.to(topk_local.device)[topk_local]
        else:
            topk_indices = topk_local
        return topk_indices, topk_weights


class NemotronHTopkRouter(nn.Module):
    """Router original Nemotron: `gate.weight` [128, hidden] + `e_score_correction_bias`."""

    def __init__(self, config, num_experts=None, top_k=None):
        super().__init__()
        self.config = config
        self.n_routed_experts = num_experts if num_experts is not None else config.base_num_experts
        self.top_k = top_k if top_k is not None else config.base_num_experts_per_tok
        self.routed_scaling_factor = config.routed_scaling_factor
        self.n_group = config.n_group
        self.topk_group = config.topk_group
        self.norm_topk_prob = config.norm_topk_prob

        self.weight = nn.Parameter(torch.empty((self.n_routed_experts, config.hidden_size), dtype=torch.float32))
        nn.init.normal_(self.weight, std=0.02)
        self.register_buffer("e_score_correction_bias", torch.zeros(self.n_routed_experts, dtype=torch.float32))

    @torch.no_grad()
    def get_topk_indices(self, scores):
        scores_for_choice = scores.view(-1, self.n_routed_experts) + self.e_score_correction_bias.unsqueeze(0)
        group_scores = (
            scores_for_choice.view(-1, self.n_group, self.n_routed_experts // self.n_group)
            .topk(2, dim=-1)[0]
            .sum(dim=-1)
        )
        group_idx = torch.topk(group_scores, k=self.topk_group, dim=-1, sorted=False)[1]
        group_mask = torch.zeros_like(group_scores)
        group_mask.scatter_(1, group_idx, 1)
        score_mask = (
            group_mask.unsqueeze(-1)
            .expand(-1, self.n_group, self.n_routed_experts // self.n_group)
            .reshape(-1, self.n_routed_experts)
        )
        scores_for_choice = scores_for_choice.masked_fill(~score_mask.bool(), 0.0)
        return torch.topk(scores_for_choice, k=self.top_k, dim=-1, sorted=False)[1]

    def forward(self, hidden_states):
        hidden_states = hidden_states.view(-1, self.config.hidden_size)
        router_logits = F.linear(hidden_states.type(torch.float32), self.weight.type(torch.float32))
        scores = router_logits.sigmoid()
        topk_indices = self.get_topk_indices(scores)
        topk_weights = scores.gather(1, topk_indices)
        if self.norm_topk_prob:
            topk_weights = topk_weights / (topk_weights.sum(dim=-1, keepdim=True) + 1e-20)
        topk_weights = topk_weights * self.routed_scaling_factor
        return topk_indices, topk_weights


class V4XExpertsMixin:
    """Añade el `v4x_router` a cualquier mixer (mamba/attention/moe) y enruta los
    expertos del checkpoint (que viven en `backbone.layers.L.V4X.experts`, NO en
    el mixer). El bloque asigna `mixer.v4x_store = block.V4X` tras construirlo.

    Los tres mixers comparten esta construcción porque el checkpoint tiene
    routers/expertos en capas de cualquier tipo (17..51).
    """

    def _init_v4x(self, config: V4XConfig, layer_idx: Optional[int]):
        self.v4x_router = None
        self._v4x_n_routable = 0
        self.v4x_store = None
        if layer_idx is None:
            return
        has_qwen = layer_idx in config.v4x_qwen_expert_layers
        has_phi = layer_idx in config.v4x_phi_expert_layers

        if has_qwen:
            self._v4x_n_routable += getattr(config, "v4x_num_qwen_experts", V4X_NUM_QWEN_EXPERTS)
        if has_phi:
            self._v4x_n_routable += 1

        if layer_idx in config.v4x_router_layers:
            dim = config.v4x_router_dims.get(layer_idx, 177)
            top_k = config.v4x_router_top_k or config.num_experts_per_tok
            self.v4x_router = V4XRouter(
                config.hidden_size,
                dim,
                top_k,
                scoring=getattr(config, "v4x_router_scoring", "softmax"),
                norm_topk_prob=config.norm_topk_prob,
                routed_scaling_factor=config.routed_scaling_factor,
            )

    def _v4x_valid_rows(self, is_moe_layer: bool) -> torch.Tensor:
        """Filas (slots lógicos) cuyo experto existe FÍSICAMENTE en esta capa.

        El slot 128 (shared) nunca se enruta: el shared expert se suma aparte,
        igual que en el forward Nemotron original.
        """
        device = self.v4x_router.weight.device
        n_base = self.config.base_num_experts
        rows = list(range(n_base)) if is_moe_layer else []  # expertos base (solo MoE)
        rows += list(range(V4X_NEW_EXPERT_SLOT_BASE, V4X_NEW_EXPERT_SLOT_BASE + self._v4x_n_routable))
        return torch.tensor(rows, dtype=torch.long, device=device)

    def _v4x_dispatch_new_experts(self, flat, topk_indices, topk_weights):
        """Suma ponderada de los expertos Qwen/Phi (slots 129..177) del store.

        flat: [tokens, hidden] en el dtype del modelo; índices/pesos del router.
        """
        out = torch.zeros(flat.shape[0], flat.shape[1], dtype=topk_weights.dtype, device=flat.device)
        local = topk_indices - V4X_NEW_EXPERT_SLOT_BASE
        experts = self.v4x_store.experts
        for j in range(self._v4x_n_routable):
            sel = local == j
            if sel.any():
                tok, k = torch.where(sel)
                w = topk_weights[tok, k].to(flat.dtype)
                # HYP-3/EXP-D2 (104) + CAZA #31 (casa, 19-oct): congelados bajo
                # no_grad y con inputs detacheados → valor bit-idéntico, CERO
                # grafo jacobiano construido y sin buffer routed_frz duplicado.
                if _flag_hyp3() and not _v4x_exp_trainable(experts[V4X_NEW_EXPERT_SLOT_BASE + j]):
                    with torch.no_grad():
                        y = (experts[V4X_NEW_EXPERT_SLOT_BASE + j](flat[tok].detach()) * w.detach().unsqueeze(-1)).to(out.dtype)
                else:
                    y = (experts[V4X_NEW_EXPERT_SLOT_BASE + j](flat[tok]) * w.unsqueeze(-1)).to(out.dtype)
                out.index_add_(0, tok, y)
        return out

    def v4x_experts_forward(self, normed_hidden, precomputed=None):
        """Rama paralela de expertos para capas NO-MoE (modos parallel/unified).

        Devuelve None si la capa no tiene expertos enrutables.
        `precomputed` (HYP-4, 104): (topk_indices, topk_weights) ya calculados por
        el bloque ANTES del mixer (lookahead); bit-idéntico al cálculo interno.
        """
        if self.v4x_router is None or self._v4x_n_routable == 0:
            return None
        orig_shape = normed_hidden.shape
        flat = normed_hidden.reshape(-1, normed_hidden.shape[-1]).to(torch.float32)
        if precomputed is None:
            valid = self._v4x_valid_rows(is_moe_layer=False)  # solo new experts
            topk_indices, topk_weights = self.v4x_router(flat, valid_rows=valid)
        else:
            topk_indices, topk_weights = precomputed
        out = self._v4x_dispatch_new_experts(flat.to(normed_hidden.dtype), topk_indices, topk_weights)
        return out.view(*orig_shape).to(normed_hidden.dtype)


# ═══════════════════════════════════════════════════════════════════════════
# SECCIÓN 3 — Mamba2
# ═══════════════════════════════════════════════════════════════════════════

def pad_tensor_by_size(input_tensor: torch.Tensor, pad_size: int):
    if len(input_tensor.shape) == 3:
        padding = (0, 0, 0, pad_size, 0, 0)
    elif len(input_tensor.shape) == 4:
        padding = (0, 0, 0, 0, 0, pad_size, 0, 0)
    else:
        raise ValueError(f"pad_tensor_by_size espera rank 3 o 4, recibe {input_tensor.shape}")
    return F.pad(input_tensor, padding, mode="constant", value=0)


def reshape_into_chunks(input_tensor, pad_size, chunk_size):
    input_tensor = pad_tensor_by_size(input_tensor, pad_size)
    if len(input_tensor.shape) == 3:
        input_tensor = input_tensor.view(
            input_tensor.shape[0], input_tensor.shape[1] // chunk_size, chunk_size, input_tensor.shape[2]
        )
    elif len(input_tensor.shape) == 4:
        input_tensor = input_tensor.view(
            input_tensor.shape[0],
            input_tensor.shape[1] // chunk_size,
            chunk_size,
            input_tensor.shape[2],
            input_tensor.shape[3],
        )
    return input_tensor


def segment_sum(input_tensor):
    """Segment sum estable (copia EXACTA del modeling_v4x original).

    [..., chunk] -> [..., chunk, chunk]: out[..., i, j] = sum_{k<=j} input[..., i, k]
    para j <= i; -inf encima de la diagonal (tras exp() => 0 = máscara causal).
    """
    chunk_size = input_tensor.size(-1)
    # 1. expandir con una dimensión extra y repetir a lo largo de esa dimensión
    input_tensor = input_tensor[..., None].expand(*input_tensor.size(), chunk_size)
    # 2. máscara triangular inferior con diagonal a 0 (anula lo de encima)
    mask = torch.tril(torch.ones(chunk_size, chunk_size, device=input_tensor.device, dtype=torch.bool), diagonal=-1)
    input_tensor = input_tensor.masked_fill(~mask, 0)
    # 3. cumsum real
    tensor_segsum = torch.cumsum(input_tensor, dim=-2)
    # 4. mantener la parte triangular inferior incluida la diagonal
    mask = torch.tril(torch.ones(chunk_size, chunk_size, device=input_tensor.device, dtype=torch.bool), diagonal=0)
    tensor_segsum = tensor_segsum.masked_fill(~mask, -torch.inf)
    return tensor_segsum


def apply_mask_to_padding_states(hidden_states, attention_mask):
    """Anula los hidden states de los tokens de padding (mamba issue #66)."""
    if attention_mask is not None and attention_mask.shape[1] > 1 and attention_mask.shape[0] > 1:
        dtype = hidden_states.dtype
        return (hidden_states * attention_mask[:, :, None]).to(dtype)
    return hidden_states


class NemotronHMamba2Mixer(V4XExpertsMixin, nn.Module):
    """Mixer Mamba2 de Nemotron-H (claves: in_proj, conv1d, A_log, D, dt_bias, norm, out_proj)."""

    def __init__(self, config: V4XConfig, layer_idx: int):
        super().__init__()
        self.config = config
        self.num_heads = config.mamba_num_heads
        self.hidden_size = config.hidden_size
        self.ssm_state_size = config.ssm_state_size
        self.conv_kernel_size = config.conv_kernel
        self.intermediate_size = config.mamba_num_heads * config.mamba_head_dim
        self.layer_idx = layer_idx
        self.use_conv_bias = config.use_conv_bias
        self.activation = config.mamba_hidden_act
        self.act = ACT2FN[config.mamba_hidden_act]

        self.layer_norm_epsilon = config.layer_norm_epsilon
        self.n_groups = config.n_groups
        self.head_dim = config.mamba_head_dim
        self.chunk_size = config.chunk_size

        self.time_step_limit = config.time_step_limit
        self.time_step_min = config.time_step_min
        self.time_step_max = config.time_step_max

        self.conv_dim = self.intermediate_size + 2 * self.n_groups * self.ssm_state_size
        self.conv1d = nn.Conv1d(
            in_channels=self.conv_dim,
            out_channels=self.conv_dim,
            bias=config.use_conv_bias,
            kernel_size=config.conv_kernel,
            groups=self.conv_dim,
            padding=config.conv_kernel - 1,
        )

        projection_size = self.intermediate_size + self.conv_dim + self.num_heads
        self.in_proj = nn.Linear(self.hidden_size, projection_size, bias=config.use_bias)

        self.dt_bias = nn.Parameter(torch.ones(self.num_heads))
        A = torch.arange(1, self.num_heads + 1)
        self.A_log = nn.Parameter(torch.log(A))
        self.A_log._no_weight_decay = True
        self.norm = MambaRMSNormGated(
            self.intermediate_size,
            eps=self.layer_norm_epsilon,
            group_size=self.intermediate_size // self.n_groups,
        )
        self.D = nn.Parameter(torch.ones(self.num_heads))
        self.D._no_weight_decay = True
        self.out_proj = nn.Linear(self.intermediate_size, self.hidden_size, bias=config.use_bias)
        self.use_bias = config.use_bias

        self._init_v4x(config, layer_idx)

    # ----------------------------- kernels CUDA -----------------------------
    # Solo para inferencia; el entrenamiento y la CPU usan torch_forward.
    def cuda_kernels_forward(self, hidden_states, cache_params=None, cache_position=None, attention_mask=None):
        hidden_states = apply_mask_to_padding_states(hidden_states, attention_mask)
        projected_states = self.in_proj(hidden_states)

        batch_size, seq_len, _ = hidden_states.shape
        groups_time_state_size = self.n_groups * self.ssm_state_size
        d_mlp = (
            projected_states.shape[-1]
            - 2 * self.intermediate_size
            - 2 * self.n_groups * self.ssm_state_size
            - self.num_heads
        ) // 2

        if cache_params is not None and cache_position is not None and cache_position[0] > 0:
            # decode de 1 token
            _, _, gate, hidden_states_B_C, dt = projected_states.squeeze(1).split(
                [d_mlp, d_mlp, self.intermediate_size, self.conv_dim, self.num_heads], dim=-1
            )
            hidden_states_B_C = causal_conv1d_update(
                hidden_states_B_C,
                cache_params.conv_states[self.layer_idx],
                self.conv1d.weight.squeeze(1),
                self.conv1d.bias,
                self.activation,
            )
            hidden_states, B, C = torch.split(
                hidden_states_B_C,
                [self.intermediate_size, groups_time_state_size, groups_time_state_size],
                dim=-1,
            )
            A = -torch.exp(self.A_log.float())
            A = A[:, None, ...][:, :, None].expand(-1, self.head_dim, self.ssm_state_size).to(dtype=torch.float32)
            dt = dt[:, :, None].expand(-1, -1, self.head_dim)
            dt_bias = self.dt_bias[:, None, ...].expand(-1, self.head_dim)
            D = self.D[:, None, ...].expand(-1, self.head_dim)
            B = B.view(batch_size, self.n_groups, B.shape[1] // self.n_groups)
            C = C.view(batch_size, self.n_groups, C.shape[1] // self.n_groups)
            hidden_states_reshaped = hidden_states.view(batch_size, self.num_heads, self.head_dim)
            hidden_states = selective_state_update(
                cache_params.ssm_states[self.layer_idx],
                hidden_states_reshaped,
                dt,
                A,
                B,
                C,
                D,
                z=None,
                dt_bias=dt_bias,
                dt_softplus=True,
            )
            hidden_states = hidden_states.view(batch_size, self.num_heads * self.head_dim)
            hidden_states = self.norm(hidden_states, gate)
            out = self.out_proj(hidden_states)[:, None, ...]
        else:
            # prefill
            _, _, gate, hidden_states_B_C, dt = projected_states.split(
                [d_mlp, d_mlp, self.intermediate_size, self.conv_dim, self.num_heads], dim=-1
            )
            if cache_params is not None:
                # #21a (CAMBIOS 94): el pad solo hace falta cuando HAY caché que
                # alimentar (con pad negativo recorta a las últimas 4 posiciones —
                # patrón oficial HF-Mamba2; sin caché era trabajo inútil).
                conv_states = nn.functional.pad(
                    hidden_states_B_C.transpose(1, 2),
                    (self.conv_kernel_size - hidden_states_B_C.shape[1], 0),
                )
                cache_params.update_conv_state(
                    layer_idx=self.layer_idx, new_conv_state=conv_states, cache_init=True
                )
            # FIX-05 (P0, mina de exactitud): causal_conv1d_fn exige x como [B, D, L]
            # (transpose in/out) y una UNICA activacion: se quita `activation=` del kernel
            # y se conserva self.act fuera, como hace el camino torch_forward.
            # Validar con celda_P0_conv1d_ab.py antes de inferencia/entrenamiento largo.
            hidden_states_B_C = self.act(
                causal_conv1d_fn(
                    x=hidden_states_B_C.transpose(1, 2),
                    weight=self.conv1d.weight.squeeze(1),
                    bias=self.conv1d.bias,
                ).transpose(1, 2)
            )
            hidden_states, B, C = torch.split(
                hidden_states_B_C,
                [self.intermediate_size, groups_time_state_size, groups_time_state_size],
                dim=-1,
            )
            A = -torch.exp(self.A_log.float())
            dt_limit_kwargs = (
                {} if self.time_step_limit == (0.0, float("inf")) else {"dt_limit": self.time_step_limit}
            )
            scan_output, ssm_state = mamba_chunk_scan_combined(
                hidden_states.view(batch_size, seq_len, -1, self.head_dim),
                dt,
                A,
                B.view(batch_size, seq_len, self.n_groups, -1),
                C.view(batch_size, seq_len, self.n_groups, -1),
                chunk_size=self.chunk_size,
                D=self.D,
                z=None,  # la puerta se aplica después en self.norm(y, gate)
                seq_idx=None,
                return_final_states=True,
                dt_bias=self.dt_bias,
                dt_softplus=True,
                **dt_limit_kwargs,
            )
            if cache_params is not None:
                cache_params.update_ssm_state(layer_idx=self.layer_idx, new_ssm_state=ssm_state)
            scan_output = scan_output.view(batch_size, seq_len, -1)
            scan_output = self.norm(scan_output, gate)
            out = self.out_proj(scan_output)
        return out

    # --------------------------- pytorch puro (exacto) ---------------------------
    def torch_forward(self, input_states, cache_params=None, cache_position=None, attention_mask=None):
        batch_size, seq_len, _ = input_states.shape
        dtype = input_states.dtype

        input_states = apply_mask_to_padding_states(input_states, attention_mask)
        projected_states = self.in_proj(input_states)
        d_mlp = (
            projected_states.shape[-1]
            - 2 * self.intermediate_size
            - 2 * self.n_groups * self.ssm_state_size
            - self.num_heads
        ) // 2
        _, _, gate, hidden_states_B_C, dt = projected_states.split(
            [d_mlp, d_mlp, self.intermediate_size, self.conv_dim, self.num_heads], dim=-1
        )

        # 2. Transformación convolucional (causal)
        if cache_params is not None and cache_position is not None and cache_position[0] > 0:
            cache_params.update_conv_state(
                layer_idx=self.layer_idx, new_conv_state=hidden_states_B_C, cache_init=False
            )
            conv_states = cache_params.conv_states[self.layer_idx].to(device=self.conv1d.weight.device)
            hidden_states_B_C = torch.sum(conv_states * self.conv1d.weight.squeeze(1), dim=-1)
            if self.use_conv_bias:
                hidden_states_B_C = hidden_states_B_C + self.conv1d.bias
            hidden_states_B_C = self.act(hidden_states_B_C)
        else:
            if cache_params is not None:
                hidden_states_B_C_transposed = hidden_states_B_C.transpose(1, 2)
                conv_states = nn.functional.pad(
                    hidden_states_B_C_transposed,
                    (cache_params.conv_kernel_size - hidden_states_B_C_transposed.shape[-1], 0),
                )
                cache_params.update_conv_state(
                    layer_idx=self.layer_idx, new_conv_state=conv_states, cache_init=True
                )
            hidden_states_B_C = self.act(
                self.conv1d(hidden_states_B_C.transpose(1, 2))[..., :seq_len].transpose(1, 2)
            )

        hidden_states_B_C = apply_mask_to_padding_states(hidden_states_B_C, attention_mask)
        hidden_states, B, C = torch.split(
            hidden_states_B_C,
            [self.intermediate_size, self.n_groups * self.ssm_state_size, self.n_groups * self.ssm_state_size],
            dim=-1,
        )

        # 3. SSM
        A = -torch.exp(self.A_log.float())  # [num_heads]
        if cache_params is not None and cache_position is not None and cache_position[0] > 0:
            # recurrencia de 1 token
            cache_device = cache_params.ssm_states[self.layer_idx].device
            dt = dt[:, 0, :][:, None, ...]
            dt = dt.transpose(1, 2).expand(batch_size, dt.shape[-1], self.head_dim)
            dt_bias = self.dt_bias[..., None].expand(self.dt_bias.shape[0], self.head_dim)
            dt = F.softplus(dt + dt_bias.to(dt.dtype))
            dt = torch.clamp(dt, self.time_step_limit[0], self.time_step_limit[1])
            A = A[..., None, None].expand(self.num_heads, self.head_dim, self.ssm_state_size).to(dtype=torch.float32)
            dA = torch.exp(dt[..., None] * A).to(device=cache_device)

            B = B.reshape(batch_size, self.n_groups, -1)[..., None, :]
            B = B.expand(batch_size, self.n_groups, self.num_heads // self.n_groups, B.shape[-1]).contiguous()
            B = B.reshape(batch_size, -1, B.shape[-1])
            dB = dt[..., None] * B[..., None, :]

            hidden_states = hidden_states.reshape(batch_size, -1, self.head_dim)
            dBx = (dB * hidden_states[..., None]).to(device=cache_device)

            cache_params.update_ssm_state(
                layer_idx=self.layer_idx,
                new_ssm_state=cache_params.ssm_states[self.layer_idx] * dA + dBx,
            )

            C = C.reshape(batch_size, self.n_groups, -1)[..., None, :]
            C = C.expand(batch_size, self.n_groups, self.num_heads // self.n_groups, C.shape[-1]).contiguous()
            C = C.reshape(batch_size, -1, C.shape[-1])

            ssm_states = cache_params.ssm_states[self.layer_idx].to(device=C.device, dtype=C.dtype)
            ssm_states_reshaped = ssm_states.view(batch_size * self.num_heads, self.head_dim, self.ssm_state_size)
            C_reshaped = C.view(batch_size * self.num_heads, self.ssm_state_size, 1)
            y = torch.bmm(ssm_states_reshaped, C_reshaped)
            y = y.view(batch_size, self.num_heads, self.head_dim)

            D = self.D[..., None].expand(self.D.shape[0], self.head_dim)
            y = (y + hidden_states * D).to(y.dtype)
            y = y.reshape(batch_size, -1)[:, None, ...]
        else:
            # SSD naive sin einsums (idéntico al modeling original)
            dt = F.softplus(dt + self.dt_bias)
            dt = torch.clamp(dt, self.time_step_limit[0], self.time_step_limit[1])
            hidden_states = hidden_states.reshape(batch_size, seq_len, -1, self.head_dim).float()
            B = B.reshape(batch_size, seq_len, -1, self.ssm_state_size).float()
            C = C.reshape(batch_size, seq_len, -1, self.ssm_state_size).float()
            # CAZA #14 (CAMBIOS 92): B/C viajan AGRUPADOS (g=8) hasta el einsum de G;
            # el repeat_interleave x8 solo se hace después, donde hace falta.
            pad_size = (self.chunk_size - seq_len % self.chunk_size) % self.chunk_size

            D_residual = self.D[..., None] * pad_tensor_by_size(hidden_states, pad_size)

            # Discretizar x y A
            hidden_states = hidden_states * dt[..., None]
            A = A.to(hidden_states.dtype) * dt

            # Reordenar en chunks
            hidden_states, A, B, C = [
                reshape_into_chunks(t, pad_size, self.chunk_size) for t in (hidden_states, A, B, C)
            ]

            A = A.permute(0, 3, 1, 2)
            A_cumsum = torch.cumsum(A, dim=-1)

            # 1. Salida intra-chunk (bloques diagonales)
            # CAZA #14 (CAMBIOS 92): ningún producto 6D se materializa — todos einsum.
            B_grp, C_grp = B, C  # (b, c, l, g=8, n)
            L = torch.exp(segment_sum(A))
            if _flag_opt8():  # OPT-8 (104): contracciones pesadas en fp16, acumulando fp32 vía cuBLAS; exponenciales/E5 intocados
                G = torch.einsum("bclgn,bcsgn->bclsg", C_grp.half(), B_grp.half()).float()
            else:
                G = torch.einsum("bclgn,bcsgn->bclsg", C_grp, B_grp)
            G = G.repeat_interleave(self.num_heads // self.n_groups, dim=-1, output_size=self.num_heads)  # (b, c, l, s, h)
            M = G * L.permute(0, 2, 3, 4, 1)
            if _flag_opt8():  # OPT-8 (104)
                Y_diag = torch.einsum("bclsh,bcshd->bclhd", M.half(), hidden_states.half()).float()  # antes: 16,0 GiB 6D
            else:
                Y_diag = torch.einsum("bclsh,bcshd->bclhd", M, hidden_states)  # antes: 16,0 GiB 6D

            # 2. Estado por intra-chunk (aquí sí: cabezas expandidas)
            B = B_grp.repeat_interleave(self.num_heads // self.n_groups, dim=3, output_size=self.num_heads)
            C = C_grp.repeat_interleave(self.num_heads // self.n_groups, dim=3, output_size=self.num_heads)
            decay_states = torch.exp(A_cumsum[:, :, :, -1:] - A_cumsum)
            B_decay = B * decay_states.permute(0, -2, -1, 1)[..., None]
            if _flag_opt8():  # OPT-8 (104)
                states = torch.einsum("bclhn,bclhd->bchdn", B_decay.half(), hidden_states.half()).float()  # antes: 16,0 GiB 6D (cifra Airi)
            else:
                states = torch.einsum("bclhn,bclhd->bchdn", B_decay, hidden_states)  # antes: 16,0 GiB 6D (cifra Airi)

            # 3. Recurrencia inter-chunk
            if cache_params is not None and cache_position is not None and cache_position[0] > 0:
                previous_states = cache_params.ssm_states[self.layer_idx][:, None, ...].to(device=states.device)
            else:
                previous_states = torch.zeros_like(states[:, :1])
            states = torch.cat([previous_states, states], dim=1)
            decay_chunk = torch.exp(segment_sum(F.pad(A_cumsum[:, :, :, -1], (1, 0))))
            decay_chunk = decay_chunk.transpose(1, 3)
            new_states = torch.einsum("bczh,bchdn->bzhdn", decay_chunk, states)  # #14e (CAMBIOS 92): antes 8,25 GiB 6D
            states, ssm_state = new_states[:, :-1], new_states[:, -1]

            # 4. Estado -> salida por chunk
            state_decay_out = torch.exp(A_cumsum)
            state_decay_out_permuted = state_decay_out.permute(0, 2, 3, 1)
            if _flag_opt8():  # OPT-8 (104)
                Y_off = torch.einsum("bclhn,bchdn->bclhd", C.half(), states.half()).float() * state_decay_out_permuted[..., None]  # #14: antes 16,0 GiB 6D
            else:
                Y_off = torch.einsum("bclhn,bchdn->bclhd", C, states) * state_decay_out_permuted[..., None]  # #14: antes 16,0 GiB 6D

            y = Y_diag + Y_off
            y = y.reshape(batch_size, -1, self.num_heads, self.head_dim)
            y = y + D_residual
            if pad_size > 0:
                y = y[:, :seq_len, :, :]
            y = y.reshape(batch_size, seq_len, -1)

            if ssm_state is not None and cache_params is not None:
                cache_params.update_ssm_state(layer_idx=self.layer_idx, new_ssm_state=ssm_state)

        scan_output = self.norm(y, gate)
        contextualized_states = self.out_proj(scan_output.to(dtype))
        return contextualized_states

    def forward(self, hidden_states, cache_params=None, cache_position=None, attention_mask=None):
        if (
            getattr(self.config, "use_mamba_kernels", True)
            and is_fast_path_available
            and not self.training
            and hidden_states.device.type == "cuda"
        ):
            return self.cuda_kernels_forward(hidden_states, cache_params, cache_position, attention_mask)
        dtype = hidden_states.dtype
        if attention_mask is not None and attention_mask.shape[1] > 1 and attention_mask.shape[0] > 1:
            hidden_states = (hidden_states * attention_mask[:, :, None]).to(dtype)
        return self.torch_forward(hidden_states, cache_params, cache_position, attention_mask)


# ═══════════════════════════════════════════════════════════════════════════
# SECCIÓN 4 — Caché híbrida autocontenida (mamba + atención)
# ═══════════════════════════════════════════════════════════════════════════

class HybridMambaAttentionDynamicCache:
    """Caché híbrida: estados SSM/conv de Mamba2 + KV de atención.

    Autocontenida (no hereda de DynamicCache) para ser estable entre versiones
    de transformers. `update()` la registra como caché de atención estándar, así
    que generate() la persiste vía el campo `cache_params` del output
    (ALL_CACHE_NAMES de transformers la reconoce).
    """

    def __init__(self, config, batch_size, dtype=torch.float16, device=None):
        self.dtype = dtype
        self.has_previous_state = False
        self.in_think_mode = None  # FIX-06a (CAMBIOS 75): estado phi-span persistente en decode
        intermediate_size = config.mamba_num_heads * config.mamba_head_dim
        ssm_state_size = config.ssm_state_size
        conv_kernel_size = config.conv_kernel
        # estados SSM en el dtype indicado por el config (float32 por defecto,
        # como el config original del checkpoint)
        ssm_dtype = dtype
        _cache_dtype = str(getattr(config, "mamba_ssm_cache_dtype", "") or "")
        if _cache_dtype == "float32":
            ssm_dtype = torch.float32
        elif _cache_dtype == "float16":
            ssm_dtype = torch.float16
        elif _cache_dtype == "bfloat16":
            ssm_dtype = torch.bfloat16

        self.conv_states: List[torch.Tensor] = []
        self.ssm_states: List[torch.Tensor] = []
        self.key_cache: List[Optional[torch.Tensor]] = []
        self.value_cache: List[Optional[torch.Tensor]] = []
        self.conv_kernel_size = conv_kernel_size

        for i in range(config.num_hidden_layers):
            if config.layers_block_type[i] == "mamba":
                self.conv_states.append(
                    torch.zeros(
                        batch_size,
                        intermediate_size + config.n_groups * ssm_state_size * 2,
                        conv_kernel_size,
                        device=device,
                        dtype=dtype,
                    )
                )
                self.ssm_states.append(
                    torch.zeros(
                        batch_size,
                        config.mamba_num_heads,
                        config.mamba_head_dim,
                        ssm_state_size,
                        device=device,
                        dtype=ssm_dtype,
                    )
                )
            else:
                self.conv_states.append(torch.zeros(1, device=device, dtype=dtype))
                self.ssm_states.append(torch.zeros(1, device=device, dtype=dtype))

    # ------------------------------ atención ------------------------------
    def update(self, key_states, value_states, layer_idx, cache_kwargs=None):
        if len(self.key_cache) <= layer_idx:
            while len(self.key_cache) <= layer_idx:
                self.key_cache.append(None)
                self.value_cache.append(None)
            self.key_cache[layer_idx] = key_states
            self.value_cache[layer_idx] = value_states
        else:
            self.key_cache[layer_idx] = torch.cat([self.key_cache[layer_idx], key_states], dim=-2)
            self.value_cache[layer_idx] = torch.cat([self.value_cache[layer_idx], value_states], dim=-2)
        self.has_previous_state = True
        return self.key_cache[layer_idx], self.value_cache[layer_idx]

    def get_seq_length(self, layer_idx: Optional[int] = 0) -> int:
        for i in range(len(self.key_cache) - 1, -1, -1):
            if self.key_cache[i] is not None:
                return self.key_cache[i].shape[-2]
        return 0

    def get_max_cache_shape(self) -> Optional[int]:
        return None

    def reorder_cache(self, beam_idx: torch.LongTensor):
        for i in range(len(self.key_cache)):
            if self.key_cache[i] is not None:
                self.key_cache[i] = self.key_cache[i].index_select(0, beam_idx.to(self.key_cache[i].device))
                self.value_cache[i] = self.value_cache[i].index_select(0, beam_idx.to(self.value_cache[i].device))
        for i in range(len(self.conv_states)):
            if self.conv_states[i].numel():
                self.conv_states[i] = self.conv_states[i].index_select(0, beam_idx.to(self.conv_states[i].device))
            if self.ssm_states[i].numel():
                self.ssm_states[i] = self.ssm_states[i].index_select(0, beam_idx.to(self.ssm_states[i].device))

    # ------------------------------- mamba -------------------------------
    def update_conv_state(self, layer_idx, new_conv_state, cache_init=False):
        """cache_init=True: estado completo [bsz, conv_dim, k] (prefill).
        cache_init=False: nuevo token [bsz, 1, conv_dim] o [bsz, conv_dim] (decode)."""
        self.has_previous_state = True
        if cache_init:
            self.conv_states[layer_idx] = new_conv_state.to(self.conv_states[layer_idx].device)
        else:
            new = new_conv_state[:, 0, :] if new_conv_state.dim() == 3 else new_conv_state
            rolled = self.conv_states[layer_idx].roll(shifts=-1, dims=-1)
            rolled[:, :, -1] = new.to(rolled.device)
            self.conv_states[layer_idx] = rolled
        return self.conv_states[layer_idx]

    def update_ssm_state(self, layer_idx, new_ssm_state):
        self.has_previous_state = True
        self.ssm_states[layer_idx] = new_ssm_state.to(self.ssm_states[layer_idx].device)
        return self.ssm_states[layer_idx]

    def reset(self):
        self.in_think_mode = None  # FIX-06a (CAMBIOS 75)
        for layer_idx in range(len(self.conv_states)):
            if self.conv_states[layer_idx].numel():
                self.conv_states[layer_idx].zero_()
            if self.ssm_states[layer_idx].numel():
                self.ssm_states[layer_idx].zero_()


# ═══════════════════════════════════════════════════════════════════════════
# SECCIÓN 5 — Atención del backbone (eager / sdpa / flash)
# ═══════════════════════════════════════════════════════════════════════════

# FIX-02a: SDPA con GQA nativo (torch >= 2.5) elimina la copia fisica x16 de repeat_kv.
# Escape hatch: V4X_DISABLE_GQA=1 restaura el camino antiguo.
def _sdpa_gqa_ok() -> bool:
    try:
        import os
        if os.environ.get("V4X_DISABLE_GQA", "0") == "1":
            return False
        v = torch.__version__.split("+")[0].split(".")
        return int(v[0]) > 2 or (int(v[0]) == 2 and int(v[1]) >= 5)
    except Exception:
        return False


_GQA_SDPA = _sdpa_gqa_ok()


def repeat_kv(hidden_states: torch.Tensor, n_rep: int) -> torch.Tensor:
    batch, num_key_value_heads, slen, head_dim = hidden_states.shape
    if n_rep == 1:
        return hidden_states
    hidden_states = hidden_states[:, :, None, :, :].expand(batch, num_key_value_heads, n_rep, slen, head_dim)
    return hidden_states.reshape(batch, num_key_value_heads * n_rep, slen, head_dim)


class NemotronHAttention(V4XExpertsMixin, nn.Module):
    """Atención GQA del backbone con RoPE (q/k/v/o SIN bias en el checkpoint)."""

    def __init__(self, config: V4XConfig, layer_idx: Optional[int] = None):
        super().__init__()
        self.config = config
        self.layer_idx = layer_idx
        if layer_idx is None:
            logger.warning_once(
                f"Instantiating {self.__class__.__name__} sin `layer_idx` no es recomendable "
                "(errores en forward si se usa caché)."
            )
        self.attention_dropout = config.attention_dropout
        self.hidden_size = config.hidden_size
        self.num_heads = config.num_attention_heads
        self.head_dim = getattr(config, "head_dim", None) or config.hidden_size // config.num_attention_heads
        self.num_key_value_heads = config.num_key_value_heads
        self.num_key_value_groups = self.num_heads // self.num_key_value_heads
        self.max_position_embeddings = config.max_position_embeddings
        self.is_causal = True

        self.q_proj = nn.Linear(self.hidden_size, self.num_heads * self.head_dim, bias=config.attention_bias)
        self.k_proj = nn.Linear(self.hidden_size, self.num_key_value_heads * self.head_dim, bias=config.attention_bias)
        self.v_proj = nn.Linear(self.hidden_size, self.num_key_value_heads * self.head_dim, bias=config.attention_bias)
        self.o_proj = nn.Linear(self.head_dim * self.num_heads, self.hidden_size, bias=config.attention_bias)
        self.rotary_emb = V4XRotaryEmbedding(config=config)

        self._init_v4x(config, layer_idx)

    def forward(
        self,
        hidden_states: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        past_key_value: Optional[HybridMambaAttentionDynamicCache] = None,
        output_attentions: bool = False,
        use_cache: bool = False,
        cache_position: Optional[torch.LongTensor] = None,
        **kwargs,
    ):
        bsz, q_len, _ = hidden_states.size()
        query_states = self.q_proj(hidden_states)
        key_states = self.k_proj(hidden_states)
        value_states = self.v_proj(hidden_states)

        query_states = query_states.view(bsz, q_len, self.num_heads, self.head_dim).transpose(1, 2)
        key_states = key_states.view(bsz, q_len, self.num_key_value_heads, self.head_dim).transpose(1, 2)
        value_states = value_states.view(bsz, q_len, self.num_key_value_heads, self.head_dim).transpose(1, 2)

        cos, sin = self.rotary_emb(value_states, position_ids)
        query_states, key_states = apply_rotary_pos_emb(query_states, key_states, cos, sin)

        if past_key_value is not None:
            key_states, value_states = past_key_value.update(key_states, value_states, self.layer_idx)

        key_states = repeat_kv(key_states, self.num_key_value_groups)
        value_states = repeat_kv(value_states, self.num_key_value_groups)

        attn_weights = torch.matmul(query_states, key_states.transpose(2, 3)) / math.sqrt(self.head_dim)

        if attention_mask is not None:
            attn_weights = attn_weights + attention_mask[:, :, :, : key_states.shape[-2]]
        elif q_len > 1:
            # causal manual (prefill sin padding y sin máscara explícita)
            kv_len = key_states.shape[-2]
            min_dtype = torch.finfo(attn_weights.dtype).min
            causal = torch.triu(
                torch.full((q_len, kv_len), min_dtype, device=attn_weights.device, dtype=attn_weights.dtype),
                diagonal=1 + (kv_len - q_len),
            )
            attn_weights = attn_weights + causal[None, None, :, :]

        attn_weights = F.softmax(attn_weights, dim=-1, dtype=torch.float32).to(query_states.dtype)
        attn_weights = F.dropout(
            attn_weights, p=self.attention_dropout if self.training else 0.0, training=self.training
        )
        attn_output = torch.matmul(attn_weights, value_states)

        attn_output = attn_output.transpose(1, 2).contiguous()
        attn_output = attn_output.view(bsz, q_len, self.num_heads * self.head_dim)
        attn_output = self.o_proj(attn_output)

        return attn_output, attn_weights if output_attentions else None, past_key_value


class NemotronHSdpaAttention(NemotronHAttention):
    def forward(
        self,
        hidden_states: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        past_key_value: Optional[HybridMambaAttentionDynamicCache] = None,
        output_attentions: bool = False,
        use_cache: bool = False,
        cache_position: Optional[torch.LongTensor] = None,
        **kwargs,
    ):
        if output_attentions:
            logger.warning_once("V4X/SDPA no soporta output_attentions=True; usando eager.")
            return super().forward(
                hidden_states=hidden_states,
                attention_mask=attention_mask,
                position_ids=position_ids,
                past_key_value=past_key_value,
                output_attentions=output_attentions,
                use_cache=use_cache,
                cache_position=cache_position,
            )

        bsz, q_len, _ = hidden_states.size()
        query_states = self.q_proj(hidden_states)
        key_states = self.k_proj(hidden_states)
        value_states = self.v_proj(hidden_states)

        query_states = query_states.view(bsz, q_len, self.num_heads, self.head_dim).transpose(1, 2)
        key_states = key_states.view(bsz, q_len, self.num_key_value_heads, self.head_dim).transpose(1, 2)
        value_states = value_states.view(bsz, q_len, self.num_key_value_heads, self.head_dim).transpose(1, 2)

        cos, sin = self.rotary_emb(value_states, position_ids)
        query_states, key_states = apply_rotary_pos_emb(query_states, key_states, cos, sin)

        if past_key_value is not None:
            key_states, value_states = past_key_value.update(key_states, value_states, self.layer_idx)

        # FIX-02b (V1): con GQA nativo NO se materializa repeat_kv (16x menos VRAM de KV).
        # Matematica identica: cada cabeza Q atiende a su cabeza KV de grupo (misma semantica).
        _use_gqa = _GQA_SDPA and self.num_key_value_groups > 1 and query_states.is_cuda
        if not _use_gqa:
            key_states = repeat_kv(key_states, self.num_key_value_groups)
            value_states = repeat_kv(value_states, self.num_key_value_groups)

        causal_mask = attention_mask
        if attention_mask is not None:
            causal_mask = causal_mask[:, :, :, : key_states.shape[-2]]

        if query_states.device.type == "cuda" and attention_mask is not None and not _use_gqa:
            query_states = query_states.contiguous()
            key_states = key_states.contiguous()
            value_states = value_states.contiguous()

        is_causal = True if causal_mask is None and q_len > 1 else False
        _sdpa_kwargs = dict(
            attn_mask=causal_mask,
            dropout_p=self.attention_dropout if self.training else 0.0,
            is_causal=is_causal,
        )
        if _use_gqa:
            _sdpa_kwargs["enable_gqa"] = True
        attn_output = F.scaled_dot_product_attention(
            query_states,
            key_states,
            value_states,
            **_sdpa_kwargs,
        )
        attn_output = attn_output.transpose(1, 2).contiguous()
        attn_output = attn_output.view(bsz, q_len, self.num_heads * self.head_dim)
        attn_output = self.o_proj(attn_output)
        return attn_output, None, past_key_value


class NemotronHFlashAttention2(NemotronHAttention):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._flash_attn_uses_top_left_mask = True  # seguridad; FA2 >= 2.1 usa bottom-right

    def forward(
        self,
        hidden_states: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        past_key_value: Optional[HybridMambaAttentionDynamicCache] = None,
        output_attentions: bool = False,
        use_cache: bool = False,
        cache_position: Optional[torch.LongTensor] = None,
        **kwargs,
    ):
        if _flash_attention_forward is None:
            return NemotronHSdpaAttention.forward(
                self,
                hidden_states=hidden_states,
                attention_mask=attention_mask,
                position_ids=position_ids,
                past_key_value=past_key_value,
                output_attentions=output_attentions,
                use_cache=use_cache,
                cache_position=cache_position,
            )

        bsz, q_len, _ = hidden_states.size()
        query_states = self.q_proj(hidden_states)
        key_states = self.k_proj(hidden_states)
        value_states = self.v_proj(hidden_states)

        query_states = query_states.view(bsz, q_len, self.num_heads, self.head_dim)
        key_states = key_states.view(bsz, q_len, self.num_key_value_heads, self.head_dim).transpose(1, 2)
        value_states = value_states.view(bsz, q_len, self.num_key_value_heads, self.head_dim).transpose(1, 2)

        cos, sin = self.rotary_emb(value_states, position_ids)
        query_states, key_states = apply_rotary_pos_emb(query_states, key_states, cos, sin, unsqueeze_dim=2)

        if past_key_value is not None:
            key_states, value_states = past_key_value.update(key_states, value_states, self.layer_idx)

        query_states = query_states.transpose(1, 2)
        input_dtype = query_states.dtype
        if input_dtype == torch.float32:
            target_dtype = self.q_proj.weight.dtype
            query_states = query_states.to(target_dtype)
            key_states = key_states.to(target_dtype)
            value_states = value_states.to(target_dtype)

        attn_output = _flash_attention_forward(
            query_states,
            key_states,
            value_states,
            attention_mask,
            q_len,
            dropout=0.0 if not self.training else self.attention_dropout,
            is_causal=self.is_causal,
        )
        attn_output = attn_output.reshape(bsz, q_len, self.num_heads * self.head_dim).contiguous()
        attn_output = self.o_proj(attn_output)
        return attn_output, None, past_key_value


V4X_ATTENTION_CLASSES = {
    "eager": NemotronHAttention,
    "sdpa": NemotronHSdpaAttention,
}


# ═══════════════════════════════════════════════════════════════════════════
# SECCIÓN 6 — MoE (base Nemotron + extensión V4X)
# ═══════════════════════════════════════════════════════════════════════════

class NemotronHMOE(V4XExpertsMixin, nn.Module):
    """MoE Nemotron + expertos V4X del store + v4x_router según la capa.

    Estructura (verificada contra el índice del checkpoint):
      - gate          : router original Nemotron [128, hidden] + e_score_correction_bias
      - shared_experts: relu2 (up/down 3712)
      - V4X.experts.1-128   : base Nemotron relu2 (up/down 1856)  [vive en block.V4X]
      - V4X.experts.129-176 : Qwen silu (768), capas 18..47       [vive en block.V4X]
      - V4X.experts.177     : Phi silu (17920), capas 18..39       [vive en block.V4X]
      - v4x_router    : router unificado [dim, hidden], capas 17..51
    """

    def __init__(self, config: V4XConfig, layer_idx: Optional[int] = None):
        super().__init__()
        self.config = config
        self.layer_idx = layer_idx
        self.gate = NemotronHTopkRouter(config, num_experts=config.base_num_experts)
        self.shared_experts = NemotronHMLP(
            config=config, intermediate_size=config.moe_shared_expert_intermediate_size, layer_idx=layer_idx
        )
        self._init_v4x(config, layer_idx)

    def _moe(self, hidden_states, topk_indices, topk_weights):
        """Loop de expertos base (estilo Nemotron original). hidden_states: [tokens, h]."""
        final_hidden_states = torch.zeros_like(hidden_states, dtype=topk_weights.dtype)
        expert_mask = F.one_hot(topk_indices, num_classes=self.config.base_num_experts)
        expert_mask = expert_mask.permute(2, 0, 1)
        experts = self.v4x_store.experts
        for expert_idx in range(self.config.base_num_experts):
            expert = experts[expert_idx + 1]
            mask = expert_mask[expert_idx]
            token_indices, weight_indices = torch.where(mask)
            if token_indices.numel() > 0:
                expert_weights = topk_weights[token_indices, weight_indices]
                expert_input = hidden_states[token_indices]
                expert_output = expert(expert_input)
                weighted_output = expert_output * expert_weights.unsqueeze(-1)
                final_hidden_states.index_add_(0, token_indices, weighted_output.to(final_hidden_states.dtype))
        return final_hidden_states.type(hidden_states.dtype)

    def forward(self, hidden_states):
        normed_input = hidden_states  # el Block ya aplicó la norma: esta es la entrada del mixer
        orig_shape = hidden_states.shape
        mode = self.config.v4x_routing_mode

        # ── unified: v4x_router SUSTITUYE al gate (base + new; shared aparte) ──
        if mode == "unified" and self.v4x_router is not None:
            flat = hidden_states.reshape(-1, hidden_states.shape[-1])
            valid = self._v4x_valid_rows(is_moe_layer=True)  # base(0..127) + new(129..), sin shared
            topk_indices, topk_weights = self.v4x_router(flat.to(torch.float32), valid_rows=valid)
            routed = torch.zeros(flat.shape[0], flat.shape[1], dtype=topk_weights.dtype, device=flat.device)
            experts = self.v4x_store.experts
            for j in range(self.config.base_num_experts):
                sel = topk_indices == j
                if sel.any():
                    tok, k = torch.where(sel)
                    w = topk_weights[tok, k].to(flat.dtype)
                    # HYP-3/EXP-D2 (104) + CAZA #31 (casa, 19-oct): congelados bajo
                    # no_grad y inputs detacheados → valor bit-idéntico, CERO grafo.
                    if _flag_hyp3() and not _v4x_exp_trainable(experts[j + 1]):
                        with torch.no_grad():
                            y = (experts[j + 1](flat[tok].detach()) * w.detach().unsqueeze(-1)).to(routed.dtype)
                    else:
                        y = (experts[j + 1](flat[tok]) * w.unsqueeze(-1)).to(routed.dtype)
                    routed.index_add_(0, tok, y)
            if self._v4x_n_routable > 0:
                routed += self._v4x_dispatch_new_experts(flat, topk_indices, topk_weights)
            hidden_states = routed.view(*orig_shape).to(normed_input.dtype)
            hidden_states = hidden_states + self.shared_experts(normed_input)
            return hidden_states

        # ── base Nemotron (off) o base + rama paralela (parallel) ──
        topk_indices, topk_weights = self.gate(hidden_states)
        hidden_states = hidden_states.reshape(-1, hidden_states.shape[-1])
        hidden_states = self._moe(hidden_states, topk_indices, topk_weights).view(*orig_shape)
        hidden_states = hidden_states + self.shared_experts(normed_input)

        if mode == "parallel" and self.v4x_router is not None and self._v4x_n_routable > 0:
            flat = normed_input.reshape(-1, normed_input.shape[-1])
            valid = self._v4x_valid_rows(is_moe_layer=False)  # solo new experts
            topk_indices, topk_weights = self.v4x_router(flat.to(torch.float32), valid_rows=valid)
            branch = self._v4x_dispatch_new_experts(flat, topk_indices, topk_weights)
            hidden_states = hidden_states + branch.view(*orig_shape).to(hidden_states.dtype)
        return hidden_states


# ═══════════════════════════════════════════════════════════════════════════
# SECCIÓN 7 — Bloque y backbone
# ═══════════════════════════════════════════════════════════════════════════

class NemotronHBlock(nn.Module):
    def __init__(self, config, layer_idx):
        super().__init__()
        self.config = config
        self.layer_idx = layer_idx
        self.residual_in_fp32 = config.residual_in_fp32
        self.norm = NemotronHRMSNorm(config.hidden_size, eps=config.layer_norm_epsilon)

        self.block_type = config.layers_block_type[layer_idx]
        if self.block_type == "mamba":
            self.mixer = NemotronHMamba2Mixer(config, layer_idx=layer_idx)
        elif self.block_type == "attention":
            attn_impl = getattr(config, "_attn_implementation", None) or "eager"
            if attn_impl not in V4X_ATTENTION_CLASSES:
                attn_impl = "sdpa"
            self.mixer = V4X_ATTENTION_CLASSES[attn_impl](config, layer_idx=layer_idx)
        elif self.block_type == "mlp":
            self.mixer = NemotronHMLP(config, layer_idx=layer_idx)
        elif self.block_type == "moe":
            self.mixer = NemotronHMOE(config, layer_idx=layer_idx)
        else:
            raise ValueError(f"Invalid layer pattern {config.hybrid_override_pattern[layer_idx]}")

        # Expertos del checkpoint: viven en `backbone.layers.L.V4X.experts.{idx}`
        # (NO en el mixer). El mixer obtiene la referencia mediante `v4x_store`.
        # Se asigna con object.__setattr__ para NO registrar el store dos veces
        # en _modules (si no, state_dict duplicaría `mixer.v4x_store.experts`).
        self.V4X = V4XExpertsStore(config, layer_idx, block_type=self.block_type)
        object.__setattr__(self.mixer, "v4x_store", self.V4X)

    def forward(
        self,
        hidden_states,
        cache_params: Optional[HybridMambaAttentionDynamicCache] = None,
        cache_position: Optional[torch.LongTensor] = None,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
    ):
        residual = hidden_states
        normed = self.norm(hidden_states)
        if self.residual_in_fp32:
            residual = residual.to(torch.float32)

        # HYP-4 (104): LOOKAHEAD del router ANTES del mixer. El routing depende solo
        # de `normed` (idéntico resultado); libera una ventana para que el motor P2
        # prefetché los expertos por PCIe (hook `_h2d_prefetch_cb`, opcional).
        topk_pre = None
        if (
            _flag_hyp4()
            and self.config.v4x_routing_mode in ("parallel", "unified")
            and self.block_type in ("mamba", "attention")
            and getattr(self.mixer, "v4x_router", None) is not None
            and self.mixer._v4x_n_routable > 0
        ):
            _flat_pre = normed.reshape(-1, normed.shape[-1]).to(torch.float32)
            topk_pre = self.mixer.v4x_router(
                _flat_pre, valid_rows=self.mixer._v4x_valid_rows(is_moe_layer=False)
            )
            _cb = getattr(self.mixer, "_h2d_prefetch_cb", None)
            if _cb is not None:
                _cb(topk_pre[0])

        if self.block_type == "mamba":
            out = self.mixer(
                normed, cache_params=cache_params, cache_position=cache_position, attention_mask=attention_mask
            )
        elif self.block_type == "attention":
            out = self.mixer(
                normed,
                attention_mask=attention_mask,
                position_ids=position_ids,
                past_key_value=cache_params,
                cache_position=cache_position,
            )[0]
        elif self.block_type == "mlp":
            out = self.mixer(normed)
        elif self.block_type == "moe":
            out = self.mixer(normed)
        else:
            raise ValueError(f"Invalid block_type: {self.block_type}")

        # rama V4X paralela para capas NO-MoE (modos parallel/unified), semántica
        # del modeling original: rama sobre el hidden normalizado, salida aditiva.
        if (
            self.config.v4x_routing_mode in ("parallel", "unified")
            and self.block_type in ("mamba", "attention")
        ):
            branch = self.mixer.v4x_experts_forward(normed, precomputed=topk_pre)
            if branch is not None:
                out = out + branch

        hidden_states = residual + out
        return hidden_states


@dataclass
class V4XOutput(ModelOutput):
    last_hidden_state: Optional[torch.FloatTensor] = None
    cache_params: Optional[HybridMambaAttentionDynamicCache] = None
    hidden_states: Optional[Tuple[torch.FloatTensor]] = None
    attentions: Optional[Tuple[torch.FloatTensor]] = None


@dataclass
class V4XCausalLMOutput(ModelOutput):
    loss: Optional[torch.FloatTensor] = None
    logits: Optional[torch.FloatTensor] = None
    past_key_values: Optional[HybridMambaAttentionDynamicCache] = None
    cache_params: Optional[HybridMambaAttentionDynamicCache] = None
    hidden_states: Optional[Tuple[torch.FloatTensor]] = None
    attentions: Optional[Tuple[torch.FloatTensor]] = None


class NemotronHPreTrainedModel(PreTrainedModel):
    config_class = V4XConfig
    base_model_prefix = "backbone"
    _no_split_modules = [
        "NemotronHBlock",
        "V4XWhisperEncoderLayer",
        "V4XWhisperDecoderLayer",
        "V4XMERTLayer",
        "V4XQwen3AudioEncoderLayer",
        "V4XQwen3VisionBlock",
    ]
    supports_gradient_checkpointing = True
    _supports_cache_class = True
    _is_stateful = True

    @classmethod
    def _supports_default_dynamic_cache(cls):
        """La caché híbrida (mamba+atención) la crea `prepare_inputs_for_generation`
        (ruta oficial para modelos tipo mamba/zamba en transformers 5.x)."""
        return False

    def _init_weights(self, module):
        """Inicialización (el checkpoint manda; esto solo cubre pesos no cargados)."""
        std = self.config.initializer_range

        if isinstance(module, NemotronHMamba2Mixer):
            if getattr(module.dt_bias, "_is_hf_initialized", False):
                return
            module.A_log._no_weight_decay = True
            module.D._no_weight_decay = True
            dt = torch.exp(
                torch.rand(self.config.mamba_num_heads)
                * (math.log(self.config.time_step_max) - math.log(self.config.time_step_min))
                + math.log(self.config.time_step_min)
            ).clamp(min=self.config.time_step_floor)
            inv_dt = dt + torch.log1p(-torch.exp(-dt)) if False else dt + torch.log(-torch.expm1(-dt))
            with torch.no_grad():
                module.dt_bias.copy_(inv_dt)
            module.dt_bias._no_reinit = True

        if isinstance(module, nn.Linear):
            if module.bias is not None and not getattr(module.bias, "_no_reinit", False):
                nn.init.zeros_(module.bias)
            nn.init.normal_(module.weight, mean=0.0, std=std)
        elif isinstance(module, nn.Embedding):
            nn.init.normal_(module.weight, mean=0.0, std=std)
        elif isinstance(module, (V4XRouter, NemotronHTopkRouter)):
            nn.init.normal_(module.weight, mean=0.0, std=std)
            if hasattr(module, "e_score_correction_bias"):
                nn.init.zeros_(module.e_score_correction_bias)

        if self.config.rescale_prenorm_residual:
            for name, p in module.named_parameters():
                if getattr(p, "_is_hf_initialized", False):
                    continue
                if name in ["out_proj.weight"]:
                    nn.init.kaiming_uniform_(p, a=math.sqrt(5))
                    with torch.no_grad():
                        p /= math.sqrt(self.config.num_hidden_layers)


class NemotronHModel(NemotronHPreTrainedModel):
    """Backbone lingüístico V4X (Nemotron-H híbrido: mamba2/attention/moe)."""

    def __init__(self, config):
        super().__init__(config)
        self.embeddings = nn.Embedding(config.vocab_size, config.hidden_size)
        self.layers = nn.ModuleList(
            [NemotronHBlock(config, layer_idx=idx) for idx in range(config.num_hidden_layers)]
        )
        self.gradient_checkpointing = False
        self.norm_f = NemotronHRMSNorm(config.hidden_size, eps=config.layer_norm_epsilon)
        self.post_init()

    def get_input_embeddings(self):
        return self.embeddings

    def set_input_embeddings(self, new_embeddings):
        self.embeddings = new_embeddings

    def forward(
        self,
        input_ids=None,
        inputs_embeds=None,
        position_ids=None,
        cache_params=None,
        use_cache=None,
        output_attentions=None,
        output_hidden_states=None,
        return_dict=None,
        cache_position=None,
        attention_mask=None,
        **kwargs,
    ):
        output_attentions = output_attentions if output_attentions is not None else self.config.output_attentions
        output_hidden_states = (
            output_hidden_states if output_hidden_states is not None else self.config.output_hidden_states
        )
        use_cache = use_cache if use_cache is not None else (self.config.use_cache and not self.training)
        return_dict = return_dict if return_dict is not None else self.config.use_return_dict

        if (input_ids is None) == (inputs_embeds is None):
            raise ValueError("Debes especificar exactamente uno de input_ids o inputs_embeds")

        if inputs_embeds is None:
            inputs_embeds = self.embeddings(input_ids)

        if self.gradient_checkpointing and self.training and use_cache:
            logger.warning_once("`use_cache=True` es incompatible con gradient checkpointing. Desactivando caché.")
            use_cache = False

        batch_size, seq_len = inputs_embeds.shape[:2]

        if use_cache and cache_params is None:
            cache_params = HybridMambaAttentionDynamicCache(
                self.config, batch_size, inputs_embeds.dtype, device=inputs_embeds.device
            )

        if cache_position is None:
            past_len = 0
            if cache_params is not None and cache_params.has_previous_state:
                past_len = cache_params.get_seq_length()
            cache_position = torch.arange(past_len, past_len + seq_len, device=inputs_embeds.device)
            _past0 = past_len   # Fuga 6 (ARGON/96): past_len ya es int -> 0 syncs
        else:
            _past0 = None
        if position_ids is None:
            position_ids = cache_position.unsqueeze(0).expand(batch_size, -1)
        position_ids = position_ids.long()

        # máscaras por tipo de capa
        causal_mask = self._update_causal_mask(
            attention_mask, seq_len,
            _past0 if _past0 is not None else int(cache_position[0].item()),
            inputs_embeds.dtype, inputs_embeds.device, batch_size
        )
        mamba_mask = attention_mask
        if mamba_mask is not None:
            if bool(torch.all(mamba_mask == 1)):
                mamba_mask = None
            elif mamba_mask.shape[1] != seq_len:
                # decode: la máscara crece con generate(); recortar al input actual
                mamba_mask = mamba_mask[:, -seq_len:]

        hidden_states = inputs_embeds
        all_hidden_states = () if output_hidden_states else None
        all_self_attns = () if output_attentions else None

        for mixer_block in self.layers:
            if mixer_block.block_type == "mamba":
                layer_mask = mamba_mask
            elif mixer_block.block_type == "attention":
                layer_mask = causal_mask
            else:
                layer_mask = None

            if output_hidden_states:
                all_hidden_states += (hidden_states,)

            # OPT-1 (104): prefijo congelado bajo no_grad+sin ckpt. La celda fija
            # `_first_grad_layer > 0` SOLO en tandas de experto (slot != None):
            # en emb/attn/shared cortaría el grafo a los entrenables de abajo.
            _opt1 = (
                _flag_opt1()
                and self.training
                and mixer_block.layer_idx < getattr(self, "_first_grad_layer", 0)
            )
            # CAZA #30 (casa, 19-oct): al cruzar _first_grad_layer, hidden_states
            # viene del prefijo entero bajo no_grad → requires_grad=False; checkpoint
            # reentrante sin inputs-con-grad = backward roto (warning PyTorch).
            # Reenganchar la hoja exactamente en la frontera:
            if (
                _flag_opt1()
                and self.training
                and getattr(self, "_first_grad_layer", 0) > 0
                and mixer_block.layer_idx == self._first_grad_layer
                and not hidden_states.requires_grad
            ):
                hidden_states = hidden_states.requires_grad_(True)
            if _opt1:
                with torch.no_grad():
                    hidden_states = mixer_block(
                        hidden_states,
                        cache_params=cache_params,
                        cache_position=cache_position,
                        attention_mask=layer_mask,
                        position_ids=position_ids,
                    )
            elif self.gradient_checkpointing and self.training and not (
                _V4X_FLAG_HYP1 and mixer_block.block_type == "moe"
            ):
                # HYP-1 (104): MoE sin recompute bajo gate VRAM <=13.800 MiB (104).
                hidden_states = self._gradient_checkpointing_func(
                    mixer_block.__call__, hidden_states, cache_params, cache_position, layer_mask, position_ids
                )
            else:
                hidden_states = mixer_block(
                    hidden_states,
                    cache_params=cache_params,
                    cache_position=cache_position,
                    attention_mask=layer_mask,
                    position_ids=position_ids,
                )

        hidden_states = self.norm_f(hidden_states)

        if output_hidden_states:
            all_hidden_states += (hidden_states,)

        if not return_dict:
            return tuple(v for v in [hidden_states, cache_params, all_hidden_states, all_self_attns] if v is not None)
        return V4XOutput(
            last_hidden_state=hidden_states,
            cache_params=cache_params if use_cache else None,
            hidden_states=all_hidden_states,
            attentions=all_self_attns,
        )

    def _update_causal_mask(self, attention_mask, q_len, past_len, dtype, device, batch_size):
        """Máscara causal 4D autocontenida (transformers 5.x ya no expone el helper).

        - attention_mask None -> None (SDPA is_causal en prefill; decode q=1 atiende todo).
        - attention_mask 2D [bsz, total] -> causal + padding 4D [bsz, 1, q, total].
        """
        if attention_mask is None:
            return None
        # FIX-03 (V2): sin padding en ninguna fase -> nunca construir la 4D O(T^2):
        # past_len==0 -> prefill puro (SDPA usa is_causal); q_len==1 -> decode atiende a todo.
        if bool(torch.all(attention_mask == 1)) and (past_len == 0 or q_len == 1):
            return None
        min_dtype = torch.finfo(dtype).min
        total = attention_mask.shape[-1]
        causal = torch.full((q_len, total), min_dtype, dtype=dtype, device=device)
        causal = torch.triu(causal, diagonal=1 + past_len)
        causal = causal[None, None, :, :].expand(batch_size, 1, -1, -1)
        pad = (1.0 - attention_mask.to(dtype))[:, None, None, :] * min_dtype
        return causal + pad


# ═══════════════════════════════════════════════════════════════════════════
# SECCIÓN 8 — ENCODER: Whisper large-v3 (encoder + decoder)
#   Quirks del checkpoint: SIN k_proj.bias (96 atenciones) y SIN proj_out.
# ═══════════════════════════════════════════════════════════════════════════

def _sinusoids(length, channels, max_timescale=10000):
    """Posiciones sinusoidales (Whisper/Qwen3-Omni): [length, channels]."""
    if channels % 2 != 0:
        raise ValueError("channels debe ser par")
    log_timescale_increment = math.log(max_timescale) / (channels // 2 - 1)
    inv_timescales = torch.exp(-log_timescale_increment * torch.arange(channels // 2).float())
    scaled_time = torch.arange(length)[:, None].float() * inv_timescales[None, :]
    return torch.cat([torch.sin(scaled_time), torch.cos(scaled_time)], dim=1)


class V4XWhisperAttention(nn.Module):
    """Atención Whisper con la firma de bias del checkpoint V4X:
    q/v/out CON bias, k SIN bias (igual que Whisper oficial)."""

    def __init__(self, embed_dim, num_heads, k_bias=False, is_decoder=False):
        super().__init__()
        self.embed_dim = embed_dim
        self.num_heads = num_heads
        self.head_dim = embed_dim // num_heads
        self.scaling = self.head_dim**-0.5
        self.is_decoder = is_decoder
        self.q_proj = nn.Linear(embed_dim, embed_dim, bias=True)
        self.k_proj = nn.Linear(embed_dim, embed_dim, bias=k_bias)
        self.v_proj = nn.Linear(embed_dim, embed_dim, bias=True)
        self.out_proj = nn.Linear(embed_dim, embed_dim, bias=True)

    def _shape(self, tensor, seq_len, bsz):
        return tensor.view(bsz, seq_len, self.num_heads, self.head_dim).transpose(1, 2).contiguous()

    def forward(self, hidden_states, key_value_states=None, attention_mask=None):
        bsz, tgt_len, _ = hidden_states.size()
        is_cross = key_value_states is not None
        query_states = self.q_proj(hidden_states) * self.scaling  # q pre-escalada (Whisper)
        if is_cross:
            key_states = self._shape(self.k_proj(key_value_states), -1, bsz)
            value_states = self._shape(self.v_proj(key_value_states), -1, bsz)
        else:
            key_states = self._shape(self.k_proj(hidden_states), -1, bsz)
            value_states = self._shape(self.v_proj(hidden_states), -1, bsz)
        query_states = self._shape(query_states, tgt_len, bsz)

        proj_shape = (bsz * self.num_heads, -1, self.head_dim)
        query_states = query_states.reshape(*proj_shape)
        key_states = key_states.reshape(*proj_shape)
        value_states = value_states.reshape(*proj_shape)

        src_len = key_states.size(1)
        attn_weights = torch.bmm(query_states, key_states.transpose(1, 2))
        if attn_weights.size() != (bsz * self.num_heads, tgt_len, src_len):
            raise ValueError(f"Shape de attn_weights incorrecta: {attn_weights.shape}")
        if attention_mask is not None:
            attn_weights = attn_weights.view(bsz, self.num_heads, tgt_len, src_len) + attention_mask
            attn_weights = attn_weights.view(bsz * self.num_heads, tgt_len, src_len)
        attn_weights = F.softmax(attn_weights, dim=-1)
        attn_output = torch.bmm(attn_weights, value_states)
        attn_output = attn_output.view(bsz, self.num_heads, tgt_len, self.head_dim)
        attn_output = attn_output.transpose(1, 2).contiguous().view(bsz, tgt_len, self.embed_dim)
        return self.out_proj(attn_output)


class V4XWhisperEncoderLayer(nn.Module):
    def __init__(self, config):
        super().__init__()
        d = config["d_model"]
        self.self_attn = V4XWhisperAttention(d, config["encoder_attention_heads"], k_bias=config["k_proj_bias"])
        self.self_attn_layer_norm = nn.LayerNorm(d)
        self.fc1 = nn.Linear(d, config["encoder_ffn_dim"])
        self.fc2 = nn.Linear(config["encoder_ffn_dim"], d)
        self.final_layer_norm = nn.LayerNorm(d)

    def forward(self, x, attention_mask=None):
        residual = x
        x = self.self_attn_layer_norm(x)
        x = self.self_attn(x, attention_mask=attention_mask)
        x = residual + x
        residual = x
        x = self.final_layer_norm(x)
        x = F.gelu(self.fc1(x))
        x = self.fc2(x)
        return residual + x


class V4XWhisperEncoder(nn.Module):
    def __init__(self, config):
        super().__init__()
        d = config["d_model"]
        self.conv1 = nn.Conv1d(config["num_mel_bins"], d, kernel_size=3, padding=1)
        self.conv2 = nn.Conv1d(d, d, kernel_size=3, stride=2, padding=1)
        self.embed_positions = nn.Embedding(config["max_source_positions"], d)
        self.layers = nn.ModuleList([V4XWhisperEncoderLayer(config) for _ in range(config["encoder_layers"])])
        self.layer_norm = nn.LayerNorm(d)

    def forward(self, input_features, attention_mask=None):
        # input_features: [bsz, n_mels(128), T] log-mel (WhisperFeatureExtractor)
        inputs_embeds = F.gelu(self.conv1(input_features))
        inputs_embeds = F.gelu(self.conv2(inputs_embeds))
        bsz, _, tgt_len = inputs_embeds.size()
        pos = self.embed_positions.weight[:tgt_len, :].unsqueeze(0)
        hidden = inputs_embeds.transpose(1, 2) + pos.to(inputs_embeds.dtype)
        mask = None
        if attention_mask is not None:
            down = attention_mask[:, ::2][:, :tgt_len]
            if not bool(torch.all(down == 1)):
                mask = (1.0 - down.to(hidden.dtype))[:, None, None, :] * torch.finfo(hidden.dtype).min
        for layer in self.layers:
            hidden = layer(hidden, attention_mask=mask)
        return self.layer_norm(hidden)


class V4XWhisperDecoderLayer(nn.Module):
    def __init__(self, config):
        super().__init__()
        d = config["d_model"]
        self.self_attn = V4XWhisperAttention(d, config["decoder_attention_heads"], k_bias=config["k_proj_bias"], is_decoder=True)
        self.self_attn_layer_norm = nn.LayerNorm(d)
        self.encoder_attn = V4XWhisperAttention(d, config["decoder_attention_heads"], k_bias=config["k_proj_bias"], is_decoder=True)
        self.encoder_attn_layer_norm = nn.LayerNorm(d)
        self.fc1 = nn.Linear(d, config["decoder_ffn_dim"])
        self.fc2 = nn.Linear(config["decoder_ffn_dim"], d)
        self.final_layer_norm = nn.LayerNorm(d)

    def forward(self, x, encoder_hidden, self_attn_mask=None, cross_attn_mask=None):
        residual = x
        x = self.self_attn_layer_norm(x)
        x = self.self_attn(x, attention_mask=self_attn_mask)
        x = residual + x
        residual = x
        x = self.encoder_attn_layer_norm(x)
        x = self.encoder_attn(x, key_value_states=encoder_hidden, attention_mask=cross_attn_mask)
        x = residual + x
        residual = x
        x = self.final_layer_norm(x)
        x = F.gelu(self.fc1(x))
        x = self.fc2(x)
        return residual + x


class V4XWhisperDecoder(nn.Module):
    def __init__(self, config):
        super().__init__()
        d = config["d_model"]
        self.embed_tokens = nn.Embedding(config["vocab_size"], d)
        self.embed_positions = nn.Embedding(config["max_target_positions"], d)
        self.layers = nn.ModuleList([V4XWhisperDecoderLayer(config) for _ in range(config["decoder_layers"])])
        self.layer_norm = nn.LayerNorm(d)

    def forward(self, input_ids, encoder_hidden, encoder_attention_mask=None):
        positions = torch.arange(input_ids.shape[-1], device=input_ids.device)
        hidden = self.embed_tokens(input_ids) + self.embed_positions(positions)[None, :, :].to(
            self.embed_tokens.weight.dtype
        )
        bsz, tgt_len = input_ids.shape
        causal = torch.full((tgt_len, tgt_len), torch.finfo(hidden.dtype).min, device=hidden.device)
        causal = torch.triu(causal, diagonal=1)[None, None, :, :]
        cross = None
        if encoder_attention_mask is not None and not bool(torch.all(encoder_attention_mask == 1)):
            cross = (1.0 - encoder_attention_mask.to(hidden.dtype))[:, None, None, :] * torch.finfo(hidden.dtype).min
        for layer in self.layers:
            hidden = layer(hidden, encoder_hidden, self_attn_mask=causal, cross_attn_mask=cross)
        return self.layer_norm(hidden)


class V4XWhisperInner(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.encoder = V4XWhisperEncoder(config)
        self.decoder = V4XWhisperDecoder(config)


class V4XWhisperModel(nn.Module):
    """Whisper large-v3 completo (encoder+decoder) con los pesos del checkpoint.

    Nota: el checkpoint NO incluye proj_out; para ASR se usan los hidden states
    del decoder (o un proj_out externo en runtime, categoría 3).
    """

    def __init__(self, config=None):
        super().__init__()
        from .configuration_v4x import DEFAULT_WHISPER_CONFIG

        self.config = dict(DEFAULT_WHISPER_CONFIG) if config is None else dict(config)
        self.model = V4XWhisperInner(self.config)

    @property
    def device(self):
        return self.model.encoder.conv1.weight.device

    def get_encoder(self):
        return self.model.encoder

    def get_decoder(self):
        return self.model.decoder

    def encode(self, input_features, attention_mask=None):
        return self.model.encoder(input_features, attention_mask=attention_mask)

    def decode(self, decoder_input_ids, encoder_hidden, encoder_attention_mask=None):
        return self.model.decoder(decoder_input_ids, encoder_hidden, encoder_attention_mask)

    def forward(self, input_features, decoder_input_ids=None, attention_mask=None):
        enc = self.encode(input_features, attention_mask=attention_mask)
        if decoder_input_ids is None:
            return enc
        return self.decode(decoder_input_ids, enc, attention_mask)


# ═══════════════════════════════════════════════════════════════════════════
# SECCIÓN 9 — ENCODER: MERT-v1-330M (música; HuBERT + attention_relax)
# ═══════════════════════════════════════════════════════════════════════════

class V4XMERTConvLayer(nn.Module):
    def __init__(self, config, layer_id=0):
        super().__init__()
        in_ch = 1 if layer_id == 0 else config["conv_dim"][layer_id - 1]
        self.conv = nn.Conv1d(
            in_ch,
            config["conv_dim"][layer_id],
            kernel_size=config["conv_kernel"][layer_id],
            stride=config["conv_stride"][layer_id],
            bias=config.get("conv_bias", False),
        )
        if layer_id == 0:
            # LN solo en la primera conv (do_stable_layer_norm=True)
            self.layer_norm = nn.LayerNorm(config["conv_dim"][layer_id])
        self.activation = ACT2FN[config.get("feat_extract_activation", "gelu")]

    def forward(self, hidden_states):
        hidden_states = self.conv(hidden_states)
        if hasattr(self, "layer_norm"):
            hidden_states = hidden_states.transpose(1, 2)
            hidden_states = self.layer_norm(hidden_states)
            hidden_states = hidden_states.transpose(1, 2)
        return self.activation(hidden_states)


class V4XMERTFeatureExtractor(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.conv_layers = nn.ModuleList(
            [V4XMERTConvLayer(config, layer_id=i) for i in range(config["num_feat_extract_layers"])]
        )

    def forward(self, input_values):
        hidden_states = input_values[:, None, :]  # [bsz, 1, T]
        for conv in self.conv_layers:
            hidden_states = conv(hidden_states)
        return hidden_states


class V4XMERTFeatureProjection(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.layer_norm = nn.LayerNorm(config["conv_dim"][-1], eps=config["layer_norm_eps"])
        self.projection = nn.Linear(config["conv_dim"][-1], config["hidden_size"], bias=True)

    def forward(self, hidden_states):
        hidden_states = hidden_states.transpose(1, 2)
        hidden_states = self.layer_norm(hidden_states)
        return self.projection(hidden_states)


class V4XMERTPositionalConvEmbedding(nn.Module):
    """Conv1d posicional con weight_norm -> claves weight_v/weight_g (checkpoint)."""

    def __init__(self, config):
        super().__init__()
        d = config["hidden_size"]
        self.conv = nn.Conv1d(
            d,
            d,
            kernel_size=config["num_conv_pos_embeddings"],
            padding=config["num_conv_pos_embeddings"] // 2,
            groups=config["num_conv_pos_embedding_groups"],
        )
        try:
            torch.nn.utils.weight_norm(self.conv, name="weight", dim=2)
        except Exception:
            # fallback manual (mismos nombres de parámetros weight_v/weight_g)
            weight = self.conv.weight
            del self.conv._parameters["weight"]
            self.conv.register_parameter("weight_v", nn.Parameter(weight.data.clone()))
            self.conv.register_parameter(
                "weight_g", nn.Parameter(weight.data.norm(dim=(0, 1), keepdim=True).squeeze().clone())
            )

            def _wn(conv):
                v, g = conv.weight_v, conv.weight_g
                norm = v.norm(dim=(0, 1), keepdim=True) + 1e-8
                conv.weight = g.view(-1, 1, 1) * (v / norm)

            self._recompute = _wn

        self.activation = ACT2FN[config.get("feat_extract_activation", "gelu")]
        self.num_pad_remove = 1 if config["num_conv_pos_embeddings"] % 2 == 0 else 0

    def forward(self, hidden_states):
        if hasattr(self, "_recompute"):
            self._recompute(self.conv)
        hidden_states = hidden_states.transpose(1, 2)
        x = self.conv(hidden_states)
        if self.num_pad_remove > 0:
            x = x[:, :, : -self.num_pad_remove]
        x = self.activation(x)
        return x.transpose(1, 2)


class V4XMERTAttention(nn.Module):
    """Atención HuBERT con `attention_relax` (suma alpha a los pesos pre-softmax)
    y q pre-escalada (head_dim^-0.5)."""

    def __init__(self, config):
        super().__init__()
        d = config["hidden_size"]
        self.embed_dim = d
        self.num_heads = config["num_attention_heads"]
        self.head_dim = d // self.num_heads
        self.scaling = self.head_dim**-0.5
        self.attention_relax = config.get("attention_relax", -1.0)
        self.q_proj = nn.Linear(d, d, bias=True)
        self.k_proj = nn.Linear(d, d, bias=True)
        self.v_proj = nn.Linear(d, d, bias=True)
        self.out_proj = nn.Linear(d, d, bias=True)

    def _shape(self, tensor, seq_len, bsz):
        return tensor.view(bsz, seq_len, self.num_heads, self.head_dim).transpose(1, 2).contiguous()

    def forward(self, hidden_states, attention_mask=None):
        bsz, tgt_len, _ = hidden_states.size()
        query_states = self._shape(self.q_proj(hidden_states) * self.scaling, tgt_len, bsz)
        key_states = self._shape(self.k_proj(hidden_states), -1, bsz)
        value_states = self._shape(self.v_proj(hidden_states), -1, bsz)
        proj_shape = (bsz * self.num_heads, -1, self.head_dim)
        query_states = query_states.reshape(*proj_shape)
        key_states = key_states.reshape(*proj_shape)
        value_states = value_states.reshape(*proj_shape)
        attn_weights = torch.bmm(query_states, key_states.transpose(1, 2))
        if attention_mask is not None:
            attn_weights = attn_weights.view(bsz, self.num_heads, tgt_len, -1) + attention_mask
            attn_weights = attn_weights.view(bsz * self.num_heads, tgt_len, -1)
        if self.attention_relax > 0:
            attn_weights = attn_weights + self.attention_relax
        attn_weights = F.softmax(attn_weights, dim=-1)
        attn_output = torch.bmm(attn_weights, value_states)
        attn_output = attn_output.view(bsz, self.num_heads, tgt_len, self.head_dim)
        attn_output = attn_output.transpose(1, 2).contiguous().view(bsz, tgt_len, self.embed_dim)
        return self.out_proj(attn_output)


class V4XMERTFeedForward(nn.Module):
    def __init__(self, config):
        super().__init__()
        d = config["hidden_size"]
        self.intermediate_dense = nn.Linear(d, config["intermediate_size"], bias=True)
        self.output_dense = nn.Linear(config["intermediate_size"], d, bias=True)
        self.activation = ACT2FN[config["hidden_act"]]

    def forward(self, x):
        return self.output_dense(self.activation(self.intermediate_dense(x)))


class V4XMERTLayer(nn.Module):
    def __init__(self, config):
        super().__init__()
        d = config["hidden_size"]
        self.attention = V4XMERTAttention(config)
        self.layer_norm = nn.LayerNorm(d, eps=config["layer_norm_eps"])
        self.feed_forward = V4XMERTFeedForward(config)
        self.final_layer_norm = nn.LayerNorm(d, eps=config["layer_norm_eps"])

    def forward(self, x, attention_mask=None):
        residual = x
        x = self.layer_norm(x)
        x = self.attention(x, attention_mask=attention_mask)
        x = residual + x
        residual = x
        x = self.final_layer_norm(x)
        x = self.feed_forward(x)
        return residual + x


class V4XMERTEncoder(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.pos_conv_embed = V4XMERTPositionalConvEmbedding(config)
        self.layer_norm = nn.LayerNorm(config["hidden_size"], eps=config["layer_norm_eps"])
        self.layers = nn.ModuleList([V4XMERTLayer(config) for _ in range(config["num_hidden_layers"])])

    def forward(self, hidden_states, attention_mask=None):
        x = hidden_states + self.pos_conv_embed(hidden_states)
        x = self.layer_norm(x)
        for layer in self.layers:
            x = layer(x, attention_mask=attention_mask)
        return x


class V4XMERTModel(nn.Module):
    """MERT-v1-330M: feature_extractor + feature_projection + encoder (24 capas)."""

    def __init__(self, config=None):
        super().__init__()
        from .configuration_v4x import DEFAULT_MERT_CONFIG

        self.config = dict(DEFAULT_MERT_CONFIG) if config is None else dict(config)
        c = self.config
        self.feature_extractor = V4XMERTFeatureExtractor(c)
        self.feature_projection = V4XMERTFeatureProjection(c)
        self.encoder = V4XMERTEncoder(c)
        self.masked_spec_embed = nn.Parameter(torch.FloatTensor(c["hidden_size"]).uniform_())

    @property
    def device(self):
        return self.masked_spec_embed.device

    def _get_feat_extract_output_lengths(self, input_lengths):
        """Longitudes exactas tras el extractor convolucional (fórmula HuBERT)."""
        for i in range(self.config["num_feat_extract_layers"]):
            input_lengths = (
                input_lengths - self.config["conv_kernel"][i]
            ) // self.config["conv_stride"][i] + 1
        return input_lengths

    def forward(self, input_values, attention_mask=None):
        """input_values: [bsz, T] float @24 kHz -> ModelOutput(last_hidden_state [bsz, T', 1024])."""
        extract = self.feature_extractor(input_values)
        hidden_states = self.feature_projection(extract)

        enc_mask = None
        if attention_mask is not None:
            lengths = self._get_feat_extract_output_lengths(attention_mask.long().sum(-1))
            max_len = hidden_states.shape[1]
            m = (torch.arange(max_len, device=hidden_states.device)[None, :] < lengths[:, None]).to(
                hidden_states.dtype
            )
            enc_mask = (1.0 - m)[:, None, None, :] * torch.finfo(hidden_states.dtype).min

        hidden_states = self.encoder(hidden_states, attention_mask=enc_mask)
        return ModelOutput(last_hidden_state=hidden_states)


# ═══════════════════════════════════════════════════════════════════════════
# SECCIÓN 11 — ENCODERS QWEN
#   Audio  (Qwen3-Omni): prefijo del checkpoint V4X_Audio.audio_tower.*
#   Visión (Qwen3-VL)  : prefijo del checkpoint V4X_Vision.visual.*
#                        (imagen Y vídeo; deepstack en los índices 8/16/24;
#                         merger de salida 4096 -> V4X_Vision.adapter.net.*)
# ═══════════════════════════════════════════════════════════════════════════

def _qwen3_audio_feat_lens(input_lengths: torch.Tensor) -> torch.Tensor:
    """Longitudes del audio tower tras las convs (fórmula oficial Qwen3-Omni)."""
    input_lengths_leave = input_lengths % 100
    feat_lengths = (input_lengths_leave - 1) // 2 + 1
    output_lengths = ((feat_lengths - 1) // 2 + 1 - 1) // 2 + 1 + (input_lengths // 100) * 13
    return output_lengths


class V4XQwen3AudioAttention(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.embed_dim = config["audio_d_model"]
        self.num_heads = config["audio_encoder_attention_heads"]
        self.head_dim = self.embed_dim // self.num_heads
        self.q_proj = nn.Linear(self.embed_dim, self.embed_dim, bias=True)
        self.k_proj = nn.Linear(self.embed_dim, self.embed_dim, bias=True)
        self.v_proj = nn.Linear(self.embed_dim, self.embed_dim, bias=True)
        self.out_proj = nn.Linear(self.embed_dim, self.embed_dim, bias=True)

    def forward(self, hidden_states, cu_seqlens):
        seq_length, _ = hidden_states.size()
        q = self.q_proj(hidden_states).reshape(seq_length, self.num_heads, -1).transpose(0, 1).unsqueeze(0)
        k = self.k_proj(hidden_states).reshape(seq_length, self.num_heads, -1).transpose(0, 1).unsqueeze(0)
        v = self.v_proj(hidden_states).reshape(seq_length, self.num_heads, -1).transpose(0, 1).unsqueeze(0)

        # atención por bloques definidos por cu_seqlens (sin flash-attn)
        lengths = (cu_seqlens[1:] - cu_seqlens[:-1]).tolist()
        qs, ks, vs = [torch.split(t, lengths, dim=2) for t in (q, k, v)]
        outs = [F.scaled_dot_product_attention(qq, kk, vv, is_causal=False) for qq, kk, vv in zip(qs, ks, vs)]
        attn_output = torch.cat(outs, dim=2)
        attn_output = attn_output.reshape(seq_length, -1).contiguous()
        return self.out_proj(attn_output)


class V4XQwen3AudioEncoderLayer(nn.Module):
    def __init__(self, config):
        super().__init__()
        d = config["audio_d_model"]
        self.self_attn = V4XQwen3AudioAttention(config)
        self.self_attn_layer_norm = nn.LayerNorm(d)
        self.fc1 = nn.Linear(d, config["audio_encoder_ffn_dim"])
        self.fc2 = nn.Linear(config["audio_encoder_ffn_dim"], d)
        self.final_layer_norm = nn.LayerNorm(d)
        self.act = ACT2FN[config["audio_activation_function"]]

    def forward(self, hidden_states, cu_seqlens):
        residual = hidden_states
        x = self.self_attn_layer_norm(hidden_states)
        x = self.self_attn(x, cu_seqlens=cu_seqlens)
        x = residual + x
        residual = x
        x = self.final_layer_norm(x)
        x = self.fc2(self.act(self.fc1(x)))
        x = residual + x
        if x.dtype == torch.float16:
            # clamp de seguridad (idéntico al código oficial)
            clamp_value = torch.finfo(x.dtype).max - 1000
            x = torch.clamp(x, min=-clamp_value, max=clamp_value)
        return x


class V4XQwen3AudioEncoder(nn.Module):
    """Audio tower de Qwen3-Omni (claves: V4X_Audio.audio_tower.*).

    conv2d1(1->480,s2) -> conv2d2(480->480,s2) -> conv2d3(480->480,s2) ->
    conv_out(7680->1280, sin bias) -> 32 capas (pos sinusoidales no param.) ->
    ln_post -> proj1(1280->1280) -> GELU -> proj2(1280->2048).
    """

    def __init__(self, config):
        super().__init__()
        c = config
        d = c["audio_d_model"]
        self.num_mel_bins = c["audio_num_mel_bins"]
        self.max_source_positions = c["audio_max_source_positions"]
        self.n_window = c["audio_n_window"]
        self.n_window_infer = c["audio_n_window_infer"]
        self.conv_chunksize = c["audio_conv_chunksize"]
        self.layers = nn.ModuleList(
            [V4XQwen3AudioEncoderLayer(c) for _ in range(c["audio_encoder_layers"])]
        )
        self.ln_post = nn.LayerNorm(d)
        self.conv2d1 = nn.Conv2d(1, c["audio_downsample_hidden_size"], 3, 2, padding=1)
        self.conv2d2 = nn.Conv2d(c["audio_downsample_hidden_size"], c["audio_downsample_hidden_size"], 3, 2, padding=1)
        self.conv2d3 = nn.Conv2d(c["audio_downsample_hidden_size"], c["audio_downsample_hidden_size"], 3, 2, padding=1)
        self.conv_out = nn.Linear(
            c["audio_downsample_hidden_size"] * ((((c["audio_num_mel_bins"] + 1) // 2 + 1) // 2 + 1) // 2),
            d,
            bias=False,
        )
        self.proj1 = nn.Linear(d, d)
        self.act = ACT2FN[c["audio_activation_function"]]
        self.proj2 = nn.Linear(d, c["audio_output_dim"])
        self.register_buffer("positional_embedding", _sinusoids(self.max_source_positions, d), persistent=False)

    def forward(self, input_features, feature_lens):
        """input_features: [128, T_total] log-mel 16 kHz; feature_lens: [bsz] (frames mel)."""
        aftercnn_lens = _qwen3_audio_feat_lens(feature_lens)
        chunk_num = torch.ceil(feature_lens / (self.n_window * 2)).long()

        chunk_lengths = torch.tensor(
            [self.n_window * 2] * int(chunk_num.sum()), dtype=torch.long, device=feature_lens.device
        )
        tail_chunk_index = F.pad(chunk_num, (1, 0), value=-1).cumsum(0)[1:]
        chunk_lengths[tail_chunk_index] = feature_lens % (self.n_window * 2)
        chunk_lengths[chunk_lengths == 0] = self.n_window * 2

        chunk_list = input_features.T.split(chunk_lengths.tolist(), dim=0)
        padded_feature = nn.utils.rnn.pad_sequence(chunk_list, batch_first=True).transpose(1, 2)
        feature_lens_after_cnn = _qwen3_audio_feat_lens(chunk_lengths)
        padded_mask_after_cnn = nn.utils.rnn.pad_sequence(
            [torch.ones(int(l), dtype=torch.bool, device=padded_feature.device) for l in feature_lens_after_cnn],
            batch_first=True,
        )
        padded_feature = padded_feature.unsqueeze(1)  # [n_chunks, 1, n_mels, T_chunk]

        # convs por trozos para evitar OOM
        padded_embeds = []
        for chunk in padded_feature.split(self.conv_chunksize, dim=0):
            e = F.gelu(self.conv2d1(chunk))
            e = F.gelu(self.conv2d2(e))
            e = F.gelu(self.conv2d3(e))
            padded_embeds.append(e)
        padded_embed = torch.cat(padded_embeds, dim=0)
        b, ch, f, t = padded_embed.size()
        padded_embed = self.conv_out(padded_embed.permute(0, 3, 1, 2).contiguous().view(b, t, ch * f))

        pos = self.positional_embedding[: padded_embed.shape[1], :].unsqueeze(0).to(padded_embed.dtype)
        padded_embed = padded_embed + pos
        hidden_states = padded_embed[padded_mask_after_cnn]

        # ventanas de atención (cu_seqlens)
        cu_chunk_lens = [0]
        window_aftercnn = padded_mask_after_cnn.shape[-1] * (self.n_window_infer // (self.n_window * 2))
        for cnn_len in aftercnn_lens:
            cu_chunk_lens += [window_aftercnn] * (int(cnn_len) // window_aftercnn)
            remainder = int(cnn_len) % window_aftercnn
            if remainder != 0:
                cu_chunk_lens += [remainder]
        cu_seqlens = torch.tensor(cu_chunk_lens, device=aftercnn_lens.device).cumsum(-1, dtype=torch.int32)

        for layer in self.layers:
            hidden_states = layer(hidden_states, cu_seqlens)

        hidden_states = self.ln_post(hidden_states)
        hidden_states = self.proj1(hidden_states)
        hidden_states = self.act(hidden_states)
        hidden_states = self.proj2(hidden_states)
        return ModelOutput(last_hidden_state=hidden_states)


class V4XQwen3AudioTower(nn.Module):
    """Wrapper: `V4X_Audio` contiene `.audio_tower` (encoder real)."""

    def __init__(self, config):
        super().__init__()
        self.audio_tower = V4XQwen3AudioEncoder(config)


class V4XQwen3VisionRotaryEmbedding(nn.Module):
    def __init__(self, dim, theta=10000.0):
        super().__init__()
        inv_freq = 1.0 / (theta ** (torch.arange(0, dim, 2, dtype=torch.float) / dim))
        self.register_buffer("inv_freq", inv_freq, persistent=False)

    def forward(self, seqlen: int) -> torch.Tensor:
        seq = torch.arange(seqlen, device=self.inv_freq.device, dtype=self.inv_freq.dtype)
        return torch.outer(seq, self.inv_freq)


def _vision_apply_rotary_pos_emb(q, k, cos, sin):
    orig_q_dtype, orig_k_dtype = q.dtype, k.dtype
    q, k = q.float(), k.float()
    cos, sin = cos.unsqueeze(-2).float(), sin.unsqueeze(-2).float()
    q_embed = (q * cos) + (rotate_half(q) * sin)
    k_embed = (k * cos) + (rotate_half(k) * sin)
    return q_embed.to(orig_q_dtype), k_embed.to(orig_k_dtype)


class V4XQwen3VisionAttention(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.dim = config["vision_hidden_size"]
        self.num_heads = config["vision_num_heads"]
        self.head_dim = self.dim // self.num_heads
        self.qkv = nn.Linear(self.dim, self.dim * 3, bias=True)
        self.proj = nn.Linear(self.dim, self.dim)
        self.scaling = self.head_dim**-0.5

    def forward(self, hidden_states, cu_seqlens, position_embeddings):
        seq_length, _ = hidden_states.size()
        q, k, v = (
            self.qkv(hidden_states)
            .reshape(seq_length, 3, self.num_heads, -1)
            .permute(1, 0, 2, 3)
            .unbind(0)
        )
        cos, sin = position_embeddings
        q, k = _vision_apply_rotary_pos_emb(q, k, cos, sin)

        q = q.transpose(0, 1).unsqueeze(0)
        k = k.transpose(0, 1).unsqueeze(0)
        v = v.transpose(0, 1).unsqueeze(0)

        lengths = (cu_seqlens[1:] - cu_seqlens[:-1]).tolist()
        qs, ks, vs = [torch.split(t, lengths, dim=2) for t in (q, k, v)]
        outs = [F.scaled_dot_product_attention(qq, kk, vv, is_causal=False) for qq, kk, vv in zip(qs, ks, vs)]
        attn_output = torch.cat(outs, dim=2)
        attn_output = attn_output.reshape(seq_length, -1).contiguous()
        return self.proj(attn_output)


class V4XQwen3VisionMLP(nn.Module):
    def __init__(self, config):
        super().__init__()
        h, i = config["vision_hidden_size"], config["vision_intermediate_size"]
        self.linear_fc1 = nn.Linear(h, i, bias=True)
        self.linear_fc2 = nn.Linear(i, h, bias=True)
        self.act_fn = ACT2FN[config["vision_hidden_act"]]

    def forward(self, x):
        return self.linear_fc2(self.act_fn(self.linear_fc1(x)))


class V4XQwen3VisionBlock(nn.Module):
    def __init__(self, config):
        super().__init__()
        h = config["vision_hidden_size"]
        self.norm1 = nn.LayerNorm(h, eps=1e-6)
        self.norm2 = nn.LayerNorm(h, eps=1e-6)
        self.attn = V4XQwen3VisionAttention(config)
        self.mlp = V4XQwen3VisionMLP(config)

    def forward(self, hidden_states, cu_seqlens, position_embeddings):
        hidden_states = hidden_states + self.attn(self.norm1(hidden_states), cu_seqlens, position_embeddings)
        hidden_states = hidden_states + self.mlp(self.norm2(hidden_states))
        return hidden_states


class V4XQwen3VisionPatchEmbed(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.patch_size = config["vision_patch_size"]
        self.temporal_patch_size = config["vision_temporal_patch_size"]
        self.in_channels = 3
        self.embed_dim = config["vision_hidden_size"]
        kernel_size = [self.temporal_patch_size, self.patch_size, self.patch_size]
        self.proj = nn.Conv3d(self.in_channels, self.embed_dim, kernel_size=kernel_size, stride=kernel_size, bias=True)

    def forward(self, hidden_states):
        target_dtype = self.proj.weight.dtype
        hidden_states = hidden_states.view(
            -1, self.in_channels, self.temporal_patch_size, self.patch_size, self.patch_size
        )
        return self.proj(hidden_states.to(dtype=target_dtype)).view(-1, self.embed_dim)


class V4XQwen3VisionPatchMerger(nn.Module):
    """Merger: ln_q + mlp ModuleList(Linear@0, GELU@1, Linear@2) — layout EXACTO
    del checkpoint (mlp.{0,2}, idéntico al merger oficial de Qwen3-Omni).

    merger.ln_q: [1152] pre-shuffle; merger_list[N].ln_q: [4608] post-shuffle.
    """

    def __init__(self, config, use_postshuffle_norm=False):
        super().__init__()
        h = config["vision_hidden_size"]
        self.hidden_size = h * (config["vision_spatial_merge_size"] ** 2)  # 4608
        self.use_postshuffle_norm = use_postshuffle_norm
        self.ln_q = nn.LayerNorm(self.hidden_size if use_postshuffle_norm else h, eps=1e-6)
        self.mlp = nn.ModuleList(
            [
                nn.Linear(self.hidden_size, self.hidden_size),
                nn.GELU(),
                nn.Linear(self.hidden_size, config["vision_out_hidden_size"]),
            ]
        )

    def forward(self, hidden):
        hidden = self.ln_q(
            hidden.view(-1, self.hidden_size) if self.use_postshuffle_norm else hidden
        ).view(-1, self.hidden_size)
        for layer in self.mlp:
            hidden = layer(hidden)
        return hidden


class V4XQwen3VisionModel(nn.Module):
    """Vision tower de Qwen3-VL (claves: V4X_Vision.visual.*). Imagen Y vídeo.

    patch_embed (Conv3d) + pos_embed [2304, 1152] interpolable + 27 blocks
    (RoPE 2D por cu_seqlens) + merger + merger_list (deepstack en 8/16/24).
    Merger de salida: 4096 (vision_out_hidden_size).
    """

    def __init__(self, config):
        super().__init__()
        c = config
        h = c["vision_hidden_size"]
        self.merger_list = nn.ModuleList(
            [
                V4XQwen3VisionPatchMerger(c, use_postshuffle_norm=True)
                for _ in range(len(c["vision_deepstack_visual_indexes"]))
            ]
        )
        self.spatial_merge_size = c["vision_spatial_merge_size"]
        self.patch_size = c["vision_patch_size"]
        self.config = c
        self.patch_embed = V4XQwen3VisionPatchEmbed(c)
        self.pos_embed = nn.Embedding(c["vision_num_position_embeddings"], h)
        self.num_grid_per_side = int(c["vision_num_position_embeddings"] ** 0.5)
        head_dim = h // c["vision_num_heads"]
        self.rotary_pos_emb = V4XQwen3VisionRotaryEmbedding(head_dim // 2, theta=c["vision_rope_theta"])
        self.blocks = nn.ModuleList([V4XQwen3VisionBlock(c) for _ in range(c["vision_depth"])])
        self.merger = V4XQwen3VisionPatchMerger(c, use_postshuffle_norm=False)
        self.deepstack_visual_indexes = c["vision_deepstack_visual_indexes"]

    def rot_pos_emb(self, grid_thw: torch.Tensor) -> torch.Tensor:
        """Coordenadas (fila, columna) por bloque de merge — idéntico al oficial."""
        merge_size = self.spatial_merge_size
        max_hw = int(grid_thw[:, 1:].max().item())
        freq_table = self.rotary_pos_emb(max_hw)  # (max_hw, dim//2)
        device = freq_table.device

        total_tokens = int(torch.prod(grid_thw, dim=1).sum().item())
        pos_ids = torch.empty((total_tokens, 2), dtype=torch.long, device=device)

        offset = 0
        for num_frames, height, width in grid_thw:
            merged_h, merged_w = height // merge_size, width // merge_size
            block_rows = torch.arange(merged_h, device=device)
            block_cols = torch.arange(merged_w, device=device)
            intra_row = torch.arange(merge_size, device=device)
            intra_col = torch.arange(merge_size, device=device)
            row_idx = block_rows[:, None, None, None] * merge_size + intra_row[None, None, :, None]
            col_idx = block_cols[None, :, None, None] * merge_size + intra_col[None, None, None, :]
            row_idx = row_idx.expand(merged_h, merged_w, merge_size, merge_size).reshape(-1)
            col_idx = col_idx.expand(merged_h, merged_w, merge_size, merge_size).reshape(-1)
            coords = torch.stack((row_idx, col_idx), dim=-1)
            if num_frames > 1:
                coords = coords.repeat(int(num_frames), 1)
            num_tokens = coords.shape[0]
            pos_ids[offset : offset + num_tokens] = coords
            offset += num_tokens
        embeddings = freq_table[pos_ids]
        return embeddings.flatten(1)

    def fast_pos_embed_interpolate(self, grid_thw):
        """Interpolación bilinear 4-esquinas del pos_embed [2304, 1152] — idéntica al oficial."""
        grid_ts, grid_hs, grid_ws = grid_thw[:, 0], grid_thw[:, 1], grid_thw[:, 2]
        idx_list = [[] for _ in range(4)]
        weight_list = [[] for _ in range(4)]
        device = self.pos_embed.weight.device

        for t, h, w in zip(grid_ts, grid_hs, grid_ws):
            h_idxs = torch.linspace(0, self.num_grid_per_side - 1, int(h))
            w_idxs = torch.linspace(0, self.num_grid_per_side - 1, int(w))
            h_idxs_floor = h_idxs.int()
            w_idxs_floor = w_idxs.int()
            h_idxs_ceil = (h_idxs.int() + 1).clip(max=self.num_grid_per_side - 1)
            w_idxs_ceil = (w_idxs.int() + 1).clip(max=self.num_grid_per_side - 1)
            dh = h_idxs - h_idxs_floor
            dw = w_idxs - w_idxs_floor
            base_h = h_idxs_floor * self.num_grid_per_side
            base_h_ceil = h_idxs_ceil * self.num_grid_per_side
            indices = [
                (base_h[None].T + w_idxs_floor[None]).flatten(),
                (base_h[None].T + w_idxs_ceil[None]).flatten(),
                (base_h_ceil[None].T + w_idxs_floor[None]).flatten(),
                (base_h_ceil[None].T + w_idxs_ceil[None]).flatten(),
            ]
            weights = [
                ((1 - dh)[None].T * (1 - dw)[None]).flatten(),
                ((1 - dh)[None].T * dw[None]).flatten(),
                (dh[None].T * (1 - dw)[None]).flatten(),
                (dh[None].T * dw[None]).flatten(),
            ]
            for i in range(4):
                idx_list[i].extend(indices[i].tolist())
                weight_list[i].extend(weights[i].tolist())

        idx_tensor = torch.tensor(idx_list, dtype=torch.long, device=device)
        weight_tensor = torch.tensor(weight_list, dtype=self.pos_embed.weight.dtype, device=device)
        pos_embeds = self.pos_embed(idx_tensor) * weight_tensor[:, :, None]
        patch_pos_embeds = pos_embeds[0] + pos_embeds[1] + pos_embeds[2] + pos_embeds[3]
        patch_pos_embeds = patch_pos_embeds.split([int(h) * int(w) for h, w in zip(grid_hs, grid_ws)])

        permuted = []
        merge_size = self.spatial_merge_size
        for pos_embed, t, h, w in zip(patch_pos_embeds, grid_ts, grid_hs, grid_ws):
            pos_embed = pos_embed.repeat(int(t), 1)
            pos_embed = (
                pos_embed.view(int(t), int(h) // merge_size, merge_size, int(w) // merge_size, merge_size, -1)
                .permute(0, 1, 3, 2, 4, 5)
                .flatten(0, 4)
            )
            permuted.append(pos_embed)
        return torch.cat(permuted)

    def forward(self, hidden_states: torch.Tensor, grid_thw: torch.Tensor):
        """hidden_states: [seq, 3*2*16*16] (pixels); grid_thw: [n, 3] = (t, h, w) en
        GRUPOS DE PARCHES (t = grupos temporales: 1 para imagen, n_frames/2 para vídeo;
        h, w = nº de parches 16x16). Debe cumplirse seq == t*h*w.

        Devuelve (merged [n_merged, 4096], deepstack: list de 3 x [n_merged, 4096]).
        """
        hidden_states = self.patch_embed(hidden_states)
        pos_embeds = self.fast_pos_embed_interpolate(grid_thw)
        hidden_states = hidden_states + pos_embeds

        rotary_pos_emb = self.rot_pos_emb(grid_thw)
        seq_len, _ = hidden_states.size()
        rotary_pos_emb = rotary_pos_emb.reshape(seq_len, -1)
        emb = torch.cat((rotary_pos_emb, rotary_pos_emb), dim=-1)
        position_embeddings = (emb.cos().to(hidden_states.dtype), emb.sin().to(hidden_states.dtype))

        cu_seqlens = torch.repeat_interleave(grid_thw[:, 1] * grid_thw[:, 2], grid_thw[:, 0]).cumsum(
            dim=0, dtype=torch.int32
        )
        cu_seqlens = F.pad(cu_seqlens, (1, 0), value=0)

        deepstack_feature_lists = []
        for layer_num, blk in enumerate(self.blocks):
            hidden_states = blk(hidden_states, cu_seqlens=cu_seqlens, position_embeddings=position_embeddings)
            if layer_num in self.deepstack_visual_indexes:
                deepstack_feature = self.merger_list[self.deepstack_visual_indexes.index(layer_num)](hidden_states)
                deepstack_feature_lists.append(deepstack_feature)

        hidden_states = self.merger(hidden_states)
        return hidden_states, deepstack_feature_lists


# SECCIÓN 11b — V4X_Vision: torre de visión Qwen3-VL (imagen Y vídeo) + adapter
#   V4X_Vision.visual.*              -> V4XQwen3VisionModel (27 bloques, deepstack)
#                                       merger de salida 4096
#   V4X_Vision.adapter.net.{0,3,4}.* -> proyección 4096 -> 5376 -> 2688
# ═══════════════════════════════════════════════════════════════════════════

class V4XVisionAdapter(nn.Module):
    """Proyección de la visión al backbone (claves V4X_Vision.adapter.net.{0,3,4}).
    4096 -> 5376 -> 2688 + LayerNorm."""

    def __init__(self, config=None):
        super().__init__()
        from .configuration_v4x import DEFAULT_VISION_ADAPTER_CONFIG
        if config is None:
            c = dict(DEFAULT_VISION_ADAPTER_CONFIG)
        elif hasattr(config, "vision_adapter_config"):
            c = dict(config.vision_adapter_config or DEFAULT_VISION_ADAPTER_CONFIG)
        else:
            c = dict(config)
        self.net = nn.Sequential(
            nn.Linear(c["input_size"], c["intermediate_size"], bias=True),
            ACT2FN[c["hidden_act"]],
            nn.Dropout(c["p_dropout"]),
            nn.Linear(c["intermediate_size"], c["output_size"], bias=True),
            nn.LayerNorm(c["output_size"]),
        )

    def forward(self, x):
        return self.net(x)


class V4XVisionTower(nn.Module):
    """V4X_Vision — torre de visión Qwen3-VL: procesa IMAGEN y VÍDEO + adapter.

    Claves del checkpoint:
      V4X_Vision.visual.*              (V4XQwen3VisionModel, deepstack en 8/16/24)
      V4X_Vision.adapter.net.{0,3,4}.* (proyección 4096 -> 5376 -> 2688)

    La misma torre sirve para imagen y vídeo; `grid_thw` decide. Formato de `grid_thw`
    (convención oficial Qwen3-VL): (t, h, w) en GRUPOS DE PARCHES de 16x16:
      - Imagen : (1, H/16, W/16). El preprocesado duplica el frame (temporal_patch_size=2)
                 dentro de cada parche; pixel_values [seq, 3*2*16*16] con seq = 1*h*w.
      - Vídeo  : (n_frames/2, H/16, W/16); pixel_values [seq, 3*2*16*16] con seq = t*h*w.
    (grid_thw de Qwen3-VL es lo que devuelve su image/video processor en `image_grid_thw`
     / `video_grid_thw`; ver preprocessor_config.json y video_preprocessor_config.json
     en encoders/qwen3vl-vision/.)

    Salida: (features [n_merged, out], deepstack [3 x [n_merged, 4096]]).
    `project=True` devuelve features proyectadas al espacio del backbone (2688).
    """

    def __init__(self, config=None):
        super().__init__()
        from .configuration_v4x import DEFAULT_VISION_CONFIG
        if config is None:
            c = dict(DEFAULT_VISION_CONFIG)
        elif hasattr(config, "vision_config"):
            c = dict(config.vision_config or DEFAULT_VISION_CONFIG)
        else:
            c = dict(config)
        self.visual = V4XQwen3VisionModel(c)
        self.adapter = V4XVisionAdapter(config)

    def forward(self, pixel_values, grid_thw, project=True):
        hidden, deepstack = self.visual(pixel_values, grid_thw)
        if project:
            hidden = self.adapter(hidden)
        return hidden, deepstack


# ═══════════════════════════════════════════════════════════════════════════
# SECCIÓN 12 — Adapter de visión V4X_Vision(4096) -> V4X(2688)
#   sub-módulo `.adapter.net` = Sequential(Linear, GELU, Dropout,
#   Linear, LayerNorm) -> claves del checkpoint: V4X_Vision.adapter.net.{0,3,4}.{w,b}
#   (dims verificadas: 4096 -> 5376 -> 2688).
# ═══════════════════════════════════════════════════════════════════════════

# SECCIÓN 12b — Verificación de dims del checkpoint desde las cabeceras (fase 0)
#
# `from_pretrained` lee SOLO las cabeceras de los safetensors locales (shapes
# exactos, ~KB, sin cargar pesos) y verifica el config ANTES de construir los
# módulos, de modo que cualquier ruta de carga (normal / low_cpu_mem_usage /
# device_map="auto") recibe el modelo ya dimensionado con las dims REALES del
# checkpoint. Qué comprueba:
#   - V4X_Vision.adapter.net.{0,3,4}.weight : dims exactas 4096→5376→2688.
#   - V4X_Vision.visual.*: dims del vision config (patch_embed/pos_embed/merger).
#   - V4X.experts: intermediate del experto Qwen (dest 129..176) y del Phi (177).
#   - v4x_router.weight: filas por capa == v4x_router_dims (semántica de slots);
#     si difiere lanza V4XArchitectureMismatch.
#   - dtypes informativos por componente.
# ═══════════════════════════════════════════════════════════════════════════

class V4XArchitectureMismatch(ValueError):
    """El checkpoint real contradice la arquitectura derivada del config.

    Se lanza (en vez de parchear) cuando la discrepancia afecta a la SEMÁNTICA
    del modelo (p.ej. filas de un router ≠ mapa de slots), porque indica que la
    derivación del config es incorrecta y hay que diagnosticar, no tapar.
    """


# Ruta local del checkpoint que from_pretrained está cargando (None fuera de
# from_pretrained). Se consume en V4XForCausalLM.__init__.
_V4X_PENDING_CKPT_DIR = None


def _v4x_ckpt_weight_map(checkpoint_dir):
    """{clave: shard} de un checkpoint local (índice multi-shard o archivo único).

    Devuelve {} si el directorio no es un checkpoint safetensors local.
    """
    import json
    import os

    index_path = os.path.join(checkpoint_dir, "model.safetensors.index.json")
    if os.path.isfile(index_path):
        with open(index_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        weight_map = data.get("weight_map") or {}
        if weight_map:
            return weight_map
    single = os.path.join(checkpoint_dir, "model.safetensors")
    if os.path.isfile(single):
        from safetensors import safe_open

        with safe_open(single, framework="pt") as f:
            return {k: "model.safetensors" for k in f.keys()}
    return {}


def _v4x_read_shapes(checkpoint_dir, weight_map, keys):
    """{clave: (shape, dtype)} leyendo SOLO cabeceras safetensors (sin datos).

    `weight_map`: {clave: shard} (de _v4x_ckpt_weight_map). Abre cada shard una
    sola vez y usa PySafeSlice (solo cabecera, no carga tensores).
    """
    import os

    from safetensors import safe_open

    by_shard = {}
    for k in keys:
        shard = weight_map.get(k)
        if shard is not None:
            by_shard.setdefault(shard, []).append(k)

    out = {}
    for shard, shard_keys in by_shard.items():
        with safe_open(os.path.join(checkpoint_dir, shard), framework="pt") as f:
            for k in shard_keys:
                sl = f.get_slice(k)
                out[k] = (tuple(sl.get_shape()), sl.get_dtype())
    return out


def _v4x_scan_and_patch(checkpoint_dir, config, verbose=True):
    """Verifica en el config las dims contra las shapes del checkpoint.

    Ejecutado al principio de V4XForCausalLM.__init__ cuando from_pretrained
    está cargando un checkpoint local. Qué comprueba:

    - ``V4X_Vision.adapter.net.{0,3,4}.weight``: dims exactas input→inter→output.
    - ``V4X_Vision.visual.*``: patch_embed/pos_embed/merger → dims del vision config.
    - ``V4X_Audio.audio_tower.*``: presencia (proj1/proj2 internos).
    - ``V4X.experts``: intermediate del experto Qwen (dest 129..176) y del
      Phi (dest 177).
    - ``v4x_router.weight``: nº de filas por capa DEBE coincidir con
      ``v4x_router_dims`` (semántica de slots) → si difiere, lanza
      V4XArchitectureMismatch con el detalle.
    - dtypes informativos por componente (adapter/backbone/encoders).

    Nunca escribe en disco: el parche es solo en memoria (el config lo imprime
    para que se pueda fijar en config.json si procede).
    """
    import os
    import re

    weight_map = _v4x_ckpt_weight_map(checkpoint_dir)
    if not weight_map:
        return
    keys = set(weight_map)

    # ---- selección de claves objetivo (solo nombres, sin I/O) ----
    pat_adapter = re.compile(r"V4X_Vision\.adapter\.net\.(\d+)\.weight")
    pat_expert = re.compile(
        r"backbone\.layers\.(\d+)\.V4X\.experts\.(\d+)\.(gate_proj|up_proj|down_proj)\.weight"
    )
    pat_router = re.compile(r"backbone\.layers\.(\d+)\.mixer\.v4x_router\.weight")

    adapter_keys = sorted(k for k in keys if pat_adapter.fullmatch(k))
    router_keys = sorted(k for k in keys if pat_router.fullmatch(k))

    new_idx = set()
    for k in keys:
        m = pat_expert.fullmatch(k)
        if m:
            idx = int(m.group(2))
            if idx >= V4X_NEW_EXPERT_SLOT_BASE:
                new_idx.add(idx)
    qwen_idx = min(new_idx) if new_idx else None
    phi_idx = max(new_idx) if new_idx else None

    def _first_expert_key(idx, mod):
        cands = sorted(
            k for k in keys
            if (m := pat_expert.fullmatch(k)) and int(m.group(2)) == idx and m.group(3) == mod
        )
        return cands[0] if cands else None

    target = list(adapter_keys) + list(router_keys)
    # dims de la torre de visión (V4X_Vision.visual.*) para validar el vision config
    for k in (
        "V4X_Vision.visual.patch_embed.proj.weight",
        "V4X_Vision.visual.pos_embed.weight",
        "V4X_Vision.visual.merger.mlp.2.weight",
    ):
        if k in keys:
            target.append(k)
    qwen_key = _first_expert_key(qwen_idx, "up_proj") if qwen_idx is not None else None
    phi_key = _first_expert_key(phi_idx, "up_proj") if phi_idx is not None else None
    phi_down_key = _first_expert_key(phi_idx, "down_proj") if phi_idx is not None else None
    for k in (qwen_key, phi_key, phi_down_key):
        if k is not None:
            target.append(k)

    # sondas de dtype (informativo): 1 clave por componente
    dtype_probes = {}
    for prefix in (
        "V4X_Vision.adapter.",
        "backbone.",
        "V4X_Transcription.",
        "V4X_Music.",
        "V4X_Audio.",
        "V4X_Vision.visual.",
        "lm_head",
    ):
        cand = sorted(k for k in keys if k.startswith(prefix))
        if cand:
            dtype_probes[cand[0]] = prefix.rstrip(".")
    target.extend(dtype_probes.keys())

    shapes = _v4x_read_shapes(checkpoint_dir, weight_map, target)
    if not shapes:
        return

    notes = []
    changed = []

    # ---- 1) adapter de visión: dims exactas (4096→5376→2688) ----
    a0 = shapes.get("V4X_Vision.adapter.net.0.weight")
    a3 = shapes.get("V4X_Vision.adapter.net.3.weight")
    a4 = shapes.get("V4X_Vision.adapter.net.4.weight")
    if a0 is not None and a3 is not None and len(a0[0]) == 2 and len(a3[0]) == 2:
        inter_dim, in_dim = int(a0[0][0]), int(a0[0][1])   # Linear(input, inter).weight=[inter, input]
        out_dim = int(a3[0][0])
        if int(a3[0][1]) != inter_dim:
            raise V4XArchitectureMismatch(
                f"V4X_Vision.adapter.net.3.weight {tuple(a3[0])} no encadena con net.0.weight {tuple(a0[0])}"
            )
        if a4 is not None and len(a4[0]) == 1 and int(a4[0][0]) != out_dim:
            raise V4XArchitectureMismatch(
                f"V4X_Vision.adapter.net.4 (LayerNorm) tiene {a4[0][0]} canales pero net.3 produce {out_dim}"
            )
        cur = dict(config.vision_adapter_config or {})
        cur_io = (cur.get("input_size"), cur.get("intermediate_size"), cur.get("output_size"))
        if cur_io != (in_dim, inter_dim, out_dim):
            config.vision_adapter_config = {
                **cur, "input_size": in_dim, "intermediate_size": inter_dim, "output_size": out_dim
            }
            changed.append(f"vision adapter {cur_io[0]}→{cur_io[1]}→{cur_io[2]} ⇒ {in_dim}→{inter_dim}→{out_dim}")
        else:
            notes.append(f"vision adapter {in_dim}→{inter_dim}→{out_dim} ✓ (coincide con el config)")

    # ---- 1b) torre de visión V4X_Vision.visual.*: dims del vision config ----
    v_patch = shapes.get("V4X_Vision.visual.patch_embed.proj.weight")  # [h, 3, t, P, P]
    v_pos = shapes.get("V4X_Vision.visual.pos_embed.weight")           # [n_pos, h]
    v_out = shapes.get("V4X_Vision.visual.merger.mlp.2.weight")        # [out, h*merge^2]
    if v_patch is not None and len(v_patch[0]) == 5:
        h_v = int(v_patch[0][0])
        t_p = int(v_patch[0][2])
        p_v = int(v_patch[0][3])
        c = dict(config.vision_config or {})
        patch = (c.get("vision_hidden_size"), c.get("vision_temporal_patch_size"), c.get("vision_patch_size"))
        if patch != (h_v, t_p, p_v):
            c.update({"vision_hidden_size": h_v, "vision_temporal_patch_size": t_p, "vision_patch_size": p_v})
            config.vision_config = c
            changed.append(f"vision (hidden, t_patch, patch) {patch} ⇒ {(h_v, t_p, p_v)}")
        if v_pos is not None and len(v_pos[0]) == 2 and int(v_pos[0][1]) != h_v:
            raise V4XArchitectureMismatch(
                f"V4X_Vision.visual.pos_embed {tuple(v_pos[0])} no encadena con hidden {h_v}"
            )
        if v_out is not None and len(v_out[0]) == 2 and int(v_out[0][0]) != int(c.get("vision_out_hidden_size", 0)):
            c["vision_out_hidden_size"] = int(v_out[0][0])
            config.vision_config = c
            changed.append(f"vision_out_hidden_size ⇒ {int(v_out[0][0])}")
        n_vis = len([k for k in keys if k.startswith("V4X_Vision.visual.")])
        notes.append(f"V4X_Vision.visual: {n_vis} claves, hidden={h_v}, out={v_out[0][0] if v_out else '?'}")

    # ---- 1c) audio: presencia de la torre (V4X_Audio.audio_tower.*) ----
    n_aud = len([k for k in keys if k.startswith("V4X_Audio.")])
    if n_aud:
        notes.append(f"V4X_Audio: {n_aud} claves ✓")
    else:
        notes.append("V4X_Audio: SIN claves en el checkpoint (¿nombre cambiado?)")

    # ---- 2) expertos: I de Qwen (dest 129..176) y Phi (dest 177) ----
    if qwen_key is not None and shapes.get(qwen_key) is not None:
        i_qwen = int(shapes[qwen_key][0][0])  # up_proj [I, hidden]
        if i_qwen != config.v4x_qwen_expert_intermediate_size:
            changed.append(
                f"I_qwen {config.v4x_qwen_expert_intermediate_size} ⇒ {i_qwen} (V4X.experts.{qwen_idx})"
            )
            config.v4x_qwen_expert_intermediate_size = i_qwen
        else:
            notes.append(f"I_qwen={i_qwen} ✓ ({len([k for k in keys if pat_expert.fullmatch(k)])} claves V4X.experts)")
    i_phi = None
    phi_shape = shapes.get(phi_key) if phi_key is not None else None
    if phi_shape is not None:
        i_phi = int(phi_shape[0][0])  # up_proj [I, hidden]
    elif phi_down_key is not None and shapes.get(phi_down_key) is not None:
        i_phi = int(shapes[phi_down_key][0][1])  # down_proj [hidden, I]
    if i_phi is not None:
        if i_phi != config.v4x_phi_expert_intermediate_size:
            changed.append(f"I_phi {config.v4x_phi_expert_intermediate_size} ⇒ {i_phi} (V4X.experts.{phi_idx})")
            config.v4x_phi_expert_intermediate_size = i_phi
        else:
            notes.append(f"I_phi={i_phi} ✓ (V4X.experts.{phi_idx})")

    # ---- 3) v4x_router: filas por capa (semántica — NO se parchea) ----
    if router_keys:
        dims_cfg = config.v4x_router_dims or {}
        mismatch = []
        for k in router_keys:
            layer = int(pat_router.fullmatch(k).group(1))
            actual = int(shapes[k][0][0])
            expected = dims_cfg.get(layer, 177)
            if actual != expected:
                mismatch.append(f"L{layer}: config={expected}, ckpt={actual}")
        if mismatch:
            raise V4XArchitectureMismatch(
                "v4x_router.weight: filas del checkpoint ≠ v4x_router_dims del config — "
                + "; ".join(mismatch[:10])
                + ("; …" if len(mismatch) > 10 else "")
                + ". El mapa de slots (0-127 base, 128 shared, 129-176 qwen, 177 phi) está mal derivado: "
                "revisa configuration_v4x.py antes de continuar."
            )
        notes.append(
            f"v4x_router: {len(router_keys)} routers, filas "
            + str(sorted(set(int(shapes[k][0][0]) for k in router_keys)))
            + " ✓"
        )

    # ---- 4) dtypes informativos ----
    dtypes = {}
    for k, comp in dtype_probes.items():
        if shapes.get(k) is not None:
            dtypes[comp] = shapes[k][1]

    if verbose:
        print(f"[V4X auto-detect] checkpoint local: {os.path.basename(str(checkpoint_dir).rstrip('/'))}", flush=True)
        for n in notes:
            print(f"[V4X auto-detect]   · {n}", flush=True)
        for c in changed:
            print(f"[V4X auto-detect]   · CORREGIDO: {c}", flush=True)
        if dtypes:
            print("[V4X auto-detect]   · dtypes en shards: " + ", ".join(f"{c}={d}" for c, d in sorted(dtypes.items())), flush=True)
        if changed:
            print(
                "[V4X auto-detect]   · config corregido EN MEMORIA; considera fijar estos valores en config.json",
                flush=True,
            )


# ═══════════════════════════════════════════════════════════════════════════
# SECCIÓN 13 — V4XForCausalLM (modelo completo)
# ═══════════════════════════════════════════════════════════════════════════

class V4XForCausalLM(NemotronHPreTrainedModel, GenerationMixin):
    """AI-ku V4X Thinker-Max 35B — modelo completo.

    Atributos de primer nivel (== prefijos del checkpoint):
      backbone · lm_head · V4X_Transcription · V4X_Music ·
      V4X_Audio · V4X_Vision (Qwen3-VL, imagen y vídeo + adapter 4096->2688)

    Multimodalidad (categoría 1, pesos del checkpoint): los embeddings
    multimodales se construyen con los métodos get_*_features + project_to_v4x
    y se inyectan vía `inputs_embeds` en las posiciones de los tokens especiales
    (el ensamblado de prompts es preprocessing, categoría 2).
    """

    config_class = V4XConfig
    base_model_prefix = "backbone"
    _tied_weights_keys = []
    _supports_cache_class = True

    def __init__(self, config: V4XConfig):
        # ---- fase 0: auto-detección de dims PENDIENTES (sección 12b) ----
        # Si from_pretrained está cargando un checkpoint local, corrige el
        # config con las shapes REALES antes de construir ningún módulo.
        # NOTA: se comprueba model_type y NO isinstance(config, V4XConfig):
        # con trust_remote_code, AutoConfig y el modeling copiado viven en
        # paquetes dinámicos DISTINTOS (hashes diferentes) y las clases de
        # config no son la misma — pero sí el mismo objeto lógico.
        global _V4X_PENDING_CKPT_DIR
        _ckpt_dir, _V4X_PENDING_CKPT_DIR = _V4X_PENDING_CKPT_DIR, None
        if _ckpt_dir is not None and getattr(config, "model_type", None) == "V4X":
            _v4x_scan_and_patch(_ckpt_dir, config)

        super().__init__(config)
        self.config = config
        self.backbone = NemotronHModel(config)
        self.vocab_size = config.vocab_size
        self.lm_head = nn.Linear(config.hidden_size, config.vocab_size, bias=False)

        # ---- encoders (pesos del checkpoint) ----
        self.V4X_Transcription = V4XWhisperModel(config.whisper_config)
        self.V4X_Music = V4XMERTModel(config.mert_config)
        self.V4X_Audio = V4XQwen3AudioTower(config.thinker_config)
        # V4X_Vision: torre de visión Qwen3-VL (imagen y vídeo) + su adapter 4096->2688
        self.V4X_Vision = V4XVisionTower(config)

        self.post_init()

    # ------------------------------------------------------------------
    @classmethod
    def from_pretrained(cls, pretrained_model_name_or_path, *model_args, **kwargs):
        """from_pretrained con auto-detección de dims PENDIENTES (sección 12b).

        Si `pretrained_model_name_or_path` es un directorio local con
        safetensors, se leen SOLO las cabeceras y el config se corrige con las
        dims reales (adapter de visión, vision config, I de los expertos
        Qwen/Phi; los routers se verifican y una discrepancia lanza
        V4XArchitectureMismatch). Así la carga funciona por la ruta que sea
        (normal, low_cpu_mem_usage, device_map="auto") aunque los defaults del
        config estén equivocados.

        Rutas remotas (hub) o sin safetensors locales: comportamiento estándar.
        """
        global _V4X_PENDING_CKPT_DIR
        import os

        if isinstance(pretrained_model_name_or_path, (str, os.PathLike)) and os.path.isdir(
            str(pretrained_model_name_or_path)
        ):
            _V4X_PENDING_CKPT_DIR = str(pretrained_model_name_or_path)
        try:
            return super().from_pretrained(pretrained_model_name_or_path, *model_args, **kwargs)
        finally:
            _V4X_PENDING_CKPT_DIR = None

    # ------------------------------------------------------------------
    def get_input_embeddings(self):
        return self.backbone.get_input_embeddings()

    def set_input_embeddings(self, new_embeddings):
        self.backbone.set_input_embeddings(new_embeddings)

    def get_output_embeddings(self):
        return self.lm_head

    def set_output_embeddings(self, new_embeddings):
        self.lm_head = new_embeddings

    def get_decoder(self):
        return self.backbone

    # ------------------------------------------------------------------
    # Métodos multimodales (categoría 1: pesos del modelo)
    # ------------------------------------------------------------------
    def get_whisper_features(self, input_features, attention_mask=None):
        """ASR (V4X_Transcription): log-mel [bsz, 128, T] -> hidden [bsz, T/2, 1280]."""
        return self.V4X_Transcription.encode(input_features, attention_mask=attention_mask)

    def get_mert_features(self, input_values, attention_mask=None):
        """Música (V4X_Music): waveform [bsz, T] @24 kHz -> [bsz, T', 1024]."""
        return self.V4X_Music(input_values, attention_mask=attention_mask).last_hidden_state

    def get_audio_features(self, input_features, feature_lens):
        """Audio de entendimiento (V4X_Audio): log-mel [128, T] -> [n_tok, 2048]."""
        return self.V4X_Audio.audio_tower(input_features, feature_lens).last_hidden_state

    def get_vision_features(self, pixel_values, grid_thw, project=True):
        """V4X_Vision — IMAGEN y VÍDEO comparten torre (Qwen3-VL) + adapter.

        pixel_values [seq, 3*2*16*16] + grid_thw [n, 3] = (t, h, w) en grupos de parches
        (1, H/16, W/16) para imagen y (n_frames/2, H/16, W/16) para vídeo; seq = t*h*w.
        Devuelve (features, deepstack [3 x [n_merged, 4096]]):
          - project=True  -> features [n_merged, 2688] proyectadas al backbone.
          - project=False -> features [n_merged, 4096] del merger de la torre.
        """
        return self.V4X_Vision(pixel_values, grid_thw, project=project)

    def get_image_features(self, pixel_values, grid_thw=None, output_length=None, project=True):
        """Imágenes (V4X_Vision.visual): pixels [seq, 3*2*16*16] -> [n_merged, 2688].

        grid_thw por defecto [[1, h, w]] cuadrado deducido de seq = h*w (parches 16x16);
        para imágenes no cuadradas pasa grid_thw explícito (image_grid_thw del processor).
        """
        if grid_thw is None:
            side = int(pixel_values.shape[0] ** 0.5)  # seq = h*w (imagen, t=1)
            grid_thw = torch.tensor([[1, side, side]], device=pixel_values.device)
        return self.get_vision_features(pixel_values, grid_thw, project=project)

    def get_video_features(self, pixel_values, grid_thw, output_length=None, project=True):
        """Vídeo (V4X_Vision.visual): pixels [seq, 3*2*16*16] + grid_thw [n, 3]
        -> ([n_merged, 2688], deepstack [3 x [n_merged, 4096]])."""
        return self.get_vision_features(pixel_values, grid_thw, project=project)

    def project_to_v4x(self, features):
        """Proyecta features de visión (4096) al espacio del backbone (2688)."""
        return self.V4X_Vision.adapter(features)

    # ------------------------------------------------------------------
    def prepare_inputs_for_generation(
        self,
        input_ids,
        next_sequence_length=None,
        past_key_values=None,
        attention_mask=None,
        inputs_embeds=None,
        is_first_iteration=False,
        cache_position=None,
        position_ids=None,
        **kwargs,
    ):
        """Compatible con transformers 5.x (next_sequence_length) y 4.x (cache_position)."""
        # 1) cuántos tokens alimentar en este paso
        if next_sequence_length is not None:
            step_len = int(next_sequence_length)
        elif cache_position is not None:
            step_len = int(cache_position.shape[0])
        else:
            step_len = None  # prefill completo

        # 2) caché híbrida
        if past_key_values is None:
            batch = input_ids.shape[0] if input_ids is not None else inputs_embeds.shape[0]
            past_key_values = HybridMambaAttentionDynamicCache(
                self.config, batch, self.dtype, device=self.device
            )

        # 3) entradas (inputs_embeds solo en prefill)
        if inputs_embeds is not None and step_len is None:
            feeds = inputs_embeds
            model_inputs = {"inputs_embeds": feeds}
            cur_len = feeds.shape[1]
        else:
            ids = input_ids if step_len is None else input_ids[:, -step_len:]
            model_inputs = {"input_ids": ids.contiguous()}
            cur_len = ids.shape[1]

        # 4) position_ids desde attention_mask (o el recibido)
        if position_ids is None and attention_mask is not None:
            position_ids = (attention_mask.long().cumsum(-1) - 1).clamp(min=0)
        if position_ids is not None and position_ids.shape[-1] != cur_len:
            position_ids = position_ids[..., -cur_len:]
        if position_ids is not None:
            model_inputs["position_ids"] = position_ids

        model_inputs.update(
            {
                "past_key_values": past_key_values,
                "attention_mask": attention_mask,
                "use_cache": kwargs.pop("use_cache", True),
            }
        )
        model_inputs.update(kwargs)
        return model_inputs

    def _reorder_cache(self, past_key_values, beam_idx):
        if isinstance(past_key_values, HybridMambaAttentionDynamicCache):
            past_key_values.reorder_cache(beam_idx)
        return past_key_values

    # ------------------------------------------------------------------
    def forward(
        self,
        input_ids: Optional[torch.LongTensor] = None,
        inputs_embeds: Optional[torch.FloatTensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        cache_params: Optional[HybridMambaAttentionDynamicCache] = None,
        past_key_values: Optional[HybridMambaAttentionDynamicCache] = None,
        labels: Optional[torch.LongTensor] = None,
        output_attentions: Optional[bool] = None,
        output_hidden_states: Optional[bool] = None,
        return_dict: Optional[bool] = None,
        use_cache: Optional[bool] = None,
        cache_position: Optional[torch.LongTensor] = None,
        attention_mask: Optional[torch.Tensor] = None,
        num_logits_to_keep: Optional[int] = None,
        **kwargs,
    ) -> Union[Tuple, V4XCausalLMOutput]:
        r"""
        input_ids / inputs_embeds / labels: estándar de CausalLM.
        `inputs_embeds` permite inyectar embeddings multimodales (construidos con
        get_*_features + project_to_v4x) en las posiciones de los tokens especiales.
        """
        if past_key_values is not None and cache_params is None:
            cache_params = past_key_values

        # FIX-06/FIX-06a/FIX-06b (CAMBIOS 70/73/75/77): máscara de spans con estado
        # (decode) y routers cacheados (caza de ARGON: self.modules() recorría
        # ~12.000 submódulos por forward). Semántica idéntica a FIX-06a.
        if not hasattr(self, "_cached_v4x_routers"):
            object.__setattr__(
                self,
                "_cached_v4x_routers",
                tuple(m for m in self.modules() if isinstance(m, V4XRouter)),
            )
        if input_ids is not None and getattr(self.config, "v4x_phi_span_mask", False):
            prev_think = getattr(cache_params, "in_think_mode", None) if cache_params is not None else None
            _span, _next = _v4x_build_phi_span_mask(input_ids, prev_in_think=prev_think)
            if cache_params is not None:
                cache_params.in_think_mode = _next
            flat_mask = _span.reshape(-1)
            for _r in self._cached_v4x_routers:
                _r._phi_span_mask = flat_mask
        else:
            # FIX-06c (CAZA ARGON #8, CAMBIOS 81): limpiar máscara residual si
            # el siguiente pase entra por inputs_embeds o el flag está apagado.
            for _r in self._cached_v4x_routers:
                _r._phi_span_mask = None

        output_attentions = output_attentions if output_attentions is not None else self.config.output_attentions
        output_hidden_states = (
            output_hidden_states if output_hidden_states is not None else self.config.output_hidden_states
        )
        return_dict = return_dict if return_dict is not None else self.config.use_return_dict

        v4x_outputs = self.backbone(
            input_ids,
            cache_params=cache_params,
            inputs_embeds=inputs_embeds,
            output_attentions=output_attentions,
            output_hidden_states=output_hidden_states,
            return_dict=return_dict,
            use_cache=use_cache,
            cache_position=cache_position,
            attention_mask=attention_mask,
            position_ids=position_ids,
        )
        hidden_states = v4x_outputs[0]

        # FIX-04 (V3): en generacion (labels is None) solo se computan los logits que se piden.
        if labels is None:
            keep = num_logits_to_keep
            if keep is None:
                keep = getattr(self.config, "num_logits_to_keep", None)
            logits_in = hidden_states[:, -keep:, :] if (keep is not None and keep > 0) else hidden_states
            logits = self.lm_head(logits_in.to(self.lm_head.weight.dtype)).float()
        else:
            logits = self.lm_head(hidden_states.to(self.lm_head.weight.dtype)).float()

        loss = None
        if labels is not None:
            labels = labels.to(logits.device)
            shift_logits = logits[..., :-1, :].contiguous()
            shift_labels = labels[..., 1:].contiguous()
            loss_fct = CrossEntropyLoss()
            loss = loss_fct(shift_logits.view(-1, shift_logits.size(-1)), shift_labels.view(-1))

        if not return_dict:
            output = (logits,) + v4x_outputs[1:]
            return ((loss,) + output) if loss is not None else output

        return V4XCausalLMOutput(
            loss=loss,
            logits=logits,
            past_key_values=v4x_outputs.cache_params,
            cache_params=v4x_outputs.cache_params,
            hidden_states=v4x_outputs.hidden_states,
            attentions=v4x_outputs.attentions,
        )

    # ------------------------------------------------------------------
    @classmethod
    def get_expert_metadata(cls):
        """Metadatos de expertos (logging/debug). NO afectan al routing."""
        return {
            "0-127": {"origin": "nemotron", "type": "general", "activation": "relu2"},
            "128": {"origin": "nemotron", "type": "shared", "activation": "relu2"},
            "129-176": {"origin": "qwen3-coder", "type": "code", "activation": "silu"},
            "177": {"origin": "phi-4", "type": "reasoning", "activation": "silu"},
        }

    @classmethod
    def get_trainable_params_for_router_sft(cls, model):
        """Fase 1/2 del plan de entrenamiento: solo routers entrenables."""
        trainable = []
        frozen = 0
        for name, param in model.named_parameters():
            if "v4x_router" in name or "e_score_correction" in name:
                param.requires_grad = True
                trainable.append(param)
            else:
                param.requires_grad = False
                frozen += 1
        logger.info(f"V4X Router SFT: {len(trainable)} params entrenables, {frozen} congelados")
        return trainable
