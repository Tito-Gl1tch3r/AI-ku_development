# coding=utf-8
# Copyright (c) 2025, NVIDIA CORPORATION. All rights reserved.
# Copyright (c) 2026, AI-ku. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""AI-ku V4X (Thinker-Max 35B) — configuración completa y autocontenida.

Sustituye a `configuration_nemotron_h.py` (el esquema Nemotron-H era solo el backbone
lingüístico) y añade TODOS los componentes que viven en el checkpoint:

  1. BACKBONE (Nemotron-H híbrido): Mamba2 + Attention (RoPE YaRN 4x) + MoE.
  2. EXTENSIÓN V4X: expertos Qwen3-Coder (48/capa) + experto Phi-4 + router unificado.
  3. ENCODERS (pesos dentro del checkpoint):
       - whisper      : Whisper large-v3 (encoder+decoder, SIN k_proj.bias ni proj_out)
       - mert         : MERT-v1-330M (audio musical, HuBERT + attention_relax)
       - audio        : torre de audio de Qwen3-Omni-30B-A3B (V4X_Audio, proj1/proj2)
       - vision       : torre de visión de Qwen3-VL (V4X_Vision.visual, imagen Y vídeo, deepstack)
  4. ADAPTER: proyección de la visión Qwen3-VL (4096) al espacio V4X (2688):
     V4X_Vision.adapter.net.*.

Fidelidad: cada mapa por capa de este config reproduce EXACTAMENTE la estructura de
claves de `model.safetensors.index.json` del checkpoint (verificado contra el índice).
"""

import re

from transformers.configuration_utils import PretrainedConfig
from transformers.utils import logging


logger = logging.get_logger(__name__)


# ---------------------------------------------------------------------------
# Mapas V4X derivados del checkpoint (NO cambiar sin regenerar el checkpoint).
# ---------------------------------------------------------------------------
# hybrid_override_pattern (52 capas):
#   M -> Mamba2      * -> Attention      E -> MoE      - -> MLP denso (no usado en V4X)
V4X_HYBRID_OVERRIDE_PATTERN = "MEMEM*EMEMEM*EMEMEM*EMEMEM*EMEMEM*EMEMEMEM*EMEMEMEME"

# Expertos Qwen3-Coder colapsados (new_experts.0-47, silu, up/gate/down):
#   presentes en las capas 18..47 (48 expertos por capa).
V4X_QWEN_EXPERT_LAYERS = list(range(18, 48))

# Experto Phi-4 colapsado (new_experts.48, silu, up/gate/down):
#   completo en las capas 18..39.
V4X_PHI_EXPERT_LAYERS = list(range(18, 40))

# Nº de expertos Qwen3-Coder por capa (new_experts.0-47).
V4X_NUM_QWEN_EXPERTS = 48
# Caso especial capa 17: el checkpoint SOLO contiene
#   backbone.layers.17.mixer.new_experts.48.down_proj.weight  (phi parcial).
# Se instancia tal cual para que el load sea exacto (0 unexpected / 0 missing).
V4X_PHI_PARTIAL_LAYERS = [17]

# Router unificado v4x_router (nn.Parameter [dim, hidden]):
#   capas 17..51. Dim = nº de slots lógicos:
#     [0..127] base Nemotron · [128] shared · [129..176] Qwen · [177] Phi
#   129 = base+shared | 177 = base+shared+qwen | 178 = base+shared+qwen+phi
V4X_ROUTER_LAYERS = list(range(17, 52))
_V4X_ROUTER_178 = (18, 19, 21, 23, 25, 26, 28, 30, 32, 33, 35, 37, 39)  # capas NO-MoE 18..39
V4X_ROUTER_DIMS = {17: 177}
for _L in range(18, 40):
    V4X_ROUTER_DIMS[_L] = 178 if _L in _V4X_ROUTER_178 else 177
for _L in range(40, 48):
    V4X_ROUTER_DIMS[_L] = 177
for _L in range(48, 52):
    V4X_ROUTER_DIMS[_L] = 129
del _L, _V4X_ROUTER_178


# ---------------------------------------------------------------------------
# Configs por defecto de los encoders (dimensiones verificadas contra el
# checkpoint y contra los configs de origen).
# ---------------------------------------------------------------------------
DEFAULT_WHISPER_CONFIG = {
    "_name_or_path": "openai/whisper-large-v3",
    "d_model": 1280,
    "encoder_layers": 32,
    "decoder_layers": 32,
    "encoder_attention_heads": 20,
    "decoder_attention_heads": 20,
    "encoder_ffn_dim": 5120,
    "decoder_ffn_dim": 5120,
    "num_mel_bins": 128,
    "vocab_size": 51866,           # embed_tokens del decoder
    "max_source_positions": 1500,
    "max_target_positions": 448,
    "activation_function": "gelu",
    # Quirks del checkpoint V4X (¡verificado contra el índice!):
    "k_proj_bias": False,          # NO hay k_proj.bias en ninguna de las 96 atenciones
    "has_proj_out": False,         # NO hay proj_out (solo encoder+decoder)
}

DEFAULT_MERT_CONFIG = {
    "_name_or_path": "m-a-p/MERT-v1-330M",
    "hidden_size": 1024,
    "num_hidden_layers": 24,
    "num_attention_heads": 16,
    "intermediate_size": 4096,
    "num_feat_extract_layers": 7,
    "conv_dim": [512, 512, 512, 512, 512, 512, 512],
    "conv_kernel": [10, 3, 3, 3, 3, 2, 2],
    "conv_stride": [5, 2, 2, 2, 2, 2, 2],
    "feat_extract_norm": "group",       # do_stable_layer_norm=True
    "do_stable_layer_norm": True,
    "feat_proj_layer_norm": True,
    "num_conv_pos_embeddings": 128,
    "num_conv_pos_embedding_groups": 16,
    "layer_norm_eps": 1e-05,
    "hidden_act": "gelu",
    "attention_relax": 32.0,
    "sample_rate": 24000,
    "initializer_range": 0.02,
}


DEFAULT_THINKER_CONFIG = {
    "_name_or_path": "Qwen/Qwen3-Omni-30B-A3B-Instruct (torre de audio)",
    # --- audio tower (Qwen3OmniMoeAudioEncoder) -> V4X_Audio.audio_tower.* ---
    "audio_d_model": 1280,
    "audio_encoder_layers": 32,
    "audio_encoder_attention_heads": 20,
    "audio_encoder_ffn_dim": 5120,
    "audio_num_mel_bins": 128,
    "audio_downsample_hidden_size": 480,
    "audio_output_dim": 2048,
    "audio_max_source_positions": 1500,
    "audio_n_window": 50,
    "audio_n_window_infer": 800,
    "audio_conv_chunksize": 500,
    "audio_activation_function": "gelu",
}


# Torre de visión Qwen3-VL (V4X_Vision.visual.*): imagen Y vídeo.
# Dimensiones verificadas contra el config oficial de Qwen3-VL
# (vision_config: depth 27, hidden 1152, heads 16, intermediate 4304,
#  out_hidden_size 4096, deepstack [8, 16, 24]) y contra las cabeceras del
# checkpoint (V4X_Vision.visual.*, merger.mlp.2 = [4096, 4608]).
DEFAULT_VISION_CONFIG = {
    "_name_or_path": "Qwen/Qwen3-VL-MoE (torre de visión, imagen + vídeo)",
    "vision_hidden_size": 1152,
    "vision_depth": 27,
    "vision_num_heads": 16,
    "vision_intermediate_size": 4304,
    "vision_patch_size": 16,
    "vision_temporal_patch_size": 2,
    "vision_spatial_merge_size": 2,
    "vision_out_hidden_size": 4096,
    "vision_num_position_embeddings": 2304,
    "vision_deepstack_visual_indexes": [8, 16, 24],
    "vision_hidden_act": "gelu_pytorch_tanh",
    "vision_rope_theta": 10000.0,
}


DEFAULT_VISION_ADAPTER_CONFIG = {
    # Proyección de la salida del merger de visión (V4X_Vision.adapter.net.*):
    # 4096 (Qwen3-VL) -> 5376 -> 2688 (hidden del backbone).
    "input_size": 4096,
    "intermediate_size": 5376,
    "output_size": 2688,
    "hidden_act": "gelu",
    "p_dropout": 0.0,
}


class V4XConfig(PretrainedConfig):
    r"""Configuración del modelo completo AI-ku V4X Thinker-Max.

    Componentes:
      - Backbone Nemotron-H híbrido (hidden 2688, 52 capas, YaRN 4x).
      - MoE V4X: 128 expertos base relu2 + 1 shared + 48 Qwen silu + 1 Phi silu.
      - Encoders multimodales con pesos en el checkpoint.
      - Adapter de visión Qwen3-VL (4096) -> backbone V4X (2688).

    Notas de fidelidad:
      - `n_routed_experts=177` y `num_experts_per_tok=177` (router denso: todos los
        expertos por token) según el config original del checkpoint.
      - Los expertos Qwen/Phi viven en `mixer.new_experts.*` y el router unificado en
        `mixer.v4x_router.weight` (capas 17-51).
    """

    model_type = "V4X"
    keys_to_ignore_at_inference = ["past_key_values"]
    base_attr = "backbone"

    # Números mágicos del checkpoint:
    #   base_num_experts=128 (nemotron, relu2, up/down 1856)
    #   shared=1 (relu2, up/down 3712)
    #   qwen=48/capa (silu, gate/up/down 768)
    #   phi=1/capa (silu, gate/up/down 17920)
    #   total lógico: 177 routed + 1 shared = 178

    def __init__(
        self,
        # ------------------ backbone Nemotron-H ------------------
        vocab_size=131072,
        tie_word_embeddings=False,
        hidden_size=2688,
        intermediate_size=1856,
        num_hidden_layers=52,
        hybrid_override_pattern=V4X_HYBRID_OVERRIDE_PATTERN,
        num_attention_heads=32,
        head_dim=128,
        num_key_value_heads=2,
        mlp_hidden_act="relu2",
        attention_bias=False,
        mlp_bias=False,
        use_bias=False,
        initializer_range=0.02,
        layer_norm_epsilon=1e-5,
        residual_in_fp32=False,
        use_cache=True,
        num_logits_to_keep=1,
        pad_token_id=0,
        bos_token_id=1,       # <|V4X_sec|>
        eos_token_id=11,      # <|V4X_end|> (antes 2 = </s> legacy)
        sliding_window=None,
        max_position_embeddings=1048576,
        rope_theta=10000.0,
        rope_scaling=None,          # {"type": "yarn", "factor": 4.0, ...} en el config real
        attention_dropout=0.0,
        hidden_dropout=0.0,
        partial_rotary_factor=1.0,
        # ------------------ Mamba2 ------------------
        use_mamba_kernels=True,
        ssm_state_size=128,
        mamba_num_heads=64,
        mamba_n_groups=8,
        mamba_head_dim=64,
        mamba_d_conv=4,
        mamba_expand=2,
        mamba_hidden_act="silu",
        mamba_dt_min=0.001,
        mamba_dt_max=0.1,
        mamba_dt_limit=(0.0, float("inf")),
        mamba_dt_init_floor=1e-4,
        mamba_conv_bias=True,
        mamba_proj_bias=False,
        mamba_chunk_size=128,
        mamba_ssm_cache_dtype="float32",     # dtype de los estados SSM en caché
        rescale_prenorm_residual=True,
        # ------------------ MoE base (Nemotron) ------------------
        n_routed_experts=177,       # 128 base + 48 qwen + 1 phi (numeración lógica)
        n_shared_experts=1,
        moe_intermediate_size=1856,
        moe_shared_expert_intermediate_size=3712,
        num_experts_per_tok=177,    # router denso V4X
        routed_scaling_factor=2.5,
        n_group=1,
        topk_group=1,
        norm_topk_prob=True,
        base_num_experts=128,       # expertos nemotron FÍSICOS por capa MoE
        base_num_experts_per_tok=6, # top-k del gate ORIGINAL Nemotron (modo "off")
        # ------------------ extensión V4X ------------------
        v4x_qwen_expert_intermediate_size=768,
        v4x_phi_expert_intermediate_size=17920,
        v4x_num_qwen_experts=V4X_NUM_QWEN_EXPERTS,  # 48 (new_experts.0-47)
        v4x_qwen_expert_layers=None,        # None -> V4X_QWEN_EXPERT_LAYERS
        v4x_phi_expert_layers=None,         # None -> V4X_PHI_EXPERT_LAYERS
        v4x_phi_partial_layers=None,        # None -> V4X_PHI_PARTIAL_LAYERS
        v4x_router_layers=None,             # None -> V4X_ROUTER_LAYERS
        v4x_router_dims=None,               # None -> V4X_ROUTER_DIMS
        # Modo de integración del router/expertos nuevos en el forward:
        #   "off"      (por defecto): solo forward base Nemotron. Los pesos V4X se
        #              cargan pero no participan -> logits base coherentes (fase 0).
        #   "unified"  : en capas MoE el v4x_router SUSTITUYE al gate nemotron y
        #              enruta base+shared+qwen(+phi).
        #   "parallel" : en capas NO-MoE añade una rama MoE paralela con los nuevos
        #              expertos (qwen+phi) enrutada por v4x_router.
        #   (unified y parallel se activan a la vez en sus capas correspondientes)
        v4x_routing_mode="off",
        v4x_router_top_k=None,              # None -> num_experts_per_tok (denso)
v4x_phi_span_mask=None,             # FIX-06 (CAMBIOS 70): phi-177 solo en spans think (12..13)
        # Scoring del router V4X en los modos unified/parallel:
        #   "softmax" (defecto): softmax sobre los top-k logits (semántica del
        #             modeling_v4x original del usuario).
        #   "sigmoid" : estilo Nemotron (sigmoid + renorm + routed_scaling_factor).
        v4x_router_scoring="softmax",
        # ------------------ encoders (pesos en checkpoint) ------------------
        whisper_config=None,                # None -> DEFAULT_WHISPER_CONFIG
        mert_config=None,                   # None -> DEFAULT_MERT_CONFIG
        thinker_config=None,                # None -> DEFAULT_THINKER_CONFIG (torre de audio)
        vision_config=None,                 # None -> DEFAULT_VISION_CONFIG (Qwen3-VL, imagen + vídeo)
        vision_adapter_config=None,         # None -> DEFAULT_VISION_ADAPTER_CONFIG (4096->5376->2688)
        **kwargs,
    ):
        # ---- backbone ----
        self.vocab_size = vocab_size
        self.tie_word_embeddings = tie_word_embeddings
        self.hidden_size = hidden_size
        self.intermediate_size = intermediate_size
        self.num_hidden_layers = num_hidden_layers
        self.hybrid_override_pattern = hybrid_override_pattern

        assert len(self.hybrid_override_pattern) == self.num_hidden_layers, (
            "hybrid_override_pattern debe tener longitud == num_hidden_layers"
        )
        assert re.match(r"^[\*ME\-]+$", self.hybrid_override_pattern), (
            "hybrid_override_pattern solo puede contener 'M' (mamba), '*' (attention), "
            "'E' (moe) o '-' (mlp denso)"
        )

        if num_key_value_heads is None:
            num_key_value_heads = num_attention_heads
        self.num_key_value_heads = num_key_value_heads

        self.num_attention_heads = num_attention_heads
        self.head_dim = head_dim
        self.sliding_window = sliding_window
        self.max_position_embeddings = max_position_embeddings
        self.rope_theta = rope_theta
        self.rope_scaling = rope_scaling
        self.partial_rotary_factor = partial_rotary_factor
        self.attention_dropout = attention_dropout
        self.hidden_dropout = hidden_dropout

        self.mlp_hidden_act = mlp_hidden_act
        self.attention_bias = attention_bias
        self.mlp_bias = mlp_bias
        self.use_bias = use_bias
        self.initializer_range = initializer_range
        self.layer_norm_epsilon = layer_norm_epsilon
        self.residual_in_fp32 = residual_in_fp32
        self.use_cache = use_cache
        self.num_logits_to_keep = num_logits_to_keep

        # ---- mamba2 ----
        self.use_mamba_kernels = use_mamba_kernels
        self.n_groups = mamba_n_groups
        self.mamba_head_dim = mamba_head_dim
        self.ssm_state_size = ssm_state_size
        self.mamba_num_heads = mamba_num_heads
        self.conv_kernel = mamba_d_conv
        self.expand = mamba_expand
        self.mamba_hidden_act = mamba_hidden_act
        self.time_step_min = mamba_dt_min
        self.time_step_max = mamba_dt_max
        self.time_step_limit = mamba_dt_limit
        self.time_step_floor = mamba_dt_init_floor
        self.use_conv_bias = mamba_conv_bias
        self.mamba_proj_bias = mamba_proj_bias
        self.chunk_size = mamba_chunk_size
        self.mamba_ssm_cache_dtype = mamba_ssm_cache_dtype
        self.rescale_prenorm_residual = rescale_prenorm_residual

        # ---- MoE base ----
        self.n_routed_experts = n_routed_experts
        self.n_shared_experts = n_shared_experts
        self.moe_intermediate_size = moe_intermediate_size
        self.moe_shared_expert_intermediate_size = moe_shared_expert_intermediate_size
        self.num_experts_per_tok = num_experts_per_tok
        self.routed_scaling_factor = routed_scaling_factor
        self.n_group = n_group
        self.topk_group = topk_group
        self.norm_topk_prob = norm_topk_prob
        self.base_num_experts = base_num_experts
        self.base_num_experts_per_tok = base_num_experts_per_tok

        # ---- extensión V4X ----
        self.v4x_qwen_expert_intermediate_size = v4x_qwen_expert_intermediate_size
        self.v4x_phi_expert_intermediate_size = v4x_phi_expert_intermediate_size
        self.v4x_num_qwen_experts = v4x_num_qwen_experts
        self.v4x_qwen_expert_layers = (
            list(v4x_qwen_expert_layers) if v4x_qwen_expert_layers is not None
            else list(V4X_QWEN_EXPERT_LAYERS)
        )
        self.v4x_phi_expert_layers = (
            list(v4x_phi_expert_layers) if v4x_phi_expert_layers is not None
            else list(V4X_PHI_EXPERT_LAYERS)
        )
        self.v4x_phi_partial_layers = (
            list(v4x_phi_partial_layers) if v4x_phi_partial_layers is not None
            else list(V4X_PHI_PARTIAL_LAYERS)
        )
        self.v4x_router_layers = (
            list(v4x_router_layers) if v4x_router_layers is not None
            else list(V4X_ROUTER_LAYERS)
        )
        self.v4x_router_dims = (
            # JSON serializa las claves int como string: re-coeger a int al cargar
            {int(k): int(v) for k, v in dict(v4x_router_dims).items()} if v4x_router_dims is not None
            else dict(V4X_ROUTER_DIMS)
        )
        self.v4x_routing_mode = v4x_routing_mode
        self.v4x_router_top_k = v4x_router_top_k
        self.v4x_phi_span_mask = bool(v4x_phi_span_mask) if v4x_phi_span_mask is not None else False
        self.v4x_router_scoring = v4x_router_scoring

        # Normalizar rope_scaling al formato nuevo ("type" -> "rope_type") para
        # que ROPE_INIT_FUNCTIONS de transformers lo acepte directamente.
        if isinstance(self.rope_scaling, dict) and "rope_type" not in self.rope_scaling and "type" in self.rope_scaling:
            self.rope_scaling = {**self.rope_scaling, "rope_type": self.rope_scaling["type"]}

        # ---- encoders ----
        self.whisper_config = dict(DEFAULT_WHISPER_CONFIG) if whisper_config is None else dict(whisper_config)
        self.mert_config = dict(DEFAULT_MERT_CONFIG) if mert_config is None else dict(mert_config)
        self.thinker_config = dict(DEFAULT_THINKER_CONFIG) if thinker_config is None else dict(thinker_config)
        self.vision_config = dict(DEFAULT_VISION_CONFIG) if vision_config is None else dict(vision_config)
        self.vision_adapter_config = (
            dict(DEFAULT_VISION_ADAPTER_CONFIG) if vision_adapter_config is None else dict(vision_adapter_config)
        )

        # auto_map de instancia para trust_remote_code (idéntico al config
        # original del checkpoint): hace que todo save_pretrained() produzca un
        # repo cargable con AutoConfig/AutoModelForCausalLM(trust_remote_code=True).
        self.auto_map = {
            "AutoConfig": "configuration_v4x.V4XConfig",
            "AutoModelForCausalLM": "modeling_v4x.V4XForCausalLM",
        }

        super().__init__(
            pad_token_id=pad_token_id,
            bos_token_id=bos_token_id,
            eos_token_id=eos_token_id,
            tie_word_embeddings=tie_word_embeddings,
            **kwargs,
        )

    # ------------------------------------------------------------------
    @property
    def layers_block_type(self):
        """Mapea el patrón híbrido a tipos de bloque.

        M -> mamba | * -> attention | E -> moe | - -> mlp
        """
        mapping = {"M": "mamba", "*": "attention", "E": "moe", "-": "mlp"}
        return [mapping[c] for c in self.hybrid_override_pattern]

    # ------------------------------------------------------------------
    # Accesores útiles (dimensiones reales de cada componente)
    # ------------------------------------------------------------------
    @property
    def mamba_intermediate_size(self):
        """d_inner de Mamba2 = num_heads * head_dim (4096)."""
        return self.mamba_num_heads * self.mamba_head_dim

    @property
    def whisper_d_model(self):
        return self.whisper_config["d_model"]

    @property
    def mert_hidden_size(self):
        return self.mert_config["hidden_size"]

    @property
    def thinker_out_hidden_size(self):
        """Dimensión de salida de la torre de audio (2048)."""
        return self.thinker_config["audio_output_dim"]

    @property
    def vision_out_hidden_size(self):
        """Dimensión de salida del merger de visión (4096)."""
        return self.vision_config["vision_out_hidden_size"]

    @property
    def adapter_io(self):
        c = self.vision_adapter_config
        return c["input_size"], c["intermediate_size"], c["output_size"]

    def expert_summary(self):
        """Metadatos lógicos de expertos (idéntico al config original)."""
        return {
            "0-127": {"origin": "nemotron", "type": "general", "activation": "relu2"},
            "128": {"origin": "nemotron", "type": "shared", "activation": "relu2"},
            "129-176": {"origin": "qwen3-coder", "type": "code", "activation": "silu"},
            "177": {"origin": "phi-4", "type": "reasoning", "activation": "silu"},
        }
